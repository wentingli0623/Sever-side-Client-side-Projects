﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;
using System.Data;
using CoffeeShopLibrary;
using System.Collections;
using System.Globalization;
using System.Drawing;
using System.Windows.Forms;
using CheckBox = System.Web.UI.WebControls.CheckBox;
using TextBox = System.Web.UI.WebControls.TextBox;

namespace CIS3342_StarbuxPorject_WentingLi
{
    public partial class starBux : System.Web.UI.Page
    {
        ArrayList orderList = new ArrayList();
        protected void Page_Load(object sender, EventArgs e)
        {



            if (IsPostBack == false)
            {
                DBConnect dBConnect = new DBConnect();
                String str = "SELECT Title, Description, BasePrice FROM drinks WHERE Category = 'Tea'";
                DataSet myData = dBConnect.GetDataSet(str);
                gvTeaMenu.DataSource = myData;
                gvTeaMenu.DataBind();


                DBConnect dBConnect1 = new DBConnect();
                String str1 = "SELECT Title, Description, BasePrice FROM drinks WHERE Category = 'Coffee'";
                DataSet myData1 = dBConnect1.GetDataSet(str1);
                gvcoffeeMenu.DataSource = myData1;
                gvcoffeeMenu.DataBind();

            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            long b = 9999999999;
            // validation 
            if (txtBoxName.Text == "")
            {

                MessageBox.Show("Please enter your name");

            }
            else if (txtAddress.Text == "")
            {
                // Messagebox.Show(alert, title);

                MessageBox.Show("Please enter your Address");
            }
            else if (txtBoxPhone.Text == "")
            {


                MessageBox.Show("Please enter your PhoneNumber");
            }

            else if (!(long.TryParse(txtBoxPhone.Text, out b)))
            {

                MessageBox.Show("please enter a valid Phone number ");

            }
            else if (txtBoxPhone.Text.Length != 10)
            {
                MessageBox.Show("please enter a valid 10 digits Phone number  ");
            }


            else if (!txtRewardID.Text.Equals(""))
            {
                if (txtRewardID.Text.Length != 4 || !(long.TryParse(txtRewardID.Text, out b)))
                {

                    MessageBox.Show("please enter a 4 digits RewardID ");

                }

            }
            else
            {

                pnlMenu.Visible = false;
                pnlCustomerInfor.Visible = true; ;
                pnlOrderList.Visible = true;

                // ArrayList orderList = new ArrayList();


                // Iterate through the rows (records) of the GridView and store the ProductNumber
                // for each row that is checked
                //需要遍历tea and coffee 两个菜单
                for (int row = 0; row < gvTeaMenu.Rows.Count; row++)
                {
                    CheckBox CBox;
                    DropDownList ddldropD;
                    RadioButtonList rblType;
                    TextBox txtQ;





                    // Get the reference for the chkSelect control in the current row
                    CBox = (CheckBox)gvTeaMenu.Rows[row].FindControl("checkBoxTeaMenu");
                    ddldropD = (DropDownList)gvTeaMenu.Rows[row].FindControl("ddlSize");
                    rblType = (RadioButtonList)gvTeaMenu.Rows[row].FindControl("RBLType");
                    txtQ = (TextBox)gvTeaMenu.Rows[row].FindControl("txtBoxOrderQ");
                    //  lbltotal=(Label)gvTeaMenu.Rows[row].FindControl("");
                    if (CBox.Checked)
                    {
                        // create drink objects
                        Drink drink = new Drink();
                        drinkMethods dM = new drinkMethods();
                        drink.Title = gvTeaMenu.Rows[row].Cells[1].Text;
                        drink.Description = gvTeaMenu.Rows[row].Cells[2].Text;
                        drink.BasePrice = float.Parse(gvTeaMenu.Rows[row].Cells[3].Text.Substring(1));
                        drink.Size = ddldropD.SelectedItem.Value;
                        drink.Type = rblType.SelectedItem.Value;
                        drink.Quantity = int.Parse(txtQ.Text);
                        drink.TotalCost = dM.calTotalPerItem(drink.BasePrice, drink.Quantity, drink.Size);
                        orderList.Add(drink);
                    }
                }
                for (int row = 0; row < gvcoffeeMenu.Rows.Count; row++)
                {
                    CheckBox CBox;
                    DropDownList ddldropD;
                    RadioButtonList rblType;
                    TextBox txtQ;
                    // Get the reference for the chkSelect control in the current row
                    CBox = (CheckBox)gvcoffeeMenu.Rows[row].FindControl("cbDrink0");
                    ddldropD = (DropDownList)gvcoffeeMenu.Rows[row].FindControl("ddlSize");
                    rblType = (RadioButtonList)gvcoffeeMenu.Rows[row].FindControl("RBLType");
                    txtQ = (TextBox)gvcoffeeMenu.Rows[row].FindControl("txtBoxOrderQ");

                    if (CBox.Checked)
                    {
                        // create drink objects
                        Drink drink = new Drink();
                        drinkMethods dM = new drinkMethods();
                        drink.Title = gvcoffeeMenu.Rows[row].Cells[1].Text;
                        drink.Description = gvcoffeeMenu.Rows[row].Cells[2].Text;
                        drink.BasePrice = float.Parse(gvTeaMenu.Rows[row].Cells[3].Text.Substring(1));
                        drink.Size = ddldropD.SelectedItem.Value;
                        drink.Type = rblType.SelectedItem.Value;
                        drink.Quantity = int.Parse(txtQ.Text);
                        drink.TotalCost = dM.calTotalPerItem(drink.BasePrice, drink.Quantity, drink.Size);
                        orderList.Add(drink);

                    }

                }
                if (orderList.Count == 0)
                {

                    string alert = "You have to at least select one item";
                    string title = "Opps....";
                    MessageBox.Show(alert, title);
                    lblYourOrder.Visible = false;
                    pnlCustomerInfor.Visible = false;


                }
        





                int totalQuantity = 0;
                double totalCost = 0;
                gvOutput.DataSource = orderList;
                gvOutput.DataBind();

                // get data from rewardtable 
                DBConnect dBConnect5 = new DBConnect();
                String str5 = "SELECT RewardAccountID FROM rewardAccounts";
                DataSet myData5 = dBConnect5.GetDataSet(str5);



                // an arrary stores all IDs 

                // for (int cell = 0;cell< 5; cell++) {

                string rewardID1 = myData5.Tables[0].Rows[0]["RewardAccountID"].ToString();
                string rewardID2 = myData5.Tables[0].Rows[1]["RewardAccountID"].ToString();
                string rewardID3 = myData5.Tables[0].Rows[2]["RewardAccountID"].ToString();
                string rewardID4 = myData5.Tables[0].Rows[3]["RewardAccountID"].ToString();
                string rewardID5 = myData5.Tables[0].Rows[4]["RewardAccountID"].ToString();
                int TITLE_COLUMN = 0;
                int QUANTITY_COLUMN = 5;
                int TOTALCOST_COLUMN = 6;
                // calculate total if is  a reward customer
                if (txtRewardID.Text.Equals(rewardID1) || txtRewardID.Text.Equals(rewardID2) || txtRewardID.Text.Equals(rewardID3) || txtRewardID.Text.Equals(rewardID4) || txtRewardID.Text.Equals(rewardID5))
                {
                    // if statement that track rewardID if match, get 10% off


                    lblYourOrder.Text = "Welcome back! Our Reward Customer " + txtBoxName.Text + "<br/>" + "Your Phone Number is:" + txtBoxPhone.Text + "<br/>" + "Your Address is:"
                     + txtAddress.Text + "<br/>" + "Your reward Number is:" + txtRewardID.Text + "<br/>" + "Method:" + rlPickMethod.Text + "<br/>" + "<br/>" + "You got 10% off for this order";
                    for (int i = 0; i < orderList.Count; i++)
                    {

                        totalQuantity = totalQuantity + int.Parse(gvOutput.Rows[i].Cells[QUANTITY_COLUMN].Text);
                        totalCost = (totalCost + double.Parse(gvOutput.Rows[i].Cells[TOTALCOST_COLUMN].Text, System.Globalization.NumberStyles.Currency)) * 0.9;
                    }
                    gvOutput.Columns[TITLE_COLUMN].FooterText = "Totals:";
                    gvOutput.Columns[QUANTITY_COLUMN].FooterText = totalQuantity.ToString();
                    gvOutput.Columns[TOTALCOST_COLUMN].FooterText = totalCost.ToString();
                    gvOutput.Columns[TITLE_COLUMN].FooterStyle.ForeColor = Color.Red;
                    gvOutput.Columns[QUANTITY_COLUMN].FooterStyle.ForeColor = Color.Red;
                    gvOutput.Columns[TOTALCOST_COLUMN].FooterStyle.ForeColor = Color.Red;
                    gvOutput.DataBind();

                    //update database records: update drinks
                    // use totalQuantity add into database totalSale
                    // use totalCost add into database totalSale

                    foreach (Drink dr in orderList)
                    {

                        DBConnect dBConnect7 = new DBConnect();
                        String str7 = "UPDATE drinks SET TOTALSALES = TOTALSALES+" + totalCost + "WHERE TITLE ='" + dr.Title + "'";
                        dBConnect7.DoUpdate(str7);


                    }

                    foreach (Drink dr in orderList)
                    {

                        DBConnect dBConnect8 = new DBConnect();
                        String str8 = "UPDATE drinks SET BaseQuantitySold = BaseQuantitySold +" + totalQuantity + "WHERE TITLE ='" + dr.Title + "'";
                        dBConnect8.DoUpdate(str8);


                    }


                    //update database records: update rewards 
                    // total,grosssale
                    DBConnect dBConnect6 = new DBConnect();
                    String str6 = "UPDATE rewardAccounts SET GrossSales = GrossSales+" + totalCost + "WHERE RewardAccountID='" + txtRewardID.Text + "'";
                    dBConnect6.DoUpdate(str6);


                }
                else // calculate total if is not a reward customer
                { // if txtRewardID.Text="" no discount

                    lblYourOrder.Text = "Hello, " + txtBoxName.Text + "<br/>" + "Your Phone Number is:" + txtBoxPhone.Text + "<br/>" + "Your Address is:"
                       + txtAddress.Text + "<br/>" + "<br/>" + "Method:" + rlPickMethod.Text;
                    for (int l = 0; l < orderList.Count; l++)
                    {

                        totalQuantity = totalQuantity + int.Parse(gvOutput.Rows[l].Cells[QUANTITY_COLUMN].Text);
                        totalCost = totalCost + double.Parse(gvOutput.Rows[l].Cells[TOTALCOST_COLUMN].Text, System.Globalization.NumberStyles.Currency);
                    }


                    gvOutput.Columns[TITLE_COLUMN].FooterText = "Totals:";
                    gvOutput.Columns[QUANTITY_COLUMN].FooterText = totalQuantity.ToString();
                    gvOutput.Columns[TOTALCOST_COLUMN].FooterText = totalCost.ToString();
                    gvOutput.Columns[TITLE_COLUMN].FooterStyle.ForeColor = Color.Red;
                    gvOutput.Columns[QUANTITY_COLUMN].FooterStyle.ForeColor = Color.Red;
                    gvOutput.Columns[TOTALCOST_COLUMN].FooterStyle.ForeColor = Color.Red;
                    gvOutput.DataBind();

                    foreach (Drink dr in orderList)
                    {

                        DBConnect dBConnect7 = new DBConnect();
                        String str7 = "UPDATE drinks SET TOTALSALES = TOTALSALES+" + totalCost + "WHERE TITLE ='" + dr.Title + "'";
                        dBConnect7.DoUpdate(str7);


                    }

                    foreach (Drink dr in orderList)
                    {

                        DBConnect dBConnect8 = new DBConnect();
                        String str8 = "UPDATE drinks SET BaseQuantitySold = BaseQuantitySold +" + totalQuantity + "WHERE TITLE ='" + dr.Title + "'";
                        dBConnect8.DoUpdate(str8);


                    }

                }

            }
        }


        protected void gvcoffeeMenu_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void gvOutput_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnViewSeller_Click(object sender, EventArgs e)
        {
            //  imageStar1.Visible = false;
            //imageStar2.Visible = false;
            pnlManagementR.Visible = true;
            pnlOrderList.Visible = false;
            pnlMenu.Visible = false;
            pnlCustomerInfor.Visible = false;
            lblBestC.Visible = false;
            gvBestSelling.Visible = true;
            gvBestSelling.Visible = true;

            DBConnect dBConnect3 = new DBConnect();
            String str3 = "SELECT TOP 5 Title,Category,BaseQuantitySold FROM drinks ORDER By BaseQuantitySold DESC ";
            DataSet myData3 = dBConnect3.GetDataSet(str3);
            gvBestSelling.DataSource = myData3;
            gvBestSelling.DataBind();



            DBConnect dBConnect11 = new DBConnect();
            String str11 = "SELECT  TOP 5 Title, Category,TotalSales FROM drinks ORDER By TotalSales DESC ";
            DataSet myData11 = dBConnect11.GetDataSet(str11);
            gvBestSellGrossTotal.DataSource = myData11;
            gvBestSellGrossTotal.DataBind();

        }
        protected void btnBestcustomer_Click(object sender, EventArgs e)
        {
            pnlManagementR.Visible = true;
            pnlOrderList.Visible = false;
            pnlMenu.Visible = false;
            pnlCustomerInfor.Visible = false;
            lblBestC.Visible = true;
            lblBestQuanlity.Visible = false;
            lblBestTotal.Visible = false;
            gvBestSellGrossTotal.Visible = false;
            gvBestSelling.Visible = false;

            DBConnect dBConnect4 = new DBConnect();
            String str4 = "SELECT TOP 5 CustomerName, GrossSales FROM rewardAccounts ORDER BY TotalOrders DESC";
            DataSet myData4 = dBConnect4.GetDataSet(str4);
            gvBestCustomer.DataSource = myData4;
            gvBestCustomer.DataBind();
        }
        protected void btnBack2Menu_Click(object sender, EventArgs e)
        {

            pnlManagementR.Visible = false;
            pnlOrderList.Visible = false;
            pnlMenu.Visible = true;
            pnlCustomerInfor.Visible = false;
            lblBestC.Visible = false;
            lblBestQuanlity.Visible = false;
            lblBestTotal.Visible = false;
            pnlCustomerInfor.Visible = true;


        }
        protected void btnDone_Click(object sender, EventArgs e)
        {

           // string alert = "You order number is 88, it going to take above 20 mins";
            //string title = "Thanks for your busniess !";
            //MessageBox.Show(alert, title);

            pnlManagementR.Visible = false;
            pnlOrderList.Visible = false;
            pnlMenu.Visible = true;
            pnlCustomerInfor.Visible = false;
            lblBestC.Visible = false;
            lblBestQuanlity.Visible = false;
            lblBestTotal.Visible = false;
            pnlCustomerInfor.Visible = true;
            // clear
            txtAddress.Text = "";
            txtBoxName.Text = "";
            txtBoxPhone.Text = "";
            txtRewardID.Text = "";
                



        }
        protected void gvTeaMenu_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void gvBestSelling_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txtBoxPhone0_TextChanged(object sender, EventArgs e)
        {

        }

        protected void rlPickMethod_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txtRewardID_TextChanged(object sender, EventArgs e)
        {

        }

      
    }
}