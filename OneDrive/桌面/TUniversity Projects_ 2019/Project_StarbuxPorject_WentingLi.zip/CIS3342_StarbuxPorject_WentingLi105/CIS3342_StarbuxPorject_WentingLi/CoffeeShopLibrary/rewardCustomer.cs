﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopLibrary
{
    class rewardCustomer
    {
        string customerID;
        string customerName;
        string phoneNumber;
        double grossSales;
        int totalOrders;

        public String CusterID
        {
            get { return customerID; }
            set { customerID = value; }
        }
        public String CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }

        public String PhoneNumber
        {
            get { return phoneNumber; }
            set { phoneNumber = value; }
        }



        public double GrossSales
        {
            get { return grossSales; }
            set { grossSales = value; }
        }



        public int TotalOrders
        {
            get { return totalOrders; }
            set { totalOrders = value; }
        }

        public Boolean ifMatched(string rewardID)
        {

            if (rewardID.Equals(customerID))
            {


                return true;


            }
            return false;


        }

    }
}
