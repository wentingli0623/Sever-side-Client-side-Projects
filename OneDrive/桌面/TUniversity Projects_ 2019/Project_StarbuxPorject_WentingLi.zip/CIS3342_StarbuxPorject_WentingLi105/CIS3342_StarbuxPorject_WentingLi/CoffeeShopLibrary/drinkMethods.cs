﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopLibrary
{
    public class drinkMethods
    {
        double totalCost;
        string types;
        double basePrice;
        int quantity;

        public double calTotalPerItem(double basePrice, int quanlity ,string size)
        {

            totalCost = dependOnSize(basePrice,size) * quanlity;




            return totalCost;

        }
        public double dependOnSize(double basePrice ,string size)
        {

            if (size.Equals("Tall"))
            {
                return basePrice;
            }
            else if (size.Equals("Venti"))
            {
                return basePrice *1.8;
            }
            else

                return basePrice *1.5;


        }

        public Boolean checkQuantity()
        {

            if (quantity == 0)
            {
                return true;

            }
            return false;

        }






















    }
}
