﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


using System.Data;
using CoffeeShopLibrary;
using System.Collections;

namespace CoffeeShopLibrary
{
    public class OrderList
    {
        Drink singleDrink;
        ArrayList orderList = new ArrayList();
        double orderTotal;
        int count = 0;
        public void add( Drink dr) {
            orderList.Add(dr);
            count++;

        }

        public double calOrderTotal() {
            for (int i = 0; i<orderList.Count; i++) {
           //     orderTotal += singleDrink.(singleDrink.BasePrice,singleDrink.Quantity);


            }

            return orderTotal;

        }
        public int Count() {

            return count;
        }

        
    }
}
