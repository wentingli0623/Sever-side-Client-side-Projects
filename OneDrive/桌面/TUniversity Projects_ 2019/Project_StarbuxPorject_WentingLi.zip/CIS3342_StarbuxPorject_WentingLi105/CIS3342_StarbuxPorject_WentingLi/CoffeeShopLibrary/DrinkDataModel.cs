﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopLibrary
{
   // for out put gv
  public class Drink
    {
        String title;
        string description;
        double basePrice;
        String size;
        String types;
        int  quantity;
        double totalCost;


        public String Title {
            get { return title; }
            set { title = value; }
        }
        public String Description 
        {
            get { return description; }
            set { description = value; }
        }


        public double BasePrice
        {   
          
            get { return basePrice; }
            set { basePrice = value; }
        
}


        public String Size
        {
            get { return size; }
            set { size = value; }
        }
        public String Type
        {
            get { return types; }
            set { types = value; }
        }
        public int  Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }

        public double TotalCost
        {
            get { return totalCost; }
            set { totalCost = value; }
        }

        //public double calTotalPerItem(double basePrice , int quanlity) {

        //    totalCost = dependOnSize() * quanlity;




        //    return totalCost;

        //}
        //public double dependOnSize() {

        //    if (types=="Tall") {
        //        return basePrice;
        //    }
        //    else if ( types=="Grande") {
        //        return basePrice+1;
        //    }
        //    else 

        //    return basePrice + 2;


        //}

        //public Boolean checkQuantity() {

        //    if (quantity == 0) {
        //        return true;

        //    }
        //    return false;

        //}















    }
}
