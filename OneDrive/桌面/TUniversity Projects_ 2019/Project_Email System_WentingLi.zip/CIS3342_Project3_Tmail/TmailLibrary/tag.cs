﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TmailLibrary
{
 
   public class tag
    {
        string tagName;

        public string TagName
        {
            get { return tagName; }
            set { tagName = value; }


        }


    }
}
