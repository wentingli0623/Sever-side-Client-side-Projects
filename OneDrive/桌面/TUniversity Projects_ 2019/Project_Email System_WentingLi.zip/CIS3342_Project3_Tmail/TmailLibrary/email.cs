﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TmailLibrary
{
    public class email
    {
        int emailId;
        int senderId;
        int receivedId;
        string subject;
        string emailBody;
        string emailURL;
        DateTime createdTime;
        

        public int EmailId
        {
            get { return emailId; }
            set { emailId = value; }


        }
        public int SenderId
        {
            get { return senderId; }
            set { senderId = value; }


        }


        public int ReceivedId
        {
            get { return receivedId; }
            set { receivedId = value; }


        }

        //emailURL;
 
        public string EmailBody
        {
            get { return emailBody; }
            set { emailBody = value; }


        }
        public string Subject
        {
            get { return subject; }
            set { subject = value; }


        }

        public DateTime CreatedTime
        {
            get { return createdTime; }
            set { createdTime = value; }


        }





    }
}
