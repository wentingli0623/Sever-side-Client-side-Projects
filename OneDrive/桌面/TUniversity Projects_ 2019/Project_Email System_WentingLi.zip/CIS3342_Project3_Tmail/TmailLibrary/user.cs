﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TmailLibrary
{
   
        public class user
        {
            int userId;
            string userName;
            string address;
            long phoneNumber;
            string createdEmailAddress;
        string contactEmailAddress;
            string avatarURL;
            string password;
            int active;
            int type;

            public int UserId
            {
                get { return userId; }
                set { userId = value; }


            }
            public string UserName
            {
                get { return userName; }
                set { userName = value; }


            }
            public string Address
            {
                get { return address; }
                set { address = value; }


            }
            public long PhoneNumber
            {
                get { return phoneNumber; }
                set { phoneNumber = value; }


            }
            public string CreatedEmailAddress
            {
                get { return createdEmailAddress; }
                set { createdEmailAddress = value; }


            }
        public string ContactEmailAddress
        {
            get { return contactEmailAddress; }
            set { contactEmailAddress = value; }


        }
        public string AvatarURL
            {
                get { return avatarURL; }
                set { avatarURL = value; }


            }
            public string Password
            {
                get { return password; }
                set { password = value; }


            }
            public int Active
            {
                get { return active; }
                set { active = value; }


            }
            public int Type
            {
                get { return type; }
                set { type = value; }


            }
            public bool getUser(string name, string pw)
            { // check if password correct 


                if (this.password == pw)
                {


                    return true;


                }
                else
                    return false;






            


        }
    }
}
