﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;
using TmailLibrary;
using System.Windows.Forms;
using System.Collections;
using CheckBox = System.Web.UI.WebControls.CheckBox;
using TextBox = System.Windows.Forms.TextBox;

namespace CIS3342_Project3_Tmail
{
    public partial class administrator : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            //lblDisplayUserName0.Text = Session["userName"].ToString();

            //currentUserId = int.Parse(Session["userid"].ToString());
            //currentImageURL = Session["avatar"].ToString();

            //ImgDisplayUserImage.ImageUrl = currentImageURL;
            if (!IsPostBack)
            {// first page load
                lblAd.Text = Session["userName"].ToString();
             string currentImageURL = Session["avatar"].ToString();

                imgAd.ImageUrl = currentImageURL;

            }


            

        }
        protected void btnLogOff_Click(object sender, EventArgs e)
        {
            Response.Redirect("LogIn.aspx");
        }

        protected void btnBan_Click(object sender, EventArgs e)
        {
            int count = 0;
            for (int row = 0; row < gvAdFlagView.Rows.Count; row++)
            {
                CheckBox CBox;

                CBox = (CheckBox)gvAdFlagView.Rows[row].FindControl("ckbFlagAdView");

                if (CBox.Checked)
                { // find sender , turn active to 0
                    int banSenderId = int.Parse(gvAdFlagView.Rows[row].Cells[1].Text);

                    // find sender infor from single users
                    // AdBanUser @inputUsertoBan

                    SqlCommand objCommand = new SqlCommand();
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.CommandText = "AdBanUser";// name of the procedure
                                                         // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                    objCommand.Parameters.AddWithValue("@inputUsertoBan", banSenderId);

                    DBConnect objDB = new DBConnect();
                    DataSet myDataSet;
                    myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);
                    Response.Write("<script>alert('You have Banned this user succesfully.')</script>");

                    //MessageBox.Show("You have Banned this user succesfully ");
                    count++;
                }
            

            }
            if (count == 0)
            {

                Response.Write("<script>alert('You have to chose at least one user to  Ban')</script>");
                //MessageBox.Show("You have to chose at least one user to  Ban");

            }
        }
        protected void btnAdShowFlags_Click(object sender, EventArgs e)
        {
            gvAdFlagView.Visible = true;
            btnBan.Visible = true;
            gvAdShowUsers.Visible = false;
            btnUnBan.Visible = true;
            //ShowFlagsForAd
            // code ysed to connect to a SQL server database and execute  a stored procedure
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "ShowFlagsForAd";// name of the procedure
                                                      // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 

            DBConnect objDB = new DBConnect();
            DataSet myDataSet;
            myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


            int size = myDataSet.Tables[0].Rows.Count;
            if (size > 0)
            {
                ArrayList emailListFlag = new ArrayList();
                for (int i = 0; i < size; i++)
                {
                    email Email = new email();

                    Email.EmailId = int.Parse(myDataSet.Tables[0].Rows[i]["emailID"].ToString());
                    Email.SenderId = int.Parse(myDataSet.Tables[0].Rows[i]["senderId"].ToString());
                    Email.ReceivedId = int.Parse(myDataSet.Tables[0].Rows[i]["receivedId"].ToString());
                    Email.Subject = myDataSet.Tables[0].Rows[i]["subject"].ToString();
                    Email.EmailBody = myDataSet.Tables[0].Rows[i]["emailBody"].ToString();
                    Email.CreatedTime = DateTime.Parse(myDataSet.Tables[0].Rows[i]["createdTime"].ToString());
                    emailListFlag.Add(Email);

                    gvAdFlagView.DataSource = emailListFlag;
                    gvAdFlagView.DataBind();
                }
            }
            else
                Response.Write("<script>alert('You dont have any mails in your  flag box ')</script>");
            // MessageBox.Show("You dont have any mails in your  flag box ");
        }
        
        protected void btnCheckUser_Click(object sender, EventArgs e)
        {
            gvAdFlagView.Visible = false;
            btnBan.Visible = false;


            // display all users 
            // gvAdViewUsers.RowStyle.Height = 50;
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "ShowUsersForAd";// name of the procedure
                                                      // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 



            DBConnect objDB = new DBConnect();
            DataSet myDataSet;
            myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


            int size = myDataSet.Tables[0].Rows.Count;
            if (size > 0)
            {
                ArrayList personList = new ArrayList();
                for (int i = 0; i < size; i++)
                {

                    user showUser = new user();
                    showUser.AvatarURL = myDataSet.Tables[0].Rows[i]["userId"].ToString();
                    
                    showUser.UserId = int.Parse(myDataSet.Tables[0].Rows[i]["userId"].ToString());
                    showUser.UserName = myDataSet.Tables[0].Rows[i]["userName"].ToString();
                    showUser.Address = myDataSet.Tables[0].Rows[i]["address"].ToString();
                    showUser.PhoneNumber = long.Parse(myDataSet.Tables[0].Rows[i]["phoneNumber"].ToString());
                    showUser.CreatedEmailAddress = myDataSet.Tables[0].Rows[i]["createEmailAddress"].ToString();
                    showUser.AvatarURL = myDataSet.Tables[0].Rows[i]["avatar"].ToString();
                    
                    showUser.Password = myDataSet.Tables[0].Rows[i]["password"].ToString();
                    showUser.Active = int.Parse(myDataSet.Tables[0].Rows[i]["active"].ToString());
                    showUser.Type = int.Parse(myDataSet.Tables[0].Rows[i]["type"].ToString());
                    personList.Add(showUser);

                }

                gvAdShowUsers.DataSource = personList;
                gvAdShowUsers.DataBind();
            }

        }

        protected void btnUnban_Click(object sender, EventArgs e)
        {
            int count = 0;
            for (int row = 0; row < gvAdFlagView.Rows.Count; row++)
            {
                CheckBox CBox;

                CBox = (CheckBox)gvAdFlagView.Rows[row].FindControl("ckbFlagAdView");

                if (CBox.Checked)
                { // find sender , turn active to 0



                    int banSenderId = int.Parse(gvAdFlagView.Rows[row].Cells[1].Text);

                    // find sender infor from single users
                    // AdBanUser @inputUsertoBan

                    SqlCommand objCommand = new SqlCommand();
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.CommandText = "AdunBanUser";// name of the procedure
                                                           // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                    objCommand.Parameters.AddWithValue("@inputUsertounBan", banSenderId);

                    DBConnect objDB = new DBConnect();
                    DataSet myDataSet;
                    myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);
                    Response.Write("<script>alert('You have unbanned this user succesfully ')</script>");

                    // MessageBox.Show("You have unbanned this user succesfully ");
                    count++;

                }

            }
            if (count == 0)
            {

                Response.Write("<script>alert('You have to chose at least one user to  unBan')</script>");

             //   MessageBox.Show("You have to chose at least one user to  unBan");

            }
        }

       
    }
}
