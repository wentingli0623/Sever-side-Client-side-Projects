﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;
using System.Web.SessionState;
using System.Data;
using System.Collections;
using TmailLibrary;
using System.Windows.Forms;
using System.Data.SqlClient;
using CheckBox = System.Web.UI.WebControls.CheckBox;
using TextBox = System.Web.UI.WebControls.TextBox;
using Button = System.Web.UI.WebControls.Button;

namespace CIS3342_Project3_Tmail
{

    public partial class ordinaryUser : System.Web.UI.Page
    {
        // DBConnect dBConnect = new DBConnect();
        ArrayList emailListInbox = new ArrayList();
        ArrayList emailListSent = new ArrayList();
        ArrayList emailTrashList = new ArrayList();
        ArrayList emailListJunk = new ArrayList();
        ArrayList emailListFlag = new ArrayList();
        ArrayList showallemails = new ArrayList();
        public static string l;
        static int currentUserId;
        string currentImageURL;
        protected void Page_Load(object sender, EventArgs e)
        {


            if (!IsPostBack)
            {// first page load

                lblDisplayUserName0.Text = Session["userName"].ToString();
        
                currentUserId = int.Parse(Session["userid"].ToString());
                currentImageURL = Session["avatar"].ToString();

                ImgDisplayUserImage.ImageUrl = currentImageURL ;
                    
            }
        }


        protected void btnGoBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("LogIn.aspx");
        }

        protected void btnComposeEmail_Click(object sender, EventArgs e)
        {
            pnlCreateFolder.Visible = false;
            pnlComposeEmail.Visible = true;

            pnlSent.Visible = false;
            pnlJuck.Visible = false;
            pnlTrash.Visible = false;
            pnlFlag.Visible = false;
            pnlAllemails.Visible = false;
            pnlInbox.Visible = false;
            btnMoveInbox0.Visible = true;
           // btnCheckEmail.Visible = true;
            gvInbox.Visible = true;



        }

        protected void btnInboxEmails_Click(object sender, EventArgs e)
        {
            pnlComposeEmail.Visible = false;
            pnlSent.Visible = false;
            pnlJuck.Visible = false;
            pnlTrash.Visible = false;
            pnlFlag.Visible = false;
            pnlAllemails.Visible = false;
            pnlInbox.Visible = true;
            btnMoveInbox0.Visible = true;
            //btnCheckEmail.Visible = true;
            gvInbox.Visible = true;
            pnlCreateFolder.Visible = false;

            // code ysed to connect to a SQL server database and execute  a stored procedure
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "ShowInbox";// name of the procedure
                                                 // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
            objCommand.Parameters.AddWithValue("@inputReceivedId", int.Parse(Session["USERID"].ToString()));


            DBConnect objDB = new DBConnect();
            DataSet myDataSet;
            myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


            int size = myDataSet.Tables[0].Rows.Count;
            if (size > 0)
            {
                
                // ArrayList emailListInbox = new ArrayList();
                for (int i = 0; i < size; i++)
                {
                   
                   


                    email Email = new email();

                    Email.EmailId = int.Parse(myDataSet.Tables[0].Rows[i]["emailID"].ToString());
                    Email.SenderId = int.Parse(myDataSet.Tables[0].Rows[i]["senderId"].ToString());
                    Email.ReceivedId = int.Parse(myDataSet.Tables[0].Rows[i]["receivedId"].ToString());
                    Email.Subject = myDataSet.Tables[0].Rows[i]["subject"].ToString();
                    Email.EmailBody = myDataSet.Tables[0].Rows[i]["emailBody"].ToString();
                    Email.CreatedTime = DateTime.Parse(myDataSet.Tables[0].Rows[i]["createdTime"].ToString());
                  
                    //string createdTime;



                    emailListInbox.Add(Email);

                }
                gvInbox.DataSource = emailListInbox;
                gvInbox.DataBind();
            }
            else

                //MessageBox.Show("You dont have any mails in your inbox ");

                Response.Write("<script>alert('You dont have any mails in your inbox ')</script>");




        }

        protected void gvAllEmails_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        protected void btnTrashEmails_Click(object sender, EventArgs e)
        {
            pnlComposeEmail.Visible = false;
            pnlSent.Visible = false;
            pnlJuck.Visible = false;
            pnlTrash.Visible = true;
            pnlFlag.Visible = false;
            pnlAllemails.Visible = false;
            pnlInbox.Visible = false;
            gvTrash.Visible = true;
            pnlCreateFolder.Visible = false;
            // selectTrash

            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "ShowTrash";// name of the procedure
                                                 // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 

            objCommand.Parameters.AddWithValue("@inputSenderId", int.Parse(Session["USERID"].ToString()));
            objCommand.Parameters.AddWithValue("@inputReceivedId", int.Parse(Session["USERID"].ToString()));
            DBConnect objDB = new DBConnect();
            DataSet myDataSet;
            myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


            int size = myDataSet.Tables[0].Rows.Count;
            ArrayList emailTrashList = new ArrayList();
            if (size > 0)
            {

                for (int i = 0; i < size; i++)
                {

                    email Email = new email();

                    Email.EmailId = int.Parse(myDataSet.Tables[0].Rows[i]["emailID"].ToString());
                    Email.SenderId = int.Parse(myDataSet.Tables[0].Rows[i]["senderId"].ToString());
                    Email.ReceivedId = int.Parse(myDataSet.Tables[0].Rows[i]["receivedId"].ToString());
                    Email.Subject = myDataSet.Tables[0].Rows[i]["subject"].ToString();
                    Email.EmailBody = myDataSet.Tables[0].Rows[i]["emailBody"].ToString();
                    Email.CreatedTime = DateTime.Parse(myDataSet.Tables[0].Rows[i]["createdTime"].ToString());

                    emailTrashList.Add(Email);

                }

                gvTrash.DataSource = emailTrashList;
                gvTrash.DataBind();
            }
            else

                //   MessageBox.Show("You dont have any mails in your trash mail Box ");

                Response.Write("<script>alert('You dont have any mails in your trash mail Box ')</script>");
        }

        protected void btnJunkEmails_Click(object sender, EventArgs e)
        {
            pnlComposeEmail.Visible = false;
            pnlSent.Visible = false;
            pnlJuck.Visible = true;
            pnlTrash.Visible = false;
            pnlFlag.Visible = false;
            pnlAllemails.Visible = false;
            pnlInbox.Visible = false;
            gvJunk.Visible = true;
            btnTrashMove.Visible = true;
            btnMoveJunk.Visible = true;
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "ShowJunk";// name of the procedure
                                                // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
            objCommand.Parameters.AddWithValue("@inputReceivedId", int.Parse(Session["USERID"].ToString()));
            //objCommand.Parameters.AddWithValue("@inputSenderId", int.Parse(Session["USERID"].ToString()));


            DBConnect objDB = new DBConnect();
            DataSet myDataSet;
            myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


            int size = myDataSet.Tables[0].Rows.Count;
            if (size > 0)
            {
                // ArrayList emailListInbox = new ArrayList();
                for (int i = 0; i < size; i++)
                {
                    email Email = new email();

                    Email.EmailId = int.Parse(myDataSet.Tables[0].Rows[i]["emailID"].ToString());
                    Email.SenderId = int.Parse(myDataSet.Tables[0].Rows[i]["senderId"].ToString());
                    Email.ReceivedId = int.Parse(myDataSet.Tables[0].Rows[i]["receivedId"].ToString());
                    Email.Subject = myDataSet.Tables[0].Rows[i]["subject"].ToString();
                    Email.EmailBody = myDataSet.Tables[0].Rows[i]["emailBody"].ToString();
                    Email.CreatedTime = DateTime.Parse(myDataSet.Tables[0].Rows[i]["createdTime"].ToString());
                    //string createdTime;



                    emailListJunk.Add(Email);

                }
                gvJunk.DataSource = emailListJunk;
                gvJunk.DataBind();
            }
            else

                //   MessageBox.Show("You dont have any mails in your  junk box ");

                Response.Write("<script>alert('You dont have any mails in your  junk box  ')</script>");



            ////gvJunk.DataSource = checkedTrash;
            //gvJunk.DataBind();
        }

        protected void btnFlagEmails_Click(object sender, EventArgs e)
        {
            pnlFlag.Visible = true;
            pnlComposeEmail.Visible = false;
            pnlSent.Visible = false;
            pnlJuck.Visible = false;
            pnlTrash.Visible = false;
            pnlInbox.Visible = false;
            pnlAllemails.Visible = false;
            gvFlag.Visible = true;
            btnMoveJunk.Visible = true;
            pnlCreateFolder.Visible = false;
            pnlCreateFolder.Visible = false;

            //
            // code ysed to connect to a SQL server database and execute  a stored procedure
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "ShowFlag";// name of the procedure
                                                // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
            objCommand.Parameters.AddWithValue("@inputReceivedId", int.Parse(Session["USERID"].ToString()));
            //objCommand.Parameters.AddWithValue("@inputSenderId", int.Parse(Session["USERID"].ToString()));
            //@inputSenderId

            DBConnect objDB = new DBConnect();
            DataSet myDataSet;
            myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


            int size = myDataSet.Tables[0].Rows.Count;
            if (size > 0)
            {
                // ArrayList emailListInbox = new ArrayList();
                for (int i = 0; i < size; i++)
                {
                    email Email = new email();

                    Email.EmailId = int.Parse(myDataSet.Tables[0].Rows[i]["emailID"].ToString());
                    Email.SenderId = int.Parse(myDataSet.Tables[0].Rows[i]["senderId"].ToString());
                    Email.ReceivedId = int.Parse(myDataSet.Tables[0].Rows[i]["receivedId"].ToString());
                    Email.Subject = myDataSet.Tables[0].Rows[i]["subject"].ToString();
                    Email.EmailBody = myDataSet.Tables[0].Rows[i]["emailBody"].ToString();
                    Email.CreatedTime = DateTime.Parse(myDataSet.Tables[0].Rows[i]["createdTime"].ToString());
                    //string createdTime;



                    emailListFlag.Add(Email);

                }
                gvFlag.DataSource = emailListFlag;
                gvFlag.DataBind();
            }
            else

                //  MessageBox.Show("You dont have any mails in your  flag box ");

                Response.Write("<script>alert('You dont have any mails in your  flag box  ')</script>");





        }

        protected void btnSentEmails_Click(object sender, EventArgs e)
        {
            pnlSent.Visible = true;
            pnlComposeEmail.Visible = false;
            pnlInbox.Visible = false;
            pnlJuck.Visible = false;
            pnlTrash.Visible = false;
            pnlFlag.Visible = false;
            pnlAllemails.Visible = false;
            gvSent.Visible = true;
            btnSentMove.Visible = true;
            btnflagMove.Visible = true;
            pnlCreateFolder.Visible = false;

            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "ShowSentBox";// name of the procedure
                                                   // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
            objCommand.Parameters.AddWithValue("@inputSender", int.Parse(Session["userId"].ToString()));


            DBConnect objDB = new DBConnect();
            DataSet myDataSet;
            myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


            int size = myDataSet.Tables[0].Rows.Count;
            if (size > 0)
            {

                for (int i = 0; i < size; i++)
                {
                    email Email = new email();

                    Email.EmailId = int.Parse(myDataSet.Tables[0].Rows[i]["emailID"].ToString());
                    Email.SenderId = int.Parse(myDataSet.Tables[0].Rows[i]["senderId"].ToString());
                    Email.ReceivedId = int.Parse(myDataSet.Tables[0].Rows[i]["receivedId"].ToString());
                    Email.Subject = myDataSet.Tables[0].Rows[i]["subject"].ToString();
                    Email.EmailBody = myDataSet.Tables[0].Rows[i]["emailBody"].ToString();
                    Email.CreatedTime = DateTime.Parse(myDataSet.Tables[0].Rows[i]["createdTime"].ToString());
                    //string createdTime;



                    emailListSent.Add(Email);

                }
                gvSent.DataSource = emailListSent;
                gvSent.DataBind();
            }
            else

                // MessageBox.Show("You dont have any mails in your sent Box ");


                Response.Write("<script>alert('You dont have any mails in your  sent box  ')</script>");








        }

        protected void btnSend_Click(object sender, EventArgs e)
        {

            // use user name to get user id sp
            if (txtBoxNewEmailTo.Text==""){


                Response.Write("<script>alert('Please enter reveiver name ')</script>");

            }
            else if (txtBoxNewEmailSubject.Text=="") {
                Response.Write("<script>alert('Please enter subject ')</script>");
            }
            else if (txtBoxNewEmailContent.Text=="") {
                Response.Write("<script>alert('Please enter email body')</script>");
            }
            else {
                SqlCommand objCommand1 = new SqlCommand();
                objCommand1.CommandType = CommandType.StoredProcedure;
                objCommand1.CommandText = "GetIdByName";
                objCommand1.Parameters.AddWithValue("@inputName", txtBoxNewEmailTo.Text);
                SqlParameter outPutId = new SqlParameter("@outputId", 0);
                outPutId.Direction = ParameterDirection.Output;
                objCommand1.Parameters.Add(outPutId);

                //execute store procedure using BDConnect object and the SQLCommand Object
                DBConnect objDB1 = new DBConnect();
                objDB1.GetDataSetUsingCmdObj(objCommand1);

                int returneUserId = int.Parse(objCommand1.Parameters["@outputId"].Value.ToString());


                email createEmail = new email();

                createEmail.SenderId = int.Parse(Session["userId"].ToString());
                createEmail.ReceivedId = returneUserId;
                createEmail.Subject = txtBoxNewEmailSubject.Text;
                createEmail.EmailBody = txtBoxNewEmailContent.Text;
                createEmail.CreatedTime = DateTime.Now;

                // up date receiver table // insert a new email into all emails SendNewEmail
                // code ysed to connect to a SQL server database and execute  a stored procedure
                SqlCommand objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "SendNewEmail";// name of the procedure
                                                        // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                objCommand.Parameters.AddWithValue("@inputSender", createEmail.SenderId);
                objCommand.Parameters.AddWithValue("@inputReceiver ", createEmail.ReceivedId);
                objCommand.Parameters.AddWithValue("@inputSubject", createEmail.Subject);
                objCommand.Parameters.AddWithValue("@inputContent", createEmail.EmailBody);
                objCommand.Parameters.AddWithValue("@inputCreateTime", createEmail.CreatedTime);
                DBConnect objDB = new DBConnect();
                DataSet myDataSet;
                myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);



                //     MessageBox.Show("Your email has sent to the receiver");

                Response.Write("<script>alert('Your email has sent to the receiver ')</script>");




            }


        }

        protected void btnMoveInbox_Click(object sender, EventArgs e)
        {

            for (int row = 0; row < gvInbox.Rows.Count; row++)
            {
                int count = 0;
                CheckBox CBox;
                DropDownList ddldropD;
                CBox = (CheckBox)gvInbox.Rows[row].FindControl("ckbMove");
                ddldropD = (DropDownList)gvInbox.Rows[row].FindControl("ddlInboxMove");
                if (CBox.Checked)
                {
                    email moveEmail = new email();

                    moveEmail.EmailId = int.Parse(gvInbox.Rows[row].Cells[1].Text);
                    moveEmail.SenderId = int.Parse(gvInbox.Rows[row].Cells[2].Text);
                    moveEmail.ReceivedId = int.Parse(gvInbox.Rows[row].Cells[3].Text);
                    moveEmail.Subject = gvInbox.Rows[row].Cells[4].Text;
                    moveEmail.EmailBody = gvInbox.Rows[row].Cells[5].Text;
                    moveEmail.CreatedTime = DateTime.Parse(gvInbox.Rows[row].Cells[6].Text);
                    string destination = ddldropD.SelectedValue.ToString();
                    if (destination == "flag")
                    {

                        //InsertFlagTable
                        SqlCommand objCommand = new SqlCommand();
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.CommandText = "InsertFlagTable";// name of the procedure
                                                                   // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                        objCommand.Parameters.AddWithValue("@inputSender", moveEmail.SenderId);
                        objCommand.Parameters.AddWithValue("@inputReceiver", moveEmail.ReceivedId);
                        objCommand.Parameters.AddWithValue("@inputSubject", moveEmail.Subject);
                        objCommand.Parameters.AddWithValue("@inputContent", moveEmail.EmailBody);
                        objCommand.Parameters.AddWithValue("@inputCreateTime", moveEmail.CreatedTime);
                        DBConnect objDB = new DBConnect();
                        DataSet myDataSet;
                        myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);
                        // how to remove from inbox delect from all email
                        SqlCommand objCommand1 = new SqlCommand();
                        objCommand1.CommandType = CommandType.StoredProcedure;
                        objCommand1.CommandText = "RemoveFromInbox";// name of the procedure
                                                                    // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand1.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                        DBConnect objDB1 = new DBConnect();
                        DataSet myDataSet1;
                        myDataSet1 = objDB.GetDataSetUsingCmdObj(objCommand1);
                        count++;
                        Response.Write("<script>alert('You have moved this email to flagbox')</script>");
                        //MessageBox.Show("You have moved this email to flagbox");
                        pnlInbox.Visible = false;
                    }
                    else if (destination == "junk")
                    {

                        //InsertFlagTable
                        SqlCommand objCommand = new SqlCommand();
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.CommandText = "InsertJunkTable";// name of the procedure
                                                                   // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                        objCommand.Parameters.AddWithValue("@inputSender", moveEmail.SenderId);
                        objCommand.Parameters.AddWithValue("@inputReceiver", moveEmail.ReceivedId);
                        objCommand.Parameters.AddWithValue("@inputSubject", moveEmail.Subject);
                        objCommand.Parameters.AddWithValue("@inputContent", moveEmail.EmailBody);
                        objCommand.Parameters.AddWithValue("@inputCreateTime", moveEmail.CreatedTime);

                        DBConnect objDB = new DBConnect();
                        DataSet myDataSet;
                        myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);
                        // how to remove from inbox delect from all email
                        SqlCommand objCommand1 = new SqlCommand();
                        objCommand1.CommandType = CommandType.StoredProcedure;
                        objCommand1.CommandText = "RemoveFromInbox";// name of the procedure                                                                    // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand1.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                        DBConnect objDB1 = new DBConnect();
                        DataSet myDataSet1;
                        myDataSet1 = objDB.GetDataSetUsingCmdObj(objCommand1);
                        count++;
                        Response.Write("<script>alert('You have moved this email to junkbox')</script>");
                        //MessageBox.Show("You have moved this email to junkbox");
                        pnlInbox.Visible = false;
                    }
                    else if (destination == "trash")
                    { //InsertFlagTable
                        SqlCommand objCommand = new SqlCommand();
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.CommandText = "InsertTrashTable";// name of the procedure
                                                                    // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                        objCommand.Parameters.AddWithValue("@inputSender", moveEmail.SenderId);
                        objCommand.Parameters.AddWithValue("@inputReceiver", moveEmail.ReceivedId);
                        objCommand.Parameters.AddWithValue("@inputSubject", moveEmail.Subject);
                        objCommand.Parameters.AddWithValue("@inputContent", moveEmail.EmailBody);
                        objCommand.Parameters.AddWithValue("@inputCreateTime", moveEmail.CreatedTime);

                        DBConnect objDB = new DBConnect();
                        DataSet myDataSet;
                        myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


                        // how to remove from inbox delect from all email

                        SqlCommand objCommand1 = new SqlCommand();
                        objCommand1.CommandType = CommandType.StoredProcedure;
                        objCommand1.CommandText = "RemoveFromInbox";// name of the procedure
                                                                    // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand1.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                        DBConnect objDB1 = new DBConnect();
                        DataSet myDataSet1;
                        myDataSet1 = objDB.GetDataSetUsingCmdObj(objCommand1);
                        count++;
                        //MessageBox.Show("You have moved this email to trashbox");
                        Response.Write("<script>alert('You have moved this email to trashbox')</script>");
                        pnlInbox.Visible = false;
                    }// trash
                    else {
                        Response.Write("<script>alert('You have to select at least one destination to move')</script>");
                        //  MessageBox.Show("You have to select at least one destination to move");

                    }
                } 

            }
        }

        protected void gvSent_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnAllEmails_Click(object sender, EventArgs e)
        {
            pnlComposeEmail.Visible = false;
            pnlSent.Visible = false;
            pnlJuck.Visible = false;
            pnlTrash.Visible = false;
            pnlFlag.Visible = false;
            pnlInbox.Visible = false;
            pnlAllemails.Visible = true;
            pnlCreateFolder.Visible = false;


            // get from all the tables // allemails trash junk flag 

            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "ShowTrash";// name of the procedure
                                                 // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 

            objCommand.Parameters.AddWithValue("@inputSenderId", int.Parse(Session["USERID"].ToString()));
            objCommand.Parameters.AddWithValue("@inputReceivedId", int.Parse(Session["USERID"].ToString()));
            DBConnect objDB = new DBConnect();
            DataSet myDataSet1;
            myDataSet1 = objDB.GetDataSetUsingCmdObj(objCommand);
            int size1 = myDataSet1.Tables[0].Rows.Count;

            if (size1 > 0)
            {

                for (int i = 0; i < size1; i++)
                {

                    email Email = new email();

                    Email.EmailId = int.Parse(myDataSet1.Tables[0].Rows[i]["emailID"].ToString());
                    Email.SenderId = int.Parse(myDataSet1.Tables[0].Rows[i]["senderId"].ToString());
                    Email.ReceivedId = int.Parse(myDataSet1.Tables[0].Rows[i]["receivedId"].ToString());
                    Email.Subject = myDataSet1.Tables[0].Rows[i]["subject"].ToString();
                    Email.EmailBody = myDataSet1.Tables[0].Rows[i]["emailBody"].ToString();
                    Email.CreatedTime = DateTime.Parse(myDataSet1.Tables[0].Rows[i]["createdTime"].ToString());

                    showallemails.Add(Email);

                }
            }

            //=======================================================================================

            SqlCommand objCommandall = new SqlCommand();
            objCommandall.CommandType = CommandType.StoredProcedure;
            objCommandall.CommandText = "ShowAllEmails";// name of the procedure
                                                        // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 

            objCommandall.Parameters.AddWithValue("@inputUserboth", int.Parse(Session["USERID"].ToString()));

            DBConnect objDBall = new DBConnect();
            DataSet myDataSetall;
            myDataSetall = objDB.GetDataSetUsingCmdObj(objCommandall);


            int sizeall = myDataSetall.Tables[0].Rows.Count;

            if (sizeall > 0)
            {

                for (int i = 0; i < sizeall; i++)
                {

                    email Email = new email();

                    Email.EmailId = int.Parse(myDataSetall.Tables[0].Rows[i]["emailID"].ToString());
                    Email.SenderId = int.Parse(myDataSetall.Tables[0].Rows[i]["senderId"].ToString());
                    Email.ReceivedId = int.Parse(myDataSetall.Tables[0].Rows[i]["receivedId"].ToString());
                    Email.Subject = myDataSetall.Tables[0].Rows[i]["subject"].ToString();
                    Email.EmailBody = myDataSetall.Tables[0].Rows[i]["emailBody"].ToString();
                    Email.CreatedTime = DateTime.Parse(myDataSetall.Tables[0].Rows[i]["createdTime"].ToString());

                    showallemails.Add(Email);
                }
            }
            //====================================================================================================
            SqlCommand objCommandjunk = new SqlCommand();
            objCommandjunk.CommandType = CommandType.StoredProcedure;
            objCommandjunk.CommandText = "ShowJunk";// name of the procedure
                                                    // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
            objCommandjunk.Parameters.AddWithValue("@inputReceivedId", int.Parse(Session["USERID"].ToString()));
          //  objCommandjunk.Parameters.AddWithValue("@inputSenderId", int.Parse(Session["USERID"].ToString()));


            DBConnect objDBjunk = new DBConnect();
            DataSet myDataSetjunk;
            myDataSetjunk = objDB.GetDataSetUsingCmdObj(objCommandjunk);


            int sizejunk = myDataSetjunk.Tables[0].Rows.Count;
            if (sizejunk > 0)
            {

                for (int i = 0; i < sizejunk; i++)
                {
                    email Email = new email();

                    Email.EmailId = int.Parse(myDataSetjunk.Tables[0].Rows[i]["emailID"].ToString());
                    Email.SenderId = int.Parse(myDataSetjunk.Tables[0].Rows[i]["senderId"].ToString());
                    Email.ReceivedId = int.Parse(myDataSetjunk.Tables[0].Rows[i]["receivedId"].ToString());
                    Email.Subject = myDataSetjunk.Tables[0].Rows[i]["subject"].ToString();
                    Email.EmailBody = myDataSetjunk.Tables[0].Rows[i]["emailBody"].ToString();
                    Email.CreatedTime = DateTime.Parse(myDataSetjunk.Tables[0].Rows[i]["createdTime"].ToString());

                    showallemails.Add(Email);

                }
            }//====================================================================================
            SqlCommand objCommandflag = new SqlCommand();
            objCommandflag.CommandType = CommandType.StoredProcedure;
            objCommandflag.CommandText = "ShowFlag";// name of the procedure
                                                    // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
            objCommandflag.Parameters.AddWithValue("@inputReceivedId", int.Parse(Session["USERID"].ToString()));


            DBConnect objDBflag = new DBConnect();
            DataSet myDataSetflag;
            myDataSetflag = objDBflag.GetDataSetUsingCmdObj(objCommandflag);


            int size = myDataSetflag.Tables[0].Rows.Count;
            if (size > 0)
            {
                // ArrayList emailListInbox = new ArrayList();
                for (int i = 0; i < size; i++)
                {
                    email Email = new email();

                    Email.EmailId = int.Parse(myDataSetflag.Tables[0].Rows[i]["emailID"].ToString());
                    Email.SenderId = int.Parse(myDataSetflag.Tables[0].Rows[i]["senderId"].ToString());
                    Email.ReceivedId = int.Parse(myDataSetflag.Tables[0].Rows[i]["receivedId"].ToString());
                    Email.Subject = myDataSetflag.Tables[0].Rows[i]["subject"].ToString();
                    Email.EmailBody = myDataSetflag.Tables[0].Rows[i]["emailBody"].ToString();
                    Email.CreatedTime = DateTime.Parse(myDataSetflag.Tables[0].Rows[i]["createdTime"].ToString());

                    showallemails.Add(Email);

                }

            }
            //=======================================================================================
            gvAllEmails.DataSource = showallemails;
            gvAllEmails.DataBind();

        }
        protected void btnMoveAll_Click(object sender, EventArgs e)
        {
            ArrayList checkedList = new ArrayList();
            // find checked email 
            for (int row = 0; row < gvInbox.Rows.Count; row++)
            {


                CheckBox CBox;
                DropDownList ddldropD;

                CBox = (CheckBox)gvAllEmails.Rows[row].FindControl("ckbAllEmails");
                ddldropD = (DropDownList)gvAllEmails.Rows[row].FindControl("ddlALLmove");


                if (CBox.Checked)
                {
                    string destination = ddldropD.SelectedValue.ToString();

                    email checkedEmail = new email();

                    checkedEmail.EmailId = int.Parse(gvAllEmails.Rows[row].Cells[1].Text);
                    checkedEmail.SenderId = int.Parse(gvAllEmails.Rows[row].Cells[2].Text);
                    checkedEmail.ReceivedId = int.Parse(gvAllEmails.Rows[row].Cells[3].Text);
                    checkedEmail.Subject = gvAllEmails.Rows[row].Cells[4].Text;
                    checkedEmail.EmailBody = gvAllEmails.Rows[row].Cells[5].Text;
                    //    checkedEmail.CreatedTime = gvAllEmails.Rows[row].Cells[6].Text;
                    checkedList.Add(checkedEmail);



                    if (destination == "flag")
                    {

                        //checkedFlag.Add(moveEmail);
                        //emailList.Remove(moveEmail);


                    }
                    else if (destination == "junk")
                    {
                        //checkedJunk.Add(moveEmail);




                    }
                    else if (destination == "trash")
                    {


                        // update trash table 


                        SqlCommand objCommand = new SqlCommand();
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.CommandText = "updateTrash";// name of the procedure
                                                               // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand.Parameters.AddWithValue("@inputEmailId", int.Parse(gvAllEmails.Rows[row].Cells[1].Text));
                        objCommand.Parameters.AddWithValue("@inputSenderId", int.Parse(gvAllEmails.Rows[row].Cells[2].Text));
                        objCommand.Parameters.AddWithValue("@inputReceivedId", int.Parse(gvAllEmails.Rows[row].Cells[3].Text));
                        objCommand.Parameters.AddWithValue("@inputSubject", gvAllEmails.Rows[row].Cells[4].Text);
                        objCommand.Parameters.AddWithValue("@inputEmailBody", gvAllEmails.Rows[row].Cells[5].Text);
                        objCommand.Parameters.AddWithValue("@inputCreatedTime", int.Parse(gvAllEmails.Rows[row].Cells[6].Text));
                        DBConnect objDB = new DBConnect();
                        DataSet myDataSet;
                        myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);

                        // remove this mail on the table 

                        // delAfterMoveAllEmail

                        SqlCommand objCommand1 = new SqlCommand();
                        objCommand1.CommandType = CommandType.StoredProcedure;
                        objCommand1.CommandText = "delAfterMoveAllEmail";// name of the procedure
                                                                         // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand1.Parameters.AddWithValue("@inputEmailId", int.Parse(gvAllEmails.Rows[row].Cells[1].Text));

                        DBConnect objDB1 = new DBConnect();
                        DataSet myDataSet1;
                        myDataSet1 = objDB1.GetDataSetUsingCmdObj(objCommand1);
                    }
                }
            }
        }

        protected void btnUserLogOff_Click(object sender, EventArgs e)
        {
            Response.Redirect("LogIn.aspx");
        }

        protected void btnsentMove_Click(object sender, EventArgs e)
        {

            for (int row = 0; row < gvSent.Rows.Count; row++)
            {

                CheckBox CBox;
                DropDownList ddldropD;

                CBox = (CheckBox)gvSent.Rows[row].FindControl("ckbSent");
                ddldropD = (DropDownList)gvSent.Rows[row].FindControl("ddlSentMove");


                if (CBox.Checked)
                {


                    email moveEmail = new email();

                    moveEmail.EmailId = int.Parse(gvSent.Rows[row].Cells[1].Text);
                    moveEmail.SenderId = int.Parse(gvSent.Rows[row].Cells[2].Text);
                    moveEmail.ReceivedId = int.Parse(gvSent.Rows[row].Cells[3].Text);
                    moveEmail.Subject = gvSent.Rows[row].Cells[4].Text;
                    moveEmail.EmailBody = gvSent.Rows[row].Cells[5].Text;
                    moveEmail.CreatedTime = DateTime.Parse(gvSent.Rows[row].Cells[6].Text);



                    string destination = ddldropD.SelectedValue.ToString();
                    if (destination == "trash")
                    {
                        SqlCommand objCommand = new SqlCommand();
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.CommandText = "InsertTrashTable";// name of the procedure
                                                                    // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                        objCommand.Parameters.AddWithValue("@inputSender", moveEmail.SenderId);
                        objCommand.Parameters.AddWithValue("@inputReceiver", moveEmail.ReceivedId);
                        objCommand.Parameters.AddWithValue("@inputSubject", moveEmail.Subject);
                        objCommand.Parameters.AddWithValue("@inputContent", moveEmail.EmailBody);
                        objCommand.Parameters.AddWithValue("@inputCreateTime", moveEmail.CreatedTime);

                        DBConnect objDB = new DBConnect();
                        DataSet myDataSet;
                        myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);




                        // how to remove from inbox delect from all email

                        SqlCommand objCommand1 = new SqlCommand();
                        objCommand1.CommandType = CommandType.StoredProcedure;
                        objCommand1.CommandText = "RemoveFromSentbox";// name of the procedure
                                                                      // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand1.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);



                        DBConnect objDB1 = new DBConnect();
                        DataSet myDataSet1;
                        myDataSet1 = objDB.GetDataSetUsingCmdObj(objCommand1);

                        Response.Write("<script>alert('You have moved this email to Trashbox')</script>");
                        // MessageBox.Show("You have moved this email to Trashbox");
                        pnlSent.Visible = false;
                    }
                    else
                    {
                        Response.Write("<script>alert('You have to select at least one destination to move')</script>");
                     //   MessageBox.Show("You have to select at least one destination to move");

                    }


                }
            }
        }

        protected void btnMoveFlag_Click(object sender, EventArgs e)
        {
            btnflagMove.Visible = true;
            for (int row = 0; row < gvFlag.Rows.Count; row++)
            {

                CheckBox CBox;
                DropDownList ddldropD;

                CBox = (CheckBox)gvFlag.Rows[row].FindControl("ckbFlag");
                ddldropD = (DropDownList)gvFlag.Rows[row].FindControl("ddlFlag");


                if (CBox.Checked)
                {


                    email moveEmail = new email();

                    moveEmail.EmailId = int.Parse(gvFlag.Rows[row].Cells[1].Text);
                    moveEmail.SenderId = int.Parse(gvFlag.Rows[row].Cells[2].Text);
                    moveEmail.ReceivedId = int.Parse(gvFlag.Rows[row].Cells[3].Text);
                    moveEmail.Subject = gvFlag.Rows[row].Cells[4].Text;
                    moveEmail.EmailBody = gvFlag.Rows[row].Cells[5].Text;
                    moveEmail.CreatedTime = DateTime.Parse(gvFlag.Rows[row].Cells[6].Text);



                    string destination = ddldropD.SelectedValue.ToString();
           
                    if (destination == "junk")
                    {

                        //InsertFlagTable
                        SqlCommand objCommand = new SqlCommand();
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.CommandText = "InsertJunkTable";// name of the procedure
                                                                   // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                        objCommand.Parameters.AddWithValue("@inputSender", moveEmail.SenderId);
                        objCommand.Parameters.AddWithValue("@inputReceiver", moveEmail.ReceivedId);
                        objCommand.Parameters.AddWithValue("@inputSubject", moveEmail.Subject);
                        objCommand.Parameters.AddWithValue("@inputContent", moveEmail.EmailBody);
                        objCommand.Parameters.AddWithValue("@inputCreateTime", moveEmail.CreatedTime);

                        DBConnect objDB = new DBConnect();
                        DataSet myDataSet;
                        myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


                        // how to remove from inbox delect from all email

                        SqlCommand objCommand1 = new SqlCommand();
                        objCommand1.CommandType = CommandType.StoredProcedure;
                        objCommand1.CommandText = "RemoveFromFlagbox";// name of the procedure
                                                                      // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand1.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);



                        DBConnect objDB1 = new DBConnect();
                        DataSet myDataSet1;
                        myDataSet1 = objDB.GetDataSetUsingCmdObj(objCommand1);



                        Response.Write("<script>alert('You have moved this email to junk box')</script>");
                        //MessageBox.Show("You have moved this email to junk box");


                        pnlFlag.Visible = false;



                    }
                    else if (destination == "trash")
                    {


                        SqlCommand objCommand = new SqlCommand();
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.CommandText = "InsertTrashTable";// name of the procedure
                                                                    // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                        objCommand.Parameters.AddWithValue("@inputSender", moveEmail.SenderId);
                        objCommand.Parameters.AddWithValue("@inputReceiver", moveEmail.ReceivedId);
                        objCommand.Parameters.AddWithValue("@inputSubject", moveEmail.Subject);
                        objCommand.Parameters.AddWithValue("@inputContent", moveEmail.EmailBody);
                        objCommand.Parameters.AddWithValue("@inputCreateTime", moveEmail.CreatedTime);

                        DBConnect objDB = new DBConnect();
                        DataSet myDataSet;
                        myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


                        // how to remove from inbox delect from all email

                        SqlCommand objCommand1 = new SqlCommand();
                        objCommand1.CommandType = CommandType.StoredProcedure;
                        objCommand1.CommandText = "RemoveFromFlagbox";// name of the procedure
                                                                      // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand1.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);



                        DBConnect objDB1 = new DBConnect();
                        DataSet myDataSet1;
                        myDataSet1 = objDB.GetDataSetUsingCmdObj(objCommand1);
                        //MessageBox.Show("You have moved this email to trashbox");
                        Response.Write("<script>alert('You have moved this email to trashbox')</script>");
                        pnlFlag.Visible = false;
                    }// trash


                    else
                    {

                        //   MessageBox.Show("You have to select at least one destination to move");
                        Response.Write("<script>alert('You have to select at least one destination to move')</script>");
                    }



                }

            }
        }

        protected void btnMoveJunk_Click(object sender, EventArgs e)
        {
            for (int row = 0; row < gvJunk.Rows.Count; row++)
            {

                CheckBox CBox;
                DropDownList ddldropD;

                CBox = (CheckBox)gvJunk.Rows[row].FindControl("ckJunk");
                ddldropD = (DropDownList)gvJunk.Rows[row].FindControl("ddlJunk");


                if (CBox.Checked)
                {


                    email moveEmail = new email();

                    moveEmail.EmailId = int.Parse(gvJunk.Rows[row].Cells[1].Text);
                    moveEmail.SenderId = int.Parse(gvJunk.Rows[row].Cells[2].Text);
                    moveEmail.ReceivedId = int.Parse(gvJunk.Rows[row].Cells[3].Text);
                    moveEmail.Subject = gvJunk.Rows[row].Cells[4].Text;
                    moveEmail.EmailBody = gvJunk.Rows[row].Cells[5].Text;
                    moveEmail.CreatedTime = DateTime.Parse(gvJunk.Rows[row].Cells[6].Text);



                    string destination = ddldropD.SelectedValue.ToString();
                    if (destination == "flag")
                    {
                      
                        //InsertFlagTable
                        {
                            SqlCommand objCommand = new SqlCommand();
                            objCommand.CommandType = CommandType.StoredProcedure;
                            objCommand.CommandText = "InsertFlagTable";// name of the procedure
                                                                       // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                            objCommand.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                            objCommand.Parameters.AddWithValue("@inputSender", moveEmail.SenderId);
                            objCommand.Parameters.AddWithValue("@inputReceiver", moveEmail.ReceivedId);
                            objCommand.Parameters.AddWithValue("@inputSubject", moveEmail.Subject);
                            objCommand.Parameters.AddWithValue("@inputContent", moveEmail.EmailBody);
                            objCommand.Parameters.AddWithValue("@inputCreateTime", moveEmail.CreatedTime);

                            DBConnect objDB = new DBConnect();
                            DataSet myDataSet;
                            myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


                            // how to remove from inbox delect from all email

                            SqlCommand objCommand1 = new SqlCommand();
                            objCommand1.CommandType = CommandType.StoredProcedure;
                            objCommand1.CommandText = "RemoveFromJunkEmails";// name of the procedure
                                                                             // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                            objCommand1.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);



                            DBConnect objDB1 = new DBConnect();
                            DataSet myDataSet1;
                            myDataSet1 = objDB.GetDataSetUsingCmdObj(objCommand1);
                            // MessageBox.Show("You have moved this email to flag box");
                            Response.Write("<script>alert('You have moved this email to flag box')</script>");
                            pnlJuck.Visible = false;
                        }
                    }
                    else if (destination == "trash")
                    {

                        //InsertFlagTable
                        SqlCommand objCommand = new SqlCommand();
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.CommandText = "InsertTrashTable";// name of the procedure
                                                                    // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                        objCommand.Parameters.AddWithValue("@inputSender", moveEmail.SenderId);
                        objCommand.Parameters.AddWithValue("@inputReceiver", moveEmail.ReceivedId);
                        objCommand.Parameters.AddWithValue("@inputSubject", moveEmail.Subject);
                        objCommand.Parameters.AddWithValue("@inputContent", moveEmail.EmailBody);
                        objCommand.Parameters.AddWithValue("@inputCreateTime", moveEmail.CreatedTime);

                        DBConnect objDB = new DBConnect();
                        DataSet myDataSet;
                        myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


                        // how to remove from inbox delect from all email

                        SqlCommand objCommand1 = new SqlCommand();
                        objCommand1.CommandType = CommandType.StoredProcedure;
                        objCommand1.CommandText = "RemoveFromJunkEmails";// name of the procedure
                                                                         // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand1.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);



                        DBConnect objDB1 = new DBConnect();
                        DataSet myDataSet1;
                        myDataSet1 = objDB.GetDataSetUsingCmdObj(objCommand1);
                        // MessageBox.Show("You have moved this email to tash box");
                        Response.Write("<script>alert('You have moved this email to tash box')</script>");
                        pnlJuck.Visible = false;
                    }

                     else {

                        // MessageBox.Show("You have to select at least one destination to move");
                        Response.Write("<script>alert('You have to select at least one destination to move')</script>");
                    }


                }
            }
        }

        protected void btnMoveTrash_Click(object sender, EventArgs e)
        {


            for (int row = 0; row < gvTrash.Rows.Count; row++)
            {

                CheckBox CBox;
                DropDownList ddldropD;

                CBox = (CheckBox)gvTrash.Rows[row].FindControl("ckbTrash");
                ddldropD = (DropDownList)gvTrash.Rows[row].FindControl("ddlTrash");


                if (CBox.Checked)
                {


                    email moveEmail = new email();

                    moveEmail.EmailId = int.Parse(gvTrash.Rows[row].Cells[1].Text);
                    moveEmail.SenderId = int.Parse(gvTrash.Rows[row].Cells[2].Text);
                    moveEmail.ReceivedId = int.Parse(gvTrash.Rows[row].Cells[6].Text);
                    moveEmail.Subject = gvTrash.Rows[row].Cells[3].Text;
                    moveEmail.EmailBody = gvTrash.Rows[row].Cells[4].Text;
                    moveEmail.CreatedTime = DateTime.Parse(gvTrash.Rows[row].Cells[5].Text);



                    string destination = ddldropD.SelectedValue.ToString();
                    if (destination == "flag")
                    {
                        if (moveEmail.SenderId == currentUserId)
                        {

                            //   MessageBox.Show(" You can't flag your email that you sent ");
                            Response.Write("<script>alert('You can't flag your email that you sent ')</script>");

                        }
                        else
                        //InsertFlagTable
                        {
                            SqlCommand objCommand = new SqlCommand();
                            objCommand.CommandType = CommandType.StoredProcedure;
                            objCommand.CommandText = "InsertFlagTable";// name of the procedure
                                                                       // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                            objCommand.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                            objCommand.Parameters.AddWithValue("@inputSender", moveEmail.SenderId);
                            objCommand.Parameters.AddWithValue("@inputReceiver", moveEmail.ReceivedId);
                            objCommand.Parameters.AddWithValue("@inputSubject", moveEmail.Subject);
                            objCommand.Parameters.AddWithValue("@inputContent", moveEmail.EmailBody);
                            objCommand.Parameters.AddWithValue("@inputCreateTime", moveEmail.CreatedTime);

                            DBConnect objDB = new DBConnect();
                            DataSet myDataSet;
                            myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


                            // how to remove from inbox delect from all email

                            SqlCommand objCommand1 = new SqlCommand();
                            objCommand1.CommandType = CommandType.StoredProcedure;
                            objCommand1.CommandText = "RemoveFromTrashemails";// name of the procedure
                                                                              // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                            objCommand1.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);



                            DBConnect objDB1 = new DBConnect();
                            DataSet myDataSet1;
                            myDataSet1 = objDB.GetDataSetUsingCmdObj(objCommand1);
                            //MessageBox.Show("You have moved this email to flag box");
                            Response.Write("<script>alert('You have moved this email to flag box ')</script>");
                            pnlTrash.Visible = false;
                        }
                    }
                    else if (destination == "junk")
                    {

                        //InsertFlagTable
                        SqlCommand objCommand = new SqlCommand();
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.CommandText = "InsertJunkTable";// name of the procedure
                                                                   // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);
                        objCommand.Parameters.AddWithValue("@inputSender", moveEmail.SenderId);
                        objCommand.Parameters.AddWithValue("@inputReceiver", moveEmail.ReceivedId);
                        objCommand.Parameters.AddWithValue("@inputSubject", moveEmail.Subject);
                        objCommand.Parameters.AddWithValue("@inputContent", moveEmail.EmailBody);
                        objCommand.Parameters.AddWithValue("@inputCreateTime", moveEmail.CreatedTime);

                        DBConnect objDB = new DBConnect();
                        DataSet myDataSet;
                        myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


                        // how to remove from inbox delect from all email

                        SqlCommand objCommand1 = new SqlCommand();
                        objCommand1.CommandType = CommandType.StoredProcedure;
                        objCommand1.CommandText = "RemoveFromTrashemails";// name of the procedure
                                                                          // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                        objCommand1.Parameters.AddWithValue("@inputEmailId", moveEmail.EmailId);



                        DBConnect objDB1 = new DBConnect();
                        DataSet myDataSet1;
                        myDataSet1 = objDB.GetDataSetUsingCmdObj(objCommand1);
                        //MessageBox.Show("You have moved this email to junk box");
                        Response.Write("<script>alert('You have moved this email to junk box')</script>");
                        pnlTrash.Visible = false;
                    }
                    else
                    {

                        // MessageBox.Show("You have to select at least one destination to move");
                        Response.Write("<script>alert('You have to select at least one destination to move')</script>");
                    }


                }




            }
        }

        protected void btnCheckEmail_Click(object sender, EventArgs e)
        {
            // only one email alow to be select at once 
        }



        protected void btnSearch_Click(object sender, EventArgs e)
        {











        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        protected void btnSearchGo_Click(object sender, EventArgs e)


        {
            string searchSelected = ddlSearch.SelectedValue.ToString();


            if (txtBoxSearch.Text == "") {

                Response.Write("<script>alert('Please enter the content you wish to search for')</script>");

                //   MessageBox.Show("Please enter the content you wish to search for ");

            }
           
           else if (searchSelected == "sender")
            {
                //================================================================================
                // getid by name 
                pnlInbox.Visible = false;
                btnMoveInbox0.Visible = false;
                pnlSent.Visible = false;
                btnSentMove.Visible = false;
                pnlJuck.Visible = false;
                btnMoveJunk.Visible = false;
                pnlFlag.Visible = false;
                btnflagMove.Visible = false;
                pnlTrash.Visible = false;
                btnTrashMove.Visible = false;
                
                lblShowBySender.Visible = true;
                lblShowBySender.Text = "Folder Location: Inbox";

                SqlCommand objCommand1 = new SqlCommand();
                objCommand1.CommandType = CommandType.StoredProcedure;
                objCommand1.CommandText = "GetIdByName";
                objCommand1.Parameters.AddWithValue("@inputName", txtBoxSearch.Text);
                SqlParameter outPutId = new SqlParameter("@outputId", 0);
                outPutId.Direction = ParameterDirection.Output;
                objCommand1.Parameters.Add(outPutId);

                //execute store procedure using BDConnect object and the SQLCommand Object
                DBConnect objDB1 = new DBConnect();
                objDB1.GetDataSetUsingCmdObj(objCommand1);

                int returneUserId = int.Parse(objCommand1.Parameters["@outputId"].Value.ToString());
                ////////////////////////////////////===========================================
                SqlCommand objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "GetEmailBySenderInbox";// name of the procedure
                                                                 // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                objCommand.Parameters.AddWithValue("@inputSenderId", returneUserId);


                DBConnect objDB = new DBConnect();
                DataSet myDataSet;
                myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);
                gvShowSearch.DataSource = myDataSet;
                gvShowSearch.DataBind();
                //======================================
                lblshowByFlag.Visible = true;
                lblshowByFlag.Text = "Folder Location: Flag";
                SqlCommand objCommandflag = new SqlCommand();
                objCommandflag.CommandType = CommandType.StoredProcedure;
                objCommandflag.CommandText = "GetEmailBySenderFlag";// name of the procedure
                                                                    // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                objCommandflag.Parameters.AddWithValue("@inputSenderId", returneUserId);


                DBConnect objDBflag = new DBConnect();
                DataSet myDataSetflag;
                myDataSetflag = objDBflag.GetDataSetUsingCmdObj(objCommandflag);
                gvShowSearchFlag.DataSource = myDataSetflag;
                gvShowSearchFlag.DataBind();
                ///////////////////////////////////////
                lblShowByJunk.Visible = true;
                lblShowByJunk.Text = "Folder Location : Junk";
                SqlCommand objCommandjunk = new SqlCommand();
                objCommandjunk.CommandType = CommandType.StoredProcedure;
                objCommandjunk.CommandText = "GetEmailBySenderJunk";// name of the procedure
                                                                    // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                objCommandjunk.Parameters.AddWithValue("@inputSenderId", returneUserId);


                DBConnect objDBjunk = new DBConnect();
                DataSet myDataSetjunk;
                myDataSetjunk = objDBflag.GetDataSetUsingCmdObj(objCommandjunk);
                gvShowSearchJunk.DataSource = myDataSetjunk;
                gvShowSearchJunk.DataBind();

                //==================

                lblShowByTrash.Visible = true;
                lblShowByTrash.Text = "Folder Location : Trash ";
                SqlCommand objCommandtrash = new SqlCommand();
                objCommandtrash.CommandType = CommandType.StoredProcedure;
                objCommandtrash.CommandText = "GetEmailBySenderTrash";// name of the procedure
                                                                      // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                objCommandtrash.Parameters.AddWithValue("@inputSenderId", returneUserId);


                DBConnect objDBtrash = new DBConnect();
                DataSet myDataSettrash;
                myDataSettrash = objDBflag.GetDataSetUsingCmdObj(objCommandtrash);
                gvShowSearchTrash.DataSource = myDataSettrash;
                gvShowSearchTrash.DataBind();
            }
            else if (searchSelected == "subject")
            {
                pnlInbox.Visible = false;
                btnMoveInbox0.Visible = false;
                pnlSent.Visible = false;
                btnSentMove.Visible = false;
                pnlJuck.Visible = false;
                btnMoveJunk.Visible = false;
                pnlFlag.Visible = false;
                btnflagMove.Visible = false;
                pnlTrash.Visible = false;
                btnTrashMove.Visible = false;
                pnlSearchBySender.Visible = false;
                ArrayList searchSubjectList = new ArrayList();
                //in&send box 
                //// code ysed to connect to a SQL server database and execute  a stored procedure
                SqlCommand objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "GetSearchBySubjectFromInboxSentBox";// name of the procedure
                                                                              // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                objCommand.Parameters.AddWithValue("@inputSubject", txtBoxSearch.Text);


                DBConnect objDB = new DBConnect();
                DataSet myDataSet;
                myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


                int size = myDataSet.Tables[0].Rows.Count;
                if (size > 0)
                {
                    // ArrayList emailListInbox = new ArrayList();
                    for (int i = 0; i < size; i++)
                    {
          
              email Email = new email();

                        Email.EmailId = int.Parse(myDataSet.Tables[0].Rows[i]["emailID"].ToString());
                        Email.SenderId = int.Parse(myDataSet.Tables[0].Rows[i]["senderId"].ToString());
                        Email.ReceivedId = int.Parse(myDataSet.Tables[0].Rows[i]["receivedId"].ToString());
                        Email.Subject = myDataSet.Tables[0].Rows[i]["subject"].ToString();
                        Email.EmailBody = myDataSet.Tables[0].Rows[i]["emailBody"].ToString();
                        Email.CreatedTime = DateTime.Parse(myDataSet.Tables[0].Rows[i]["createdTime"].ToString());
                        //string createdTime;



                        searchSubjectList.Add(Email);
                    }
                }
                ////// flag
                SqlCommand objCommandf = new SqlCommand();
                objCommandf.CommandType = CommandType.StoredProcedure;
                objCommandf.CommandText = "GetSearchBySubjectFromFlag";// name of the procedure
                                                                       // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                objCommandf.Parameters.AddWithValue("@inputSubject", txtBoxSearch.Text);


                DBConnect objDBf = new DBConnect();
                DataSet myDataSetf;
                myDataSetf = objDB.GetDataSetUsingCmdObj(objCommandf);


                int sizef = myDataSetf.Tables[0].Rows.Count;
                if (sizef > 0)
                {
                    // ArrayList emailListInbox = new ArrayList();
                    for (int i = 0; i < sizef; i++)
                    {
                        email Email = new email();

                        Email.EmailId = int.Parse(myDataSetf.Tables[0].Rows[i]["emailID"].ToString());
                        Email.SenderId = int.Parse(myDataSetf.Tables[0].Rows[i]["senderId"].ToString());
                        Email.ReceivedId = int.Parse(myDataSetf.Tables[0].Rows[i]["receivedId"].ToString());
                        Email.Subject = myDataSetf.Tables[0].Rows[i]["subject"].ToString();
                        Email.EmailBody = myDataSetf.Tables[0].Rows[i]["emailBody"].ToString();
                        Email.CreatedTime = DateTime.Parse(myDataSetf.Tables[0].Rows[i]["createdTime"].ToString());
                        //string createdTime;



                        searchSubjectList.Add(Email);
                    }
                }

                //// junk
                SqlCommand objCommandj = new SqlCommand();
                objCommandj.CommandType = CommandType.StoredProcedure;
                objCommandj.CommandText = "GetSearchBySubjectFromJunk";// name of the procedure
                                                                       // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                objCommandj.Parameters.AddWithValue("@inputSubject", txtBoxSearch.Text);


                DBConnect objDBj = new DBConnect();
                DataSet myDataSetj;
                myDataSetj = objDB.GetDataSetUsingCmdObj(objCommandj);


                int sizej = myDataSetj.Tables[0].Rows.Count;
                if (sizej > 0)
                {
                    // ArrayList emailListInbox = new ArrayList();
                    for (int i = 0; i < sizej; i++)
                    {
                        email Email = new email();

                        Email.EmailId = int.Parse(myDataSetj.Tables[0].Rows[i]["emailID"].ToString());
                        Email.SenderId = int.Parse(myDataSetj.Tables[0].Rows[i]["senderId"].ToString());
                        Email.ReceivedId = int.Parse(myDataSetj.Tables[0].Rows[i]["receivedId"].ToString());
                        Email.Subject = myDataSetj.Tables[0].Rows[i]["subject"].ToString();
                        Email.EmailBody = myDataSetj.Tables[0].Rows[i]["emailBody"].ToString();
                        Email.CreatedTime = DateTime.Parse(myDataSetj.Tables[0].Rows[i]["createdTime"].ToString());
                        //string createdTime;



                        searchSubjectList.Add(Email);
                    }
                }
                // trash
                SqlCommand objCommandt = new SqlCommand();
                objCommandt.CommandType = CommandType.StoredProcedure;
                objCommandt.CommandText = "GetSearchBySubjectFromTrash";// name of the procedure
                                                                        // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                objCommandt.Parameters.AddWithValue("@inputSubject", txtBoxSearch.Text);


                DBConnect objDBt = new DBConnect();
                DataSet myDataSett;
                myDataSett = objDB.GetDataSetUsingCmdObj(objCommandt);


                int sizet = myDataSett.Tables[0].Rows.Count;
                if (sizet > 0)
                {
                    // ArrayList emailListInbox = new ArrayList();
                    for (int i = 0; i < sizet; i++)
                    {
                        email Email = new email();

                        Email.EmailId = int.Parse(myDataSett.Tables[0].Rows[i]["emailID"].ToString());
                        Email.SenderId = int.Parse(myDataSett.Tables[0].Rows[i]["senderId"].ToString());
                        Email.ReceivedId = int.Parse(myDataSett.Tables[0].Rows[i]["receivedId"].ToString());
                        Email.Subject = myDataSett.Tables[0].Rows[i]["subject"].ToString();
                        Email.EmailBody = myDataSett.Tables[0].Rows[i]["emailBody"].ToString();
                        Email.CreatedTime = DateTime.Parse(myDataSett.Tables[0].Rows[i]["createdTime"].ToString());
                        //string createdTime;



                        searchSubjectList.Add(Email);
                    }
                }




                gvShowSearchSubject.DataSource = searchSubjectList;
                gvShowSearchSubject.DataBind();

            }

            else if (searchSelected == "date") {
                pnlInbox.Visible = false;
                btnMoveInbox0.Visible = false;
                pnlSent.Visible = false;
                btnSentMove.Visible = false;
                pnlJuck.Visible = false;
                btnMoveJunk.Visible = false;
                pnlFlag.Visible = false;
                btnflagMove.Visible = false;
                pnlTrash.Visible = false;
                btnTrashMove.Visible = false;
                pnlSearchBySender.Visible = false;
                DateTime date;

                if (!(DateTime.TryParse(txtBoxSearch.Text, out date))) {


                    MessageBox.Show("Please enter corret date format: MM/DD/YYYY ");
                }

                else {
                    DateTime searchDate = DateTime.Parse(txtBoxSearch.Text);
                    ArrayList searchDateList = new ArrayList();
                    //in&send box 
                    //// code ysed to connect to a SQL server database and execute  a stored procedure
                    SqlCommand objCommand = new SqlCommand();
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.CommandText = "GetSearchByDateFromInboxSentBox";// name of the procedure
                                                                               // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                    objCommand.Parameters.AddWithValue("@inputDate", searchDate);


                    DBConnect objDB = new DBConnect();
                    DataSet myDataSet;
                    myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);


                    int size = myDataSet.Tables[0].Rows.Count;
                    if (size > 0)
                    {
                        // ArrayList emailListInbox = new ArrayList();
                        for (int i = 0; i < size; i++)
                        {
                            email Email = new email();

                            Email.EmailId = int.Parse(myDataSet.Tables[0].Rows[i]["emailID"].ToString());
                            Email.SenderId = int.Parse(myDataSet.Tables[0].Rows[i]["senderId"].ToString());
                            Email.ReceivedId = int.Parse(myDataSet.Tables[0].Rows[i]["receivedId"].ToString());
                            Email.Subject = myDataSet.Tables[0].Rows[i]["subject"].ToString();
                            Email.EmailBody = myDataSet.Tables[0].Rows[i]["emailBody"].ToString();
                            Email.CreatedTime = DateTime.Parse(myDataSet.Tables[0].Rows[i]["createdTime"].ToString());
                            //string createdTime;



                            searchDateList.Add(Email);
                        }
                    }
                    ////// flag
                    SqlCommand objCommandf = new SqlCommand();
                    objCommandf.CommandType = CommandType.StoredProcedure;
                    objCommandf.CommandText = "GetSearchByDateFromFlag";// name of the procedure
                                                                        // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                    objCommandf.Parameters.AddWithValue("@inputDate", searchDate);


                    DBConnect objDBf = new DBConnect();
                    DataSet myDataSetf;
                    myDataSetf = objDB.GetDataSetUsingCmdObj(objCommandf);


                    int sizef = myDataSetf.Tables[0].Rows.Count;
                    if (sizef > 0)
                    {
                        // ArrayList emailListInbox = new ArrayList();
                        for (int i = 0; i < sizef; i++)
                        {
                            email Email = new email();

                            Email.EmailId = int.Parse(myDataSetf.Tables[0].Rows[i]["emailID"].ToString());
                            Email.SenderId = int.Parse(myDataSetf.Tables[0].Rows[i]["senderId"].ToString());
                            Email.ReceivedId = int.Parse(myDataSetf.Tables[0].Rows[i]["receivedId"].ToString());
                            Email.Subject = myDataSetf.Tables[0].Rows[i]["subject"].ToString();
                            Email.EmailBody = myDataSetf.Tables[0].Rows[i]["emailBody"].ToString();
                            Email.CreatedTime = DateTime.Parse(myDataSetf.Tables[0].Rows[i]["createdTime"].ToString());
                            //string createdTime;



                            searchDateList.Add(Email);
                        }
                    }

                    //// junk
                    SqlCommand objCommandj = new SqlCommand();
                    objCommandj.CommandType = CommandType.StoredProcedure;
                    objCommandj.CommandText = "GetSearchByDateFromJunk";// name of the procedure
                                                                        // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                    objCommandj.Parameters.AddWithValue("@inputDate", searchDate);


                    DBConnect objDBj = new DBConnect();
                    DataSet myDataSetj;
                    myDataSetj = objDB.GetDataSetUsingCmdObj(objCommandj);


                    int sizej = myDataSetj.Tables[0].Rows.Count;
                    if (sizej > 0)
                    {
                        // ArrayList emailListInbox = new ArrayList();
                        for (int i = 0; i < sizej; i++)
                        {
                            email Email = new email();

                            Email.EmailId = int.Parse(myDataSetj.Tables[0].Rows[i]["emailID"].ToString());
                            Email.SenderId = int.Parse(myDataSetj.Tables[0].Rows[i]["senderId"].ToString());
                            Email.ReceivedId = int.Parse(myDataSetj.Tables[0].Rows[i]["receivedId"].ToString());
                            Email.Subject = myDataSetj.Tables[0].Rows[i]["subject"].ToString();
                            Email.EmailBody = myDataSetj.Tables[0].Rows[i]["emailBody"].ToString();
                            Email.CreatedTime = DateTime.Parse(myDataSetj.Tables[0].Rows[i]["createdTime"].ToString());
                            //string createdTime;



                            searchDateList.Add(Email);
                        }
                    }
                    // trash
                    SqlCommand objCommandt = new SqlCommand();
                    objCommandt.CommandType = CommandType.StoredProcedure;
                    objCommandt.CommandText = "GetSearchByDateFromTrash";// name of the procedure
                                                                         // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                    objCommandt.Parameters.AddWithValue("@inputDate", searchDate);


                    DBConnect objDBt = new DBConnect();
                    DataSet myDataSett;
                    myDataSett = objDB.GetDataSetUsingCmdObj(objCommandt);


                    int sizet = myDataSett.Tables[0].Rows.Count;
                    if (sizet > 0)
                    {
                        // ArrayList emailListInbox = new ArrayList();
                        for (int i = 0; i < sizet; i++)
                        {
                            email Email = new email();

                            Email.EmailId = int.Parse(myDataSett.Tables[0].Rows[i]["emailID"].ToString());
                            Email.SenderId = int.Parse(myDataSett.Tables[0].Rows[i]["senderId"].ToString());
                            Email.ReceivedId = int.Parse(myDataSett.Tables[0].Rows[i]["receivedId"].ToString());
                            Email.Subject = myDataSett.Tables[0].Rows[i]["subject"].ToString();
                            Email.EmailBody = myDataSett.Tables[0].Rows[i]["emailBody"].ToString();
                            Email.CreatedTime = DateTime.Parse(myDataSett.Tables[0].Rows[i]["createdTime"].ToString());
                            //string createdTime;



                            searchDateList.Add(Email);
                        }
                    }




                    gvShowSearchSubject.DataSource = searchDateList;
                    gvShowSearchSubject.DataBind();
                }

            }
            else
            {

                // MessageBox.Show("Please select a category  ");

                Response.Write("<script>alert('Please select a category')</script>");
            }




        }

        protected void btnCreateFolder_Click(object sender, EventArgs e)
        {

            pnlCreateFolder.Visible = true;

            pnlInbox.Visible = false;
            btnMoveInbox0.Visible = false;
            pnlSent.Visible = false;
            btnSentMove.Visible = false;
            pnlJuck.Visible = false;
            btnMoveJunk.Visible = false;
            pnlFlag.Visible = false;
            btnflagMove.Visible = false;
            pnlTrash.Visible = false;
            btnTrashMove.Visible = false;
            pnlAllemails.Visible = false;
            pnlComposeEmail.Visible = false;
        }

        protected void btnNewFolder_Click(object sender, EventArgs e)
        {
            tag personalFolder = new tag();
            // lblCreatedFolderName.Text = txtNewFolder.Text;
            // dynamic button ?
            Button btnnewFolder = new Button();
            pnlAddFolders.Controls.Add(btnnewFolder);
            btnnewFolder.Text = txtNewFolder.Text;

        }

        protected void gvFlag_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
    
    

                

    