﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TmailLibrary;
using System.Windows.Forms;
using System.Data;
using Utilities;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CIS3342_Project3_Tmail
{

    public partial class LogIn : System.Web.UI.Page
    {//DBConnect dBConnect = new DBConnect();
        protected void Page_Load(object sender, EventArgs e)
        {// bruce
            if (!IsPostBack)
            {

                if (Session["createEmailAddress"] != null)
                {// check if email address exist 


                    txtEmailAddress.Text = Session["createEmailAddress"].ToString();



                }

         }
        }
        
        protected void btnLogIn_Click(object sender, EventArgs e)
        { // wenting 
            DBConnect dBConnect = new DBConnect();
            if (txtEmailAddress.Text == "")
            {
                Response.Write("<script>alert('Please enter your email address.')</script>");
            }
            else if (txtEmailAddress.Text.Length <= 10) {
                // MessageBox.Show("please enter your email address as format XXXXXX@tmail.com");

                Response.Write("<script>alert('please enter your email address as format XXXXXX@tmail.com.')</script>");

            }
            else if (txtEmailAddress.Text.Substring(txtEmailAddress.Text.Length - 10) != "@tmail.com") {

                Response.Write("<script>alert('please enter your email address as format XXXXXX@tmail.com')</script>");
               // MessageBox.Show("please enter your email address as format XXXXXX@tmail.com");
            }
            else if (txtPassword.Text == "")
            {
                Response.Write("<script>alert('Please enter your email password.')</script>");
                // MessageBox.Show("please enter your password");
            }
            else
            {// check password correct or not 
             // code ysed to connect to a SQL server database and execute  a stored procedure
                SqlCommand objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "CheckPasswordIfMatch";// name of the procedure
                // pass an input parameter value to the stored procedure that is used for the @email and @password  built- in function 
                objCommand.Parameters.AddWithValue("@inputEmail", txtEmailAddress.Text);
                objCommand.Parameters.AddWithValue("@inputPassword", txtPassword.Text);

                DBConnect objDB = new DBConnect();
                DataSet myDataSet;
                myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);

                int size = myDataSet.Tables[0].Rows.Count;
                if (size > 0)// if password is correct 
                {// IF BANNED
                    int ifActive = int.Parse(objDB.GetField("active", 0).ToString());
                    if (ifActive == 0)
                    {
                        //MessageBox.Show("You account has been banned , please go to see administrator ");

                        Response.Write("<script>alert('You account has been banned , please go to see administrator .')</script>");
                    }
                    else // if not banned
                    {
                        // MessageBox.Show("You log in successfully ");
                        // Response.Redirect("ordinaryUser.aspx");
                        int AdOrUser = int.Parse(objDB.GetField("type", 0).ToString());
                        if (AdOrUser == 0)
                        {// put old information into a sessionand use in "show user emails "page


                            Session["userId"] = objDB.GetField("UserId", 0);
                            Session["userName"] = objDB.GetField("userName", 0);
                            Session["address"] = objDB.GetField("address", 0);
                            Session["phoneNumber"] = objDB.GetField("phoneNumber", 0);
                            Session["createEmailAddress"] = txtEmailAddress.Text;
                            Session["avatar"] = objDB.GetField("avatar", 0);
                            Response.Redirect("ordinaryUser.aspx");
                        }
                        else
                        {



                            Session["userId"] = objDB.GetField("UserId", 0);
                            Session["userName"] = objDB.GetField("userName", 0);
                            Session["address"] = objDB.GetField("address", 0);
                            Session["phoneNumber"] = objDB.GetField("phoneNumber", 0);
                            Session["createEmailAddress"] = txtEmailAddress.Text;
                            Session["avatar"] = objDB.GetField("avatar", 0);



                            Response.Redirect("administrator.aspx");
                        }
                    }
                }
                else
                {
                    Response.Write("<script>alert('You enter wrong password, please contact Administrator or create new account .')</script>");
                    //MessageBox.Show("You enter wrong password, please contact Administrator or create new account");
                }



            }


        }

        protected void btnCreateAccount_Click(object sender, EventArgs e)
        {
            Response.Redirect("creatAccount.aspx");
        }

     

        protected void txtEmailAddress_TextChanged(object sender, EventArgs e)
        {

        }
    }
}