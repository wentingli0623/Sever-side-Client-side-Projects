﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using TmailLibrary;
using Utilities;

namespace CIS3342_Project3_Tmail
{
    public partial class creatAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btncSignIn_Click(object sender, EventArgs e)
        {
            Response.Redirect("LogIn.aspx");
        }

        protected void btnCreateAccount_Click(object sender, EventArgs e)
        {
            long phoneN;
            // avlidation 
            if (txtcName.Text == "")
            {
                Response.Write("<script>alert('Please enter your name ')</script>");
                //MessageBox.Show("Please enter your name ");
            }
            else if (txtcPhone.Text == "")
            {
                Response.Write("<script>alert('Please enter your Phone number ')</script>");
                //MessageBox.Show("Please enter your Phone number  ");
            }
            else if (!(long.TryParse(txtcPhone.Text, out phoneN)))
            {

                Response.Write("<script>alert('Please valid digital number ')</script>");
               // MessageBox.Show("Please valid digital number ");


            }
            else if (txtcPhone.Text.Length != 10)
            {
                Response.Write("<script>alert('please enter a valid 10 digits Phone number ')</script>");
                //   MessageBox.Show("please enter a valid 10 digits Phone number  ");
            }
            else if (txtcPassword.Text == "")
            {
                Response.Write("<script>alert('Please enter your password  ')</script>");
                // MessageBox.Show("Please enter your password  ");
            }
            else if (txtcContactemail.Text == "")
            {
                Response.Write("<script>alert('Please enter your contact email')</script>");
                //MessageBox.Show("Please enter your contact email ");
            }
            else if (txtcEmail.Text == "")
            {
                Response.Write("<script>alert('Please enter your new email')</script>");
                // MessageBox.Show("Please enter your new email ");
            }
            else if (txtcEmail.Text.Length <= 10)
            {
                Response.Write("<script>alert('please enter your email address as format XXXXXX@tmail.com')</script>");
                //MessageBox.Show("please enter your email address as format XXXXXX@tmail.com");
            }
            else if (txtcEmail.Text.Substring(txtcEmail.Text.Length - 10) != "@tmail.com")
            {
                Response.Write("<script>alert('Please follow correct tmail formatt : xxxx@tmail.com')</script>");
                //MessageBox.Show("Please follow correct tmail formatt : xxxx@tmail.com");
            }
            else if (txtcAddress.Text == "")
            {

                Response.Write("<script>alert('Please enter your address')</script>");
                // MessageBox.Show("Please enter your address ");
            } else if (cklType.SelectedValue.ToString()=="") {
                //  MessageBox.Show("Please select your user type ");
                Response.Write("<script>alert('Please select your user type ')</script>");
            }
            else
            {
                int userType = int.Parse(cklType.SelectedValue.ToString());


                if (userType == 0)
                {
                    user newUser = new user();
                    newUser.UserName = txtcName.Text;
                    newUser.Address = txtcAddress.Text;
                    newUser.Password = txtcPassword.Text;
                    newUser.PhoneNumber = long.Parse(txtcPhone.Text);
                    newUser.CreatedEmailAddress = txtcEmail.Text;
                    newUser.ContactEmailAddress = txtcContactemail.Text;
                    newUser.AvatarURL = rdbAvatar.SelectedValue.ToString();
                    newUser.Type = int.Parse(cklType.SelectedValue);
                    newUser.Active = 1;

                    // updata call procedure 

                    //int size = myDataSet.Tables[0].Rows.Count;
                    SqlCommand objCommand = new SqlCommand();
                    objCommand.CommandType = System.Data.CommandType.StoredProcedure;
                    objCommand.CommandText = "InsertNewUser";

                    objCommand.Parameters.AddWithValue("@createName", newUser.UserName);
                    objCommand.Parameters.AddWithValue("@createAddress", newUser.Address);
                    objCommand.Parameters.AddWithValue("@createphone", newUser.PhoneNumber);
                    objCommand.Parameters.AddWithValue("@createEmail", newUser.CreatedEmailAddress);
                    objCommand.Parameters.AddWithValue("@contactEmail", newUser.ContactEmailAddress);
                    objCommand.Parameters.AddWithValue("@creataVatarURL", newUser.AvatarURL);
                    objCommand.Parameters.AddWithValue("@createPassword", newUser.Password);
                    objCommand.Parameters.AddWithValue("@createActive", newUser.Active);
                    objCommand.Parameters.AddWithValue("@createType", newUser.Type);

                    DBConnect objDB = new DBConnect();
                    DataSet myDataSet;
                    myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);
                    Response.Write("<script>alert('Your Account create succusfully as an user')</script>");
                    //MessageBox.Show("Your Account create succusfully as an user");
                    Response.Redirect("LogIn.aspx");
                }
                else
                {


                    user newUser = new user();
                    newUser.UserName = txtcName.Text;
                    newUser.Address = txtcAddress.Text;
                    newUser.Password = txtcPassword.Text;
                    newUser.PhoneNumber = long.Parse(txtcPhone.Text);
                    newUser.CreatedEmailAddress = txtcEmail.Text;
                    newUser.ContactEmailAddress = txtcContactemail.Text;
                    newUser.AvatarURL = rdbAvatar.SelectedValue.ToString();
                    newUser.Type = int.Parse(cklType.SelectedValue);
                    newUser.Active = 1;

                    // updata call procedure 

                    //int size = myDataSet.Tables[0].Rows.Count;
                    SqlCommand objCommand = new SqlCommand();
                    objCommand.CommandType = System.Data.CommandType.StoredProcedure;
                    objCommand.CommandText = "InsertNewUser";

                    objCommand.Parameters.AddWithValue("@createName", newUser.UserName);
                    objCommand.Parameters.AddWithValue("@createAddress", newUser.Address);
                    objCommand.Parameters.AddWithValue("@createphone", newUser.PhoneNumber);
                    objCommand.Parameters.AddWithValue("@createEmail", newUser.CreatedEmailAddress);
                    objCommand.Parameters.AddWithValue("@contactEmail", newUser.ContactEmailAddress);
                    objCommand.Parameters.AddWithValue("@creataVatarURL", newUser.AvatarURL);
                    objCommand.Parameters.AddWithValue("@createPassword", newUser.Password);
                    objCommand.Parameters.AddWithValue("@createActive", newUser.Active);
                    objCommand.Parameters.AddWithValue("@createType", newUser.Type);

                    DBConnect objDB = new DBConnect();
                    DataSet myDataSet;
                    myDataSet = objDB.GetDataSetUsingCmdObj(objCommand);

                    Response.Write("<script>alert('Your Account create succusfully as an administrator')</script>");
                    //MessageBox.Show("Your Account create succusfully as an administrator");
                    Response.Redirect("LogIn.aspx");
                }

            }
        }
        protected void txtcPhone0_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtcContactemail_TextChanged(object sender, EventArgs e)
        {

        }
    }

}