﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CIS3344TermProject
{
    public class item
    {
        string picURL, title, description;
        int quantity;
        double  basePrice, totalPrice;
        
        public string PicURL
        {
            get { return picURL; }
            set { picURL = value; }


        }
        public string Title
        {
            get { return title; }
            set { title = value; }


        }
        public string Description
        {
            get { return description; }
            set { description = value; }


        }
        public int Quantity {

            get { return quantity; }
            set { quantity = value; }

        }
        public double BasePrice
        {
            get { return basePrice; }
            set { basePrice = value; }

        }
        public double TotalPrice {
            get { return totalPrice; }
            set { totalPrice = value; }
        }
        // constructor 

        public item(string picURL, string title,string description, int quantity,double  basePrice, double totalPrice ) {

            this.picURL = picURL;
            this.title = title;
            this.description = description;
            this.quantity = quantity;
            this.basePrice = basePrice;
            this.totalPrice = totalPrice;
        }

        public item() {
        
        
        }


       public double singleTotal()
        {
            double singleTotol = 0;
            return singleTotol = basePrice * quantity;
        }
    }
}
