﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIS3342_project1_wentingli
{    

    public class question
    {// attributes:
        string questions, correctA, userA, strDisplay;
        int score;

        // constructor
        public question(string q ,string cA, string uA) {

            questions = q;
            correctA = cA;
            userA = uA;

        }
        // compare the correct anwser and useranswer and disply the result 
        public string display(string q,string correctA, string userA ) {


            if (compareAnswear(correctA, userA) == true)
            {
                strDisplay = q + "<br />" + "Your answer is :" + userA + "<br />" + "Congratulations!You are correct!" + "<br />";
                strDisplay += "<img src ='images folder/check.jpg'/><br />";
                countScore();
            }
            else if (compareAnswear(correctA, userA) == false)
            {
                strDisplay = q + "<br />" + "Your answer is " + userA + "<br />" + "  Your answer is wrong." + "<br />" + " The correct answer is :" + correctA + "<br />";
                strDisplay += "<img src ='images folder/cross.jpg'/><br />";
            }
            return strDisplay;
        }



        //compare the correct anwser and useranswer with inputs
        public Boolean compareAnswear(string correctA, string userA) {
            if (correctA == userA)
            {

                return true;

            }

            return false;
        }

        // getter get correct answer
        public  string getCA() {


            return correctA;
        }


        // getter get user answer
        public string getUA()
        {


            return userA;
        }

        // getter get question
        public string getQ()
        {


            return questions;
        }

        // collect scores for correct answer
        public int countScore()
        {

            score += 5;
            return score;
        }

    }
}