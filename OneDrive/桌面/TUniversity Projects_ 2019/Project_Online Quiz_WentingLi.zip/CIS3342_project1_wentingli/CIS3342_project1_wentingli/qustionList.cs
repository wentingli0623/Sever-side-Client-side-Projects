﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace CIS3342_project1_wentingli
{
    public class qustionList
    {// attributes 
        string lg, result1;
        question q;
        int score;
        //a list of question objects
        List<question> qList = new List<question>();
        // array of results string 
        string[] results = new string[20];
     //a loop to call display method in question class
        public string[] displayall()
        {
            for (int i = 0; i < qList.Count; i++)
            {

                results[i] = qList[i].display(qList[i].getQ(), qList[i].getCA(), qList[i].getUA());
            }
            return results;


        }
        // add question object into question list 
        public void add(question q)
        {

            qList.Add(q);



        }
        // get final result to get lettergrade
        public int getFinalResult()
        {
            for (int i = 0; i < 20; i++)
            {

                if (qList[i].compareAnswear(qList[i].getCA(), qList[i].getUA()) == true)
                {

                    score += 5;

                }
                
            }
            return score;
        }
        // get letter grade as string 
        public string getLetterGrade()
        {
                if (score < 60)
                    lg = ("F");
                else if (score >= 60 && score < 70)
                    lg = ("D");
                else if (score >= 70 && score < 80)
                    lg = ("c");
                else if (score >= 80 && score < 90)
                    lg = ("B");
                else
                    lg = ("A");
            return lg;
        }
        


        
     
    }
}