﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace CIS3342_project1_wentingli
{
    public partial class Quzi : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {  // request name and ID 
            string name = Request["txtName"];
            string tuID = Request["txtID"];

            Response.Write("<p> Hello    " + name + "! your TuID is :" + tuID + "</p>");
            Response.Write("<h3>The result of your quiz</h3>");

            
            // collect Questions
            string q1 = "1.What does the Dragon represent in Chinese culture?";
            string q2 = "2.What is the Chinese national language?";
            string q3 = "3.Which city is the capital of China?";
            string q4 = "4. How many Zodiac animals are there reprents Chinese year?";
            string q5 = "5.Which continet does China belong to ?";
            string q6 = "6.What does 'ni hao' mean in Chinese ?";
            string q7 = "7.Ture or Flase : Paper is considered one of China's greatest inventions.";
            string q8 = "8.What does the following character mean ?";
            string q9 = " 9.When is the date of Chinese Independence Day?";
            string q10 = "10. Which city does The Great Wall locate ?";
            string q11 = " 11. What do the Chinese use most often to eat with?";
            string q12 = "12.Chinese names usually start with the:";
            string q13 = " 13.What are the three main kinds of Chinese dumplings?";
            string q14 = "14.What is this popular fruit called in China ?";
            string q15 = "15. Who is this famous martial artist and action movie star?";
            string q16 = "16.What is China's highest mountain range?";
            string q17 = "17.Which martial art is recommended to older people for its various physical and psychological benefits in China ?";
            string q18 = "18. If I learn Mandarin Chinese, can I talk with most people in China?";
            string q19 = "19.Do I need a visa to visit China?";
            string q20 = "20.Do I need any shots or immunizations to travel to China?";

            // collect correct answers
            string cA1 = "Power, Strength, and Good Luck";
            string cA2 = "Madrain";
            string cA3 = "Beijing";
            string cA4 = "12";
            string cA5 = "Asia";
            string cA6 = "Hello or Hi";
            string cA7 = "True";
            string cA8 = "Mountain";
            string cA9 = "Oct.1st";
            string cA10 = "Beijing";
            string cA11 = "chopstickes";
            string cA12 = "Family name";
            string cA13 = "Boiled, Steam and Pan-fried";
            string cA14 = "durian";
            string cA15 = "BruceLee";
            string cA16 = "Himalayas";
            string cA17= "Tai Chi";
            string cA18= "Yes";
            string cA19= "A visa is required for all Canadians, Americans and people of most other nationalities who travel to China";
            string cA20 = "There are no particular immunizations that are required.";
            // collect user answers
            string uA1 = Request["txtQ1"];
            string uA2 = Request["txtQ2"];
            string uA3 = Request["capital"];
            string uA4 = Request["zodiac animals"];
            string uA5 = Request["txtContinet"];
            string uA6 = Request["CH1"];
            string uA7 = Request["paper"];
            string uA8 = Request["character"];
            string uA9 = Request["independtDay"];
            string uA10 = Request["Beijing"];
            string uA11 = Request["chopstickes"];
            string uA12 = Request["Cname"];
            string uA13 = Request["dumplings"];
            string uA14 = Request["txtdurian"];
            string uA15 = Request["txtBruceLee"];
            string uA16 = Request["checkbox1"];
            string uA17 = Request["taiji"];
            string uA18 = Request["mandrain"];
            string uA19 = Request["checkbox2"];
            string uA20 = Request["immunizations"];
            // create 20 question objects
            question Q1 = new question(q1,cA1,uA1);
            question Q2 = new question(q2,cA2, uA2);
            question Q3 = new question(q3, cA3, uA3);
            question Q4 = new question(q4, cA4, uA4);
            question Q5 = new question(q5, cA5, uA5);
            question Q6 = new question(q6, cA6, uA6);
            question Q7 = new question(q7, cA7, uA7);
            question Q8 = new question(q8, cA8, uA8);
            question Q9 = new question(q9, cA9, uA9);
            question Q10 = new question(q10, cA10, uA10);
            question Q11 = new question(q11, cA11, uA11);
            question Q12 = new question(q12, cA12, uA12);
            question Q13 = new question(q13, cA13, uA13);
            question Q14 = new question(q14, cA14, uA14);
            question Q15 = new question(q15, cA15, uA15);
            question Q16 = new question(q16, cA16, uA16);
            question Q17 = new question(q17, cA17, uA17);
            question Q18 = new question(q18, cA18, uA18);
            question Q19 = new question(q19, cA19, uA19);
            question Q20 = new question(q20, cA20, uA20);
            //add question objects into questionlist 
            qustionList chineseQlist = new qustionList();
            chineseQlist.add(Q1);
            chineseQlist.add(Q2);
            chineseQlist.add(Q3);
            chineseQlist.add(Q4);
            chineseQlist.add(Q5);
            chineseQlist.add(Q6);
            chineseQlist.add(Q7);
            chineseQlist.add(Q8);
            chineseQlist.add(Q9);
            chineseQlist.add(Q10);
            chineseQlist.add(Q11);
            chineseQlist.add(Q12);
            chineseQlist.add(Q13);
            chineseQlist.add(Q14);
            chineseQlist.add(Q15);
            chineseQlist.add(Q16);
            chineseQlist.add(Q17);
            chineseQlist.add(Q18);
            chineseQlist.add(Q19);
            chineseQlist.add(Q20);
           

            // use a loop to display all results

            for (int i = 0; i < 20; i++)
            { 

              Response.Write(chineseQlist.displayall().GetValue(i)+"");
            }
            // show result and letter grade
            Response.Write("<p> Your result of the quiz is: " + chineseQlist.getFinalResult() + "<p>");
            Response.Write("<p> Your grade of the quiz is: " + chineseQlist.getLetterGrade() + "<p>");

        }







































        /*
        public int addUpScore(int score)
        {
            score += 5;
            return score;
        }

        public string getLetterGrade(int score)
        {
            
            if (score < 60)
                lg = ("F");
            else if (score >= 60 && score < 70)
                lg = ("D");
            else if (score >= 70 && score < 80)
                lg = ("c");
            else if (score >= 80 && score < 90)
                lg = ("B");
            else
                lg = ("A");

            return lg;
        
    }

    protected void Page_Load(object sender, EventArgs e)
        {
            //   attributes 
            string name = Request["txtName"];
            string tuID = Request["txtID"];
            string qValue, aValue;
          
            string oneUserA = Request["txtQ1"];
            string oneA = "Power, Strength, and Good Luck";
            Response.Write("<p> Question 1. What does the Dragon represent in Chinese culture?" + "<p>");
            //Response.Write();
            Response.Write("<p> Your answer is: " + oneUserA + "<p>");
            if (compareAnswer(oneUserA, oneA) == true)
            {
                countScore();
                Response.Write("<p> You are correct" + "<p>");
            }
            else {
                Response.Write("<p> You are wrong, the correct answer is " + oneA + "<p>") ;
               
            }

            //--------------------------------------
            
            string twoUserA = Request["txtQ2"];
            string twoA = "Beijing";
            Response.Write("<p> Question 2.  Which city is the capital of China?" + "<p>");
            //Response.Write();
            Response.Write("<p> Your answer is: " + twoUserA + "<p>");
            if (compareAnswer(twoUserA, twoA) == true)
            {
                countScore();
                Response.Write("<p> You are correct" + "<p>");
            }
            else
            {
                Response.Write("<p> You are wrong, the correct answer is " + twoA + "<p>");

            }

            Response.Write("<h3>The result of your quiz</h3>");
            Response.Write("<p> Hello" + name + "your TuID is" + tuID + "</p>");
            Response.Write("<p> Your result of the quiz is: " + score +"<p>");
            Response.Write("<p> Your grade of the quiz is: " + getLetterGrade(score) + "<p>");
        }*/
    }

}