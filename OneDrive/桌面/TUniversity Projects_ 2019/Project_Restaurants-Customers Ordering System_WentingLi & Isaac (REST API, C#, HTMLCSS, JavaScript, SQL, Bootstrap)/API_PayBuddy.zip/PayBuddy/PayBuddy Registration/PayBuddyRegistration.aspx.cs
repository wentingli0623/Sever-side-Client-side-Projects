﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;

namespace PayBuddy_Registration
{
    public partial class PayBuddyRegistration : System.Web.UI.Page
    {
        DBConnect db = new DBConnect();
        SqlCommand objCommand = new SqlCommand();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblErrorMessage.Visible = false;
                txtPassword.Visible = false;
                txtPhoneNumber.Visible = false;
                btnCreateNewAccount.Visible = false;
            }
        }

        protected void btnCreateNewAccount_Click(object sender, EventArgs e)
        {
            //add the new record
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_AddMerchant";
            objCommand.Parameters.AddWithValue("@Email_Address", txtEmailAddress.Text);
            objCommand.Parameters.AddWithValue("@Merchant_Name", txtName.Text);
            objCommand.Parameters.AddWithValue("@Merchant_Phone_Number", txtPhoneNumber.Text);
            objCommand.Parameters.AddWithValue("@Password", txtPassword.Text);
            db.DoUpdateUsingCmdObj(objCommand);

            //check that the record was added
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_GetMerchant";
            objCommand.Parameters.AddWithValue("@Email_Address", txtEmailAddress.Text);
            DataSet myds = db.GetDataSetUsingCmdObj(objCommand);

            if (myds.Tables[0].Rows.Count != 0)
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = Color.White;
                lblErrorMessage.Text = "Your Account was Successfully Created! Your Merchant ID # is " + myds.Tables[0].Rows[0][0].ToString() + ". " +
                    "Your Web API KEY # is " + myds.Tables[0].Rows[0][1].ToString() + ".";
                txtName.Visible = false;
                txtEmailAddress.Visible = false;
                btnCheckEmailAvailability.Visible = false;
                txtPassword.Visible = false;
                txtPhoneNumber.Visible = false;
                btnCreateNewAccount.Visible = false;
            }
        }

        protected void btnCheckEmailAvailability_Click(object sender, EventArgs e)
        {
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_CheckMerchantEmail";
            objCommand.Parameters.AddWithValue("@Email_Address", txtEmailAddress.Text);
            DataSet myds = db.GetDataSetUsingCmdObj(objCommand);

            if (myds.Tables[0].Rows.Count != 0)
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = Color.Red;
                lblErrorMessage.Text = "That Email is already taken! Please enter a different Email Address.";
            }
            else
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = Color.White;
                lblErrorMessage.Text = "That Email is Available!";
                txtPassword.Visible = true;
                txtPhoneNumber.Visible = true;
                btnCreateNewAccount.Visible = true;

            }
        }
    }
}