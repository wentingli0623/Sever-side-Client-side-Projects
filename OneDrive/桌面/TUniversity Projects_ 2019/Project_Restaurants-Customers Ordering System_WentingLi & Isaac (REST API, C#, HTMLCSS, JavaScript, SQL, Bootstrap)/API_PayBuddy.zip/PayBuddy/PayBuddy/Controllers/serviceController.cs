﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Utilities;

namespace PayBuddy.Controllers
{
    [Produces("application/json")]
    [Route("api/service/PaymentGateway")]
    public class serviceController : Controller
    {
        DBConnect db = new DBConnect();
        SqlCommand objCommand = new SqlCommand();
        DataSet myds;
        // GET: api/service/PaymentGateway
       
            /*[HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }*/

            //url
        [HttpGet("getTransactions/{merchantAccountID}/{merchantAPIKEY}/{virtualWalletID}")]
        public List<Transaction> getTransactions(int virtualWalletID, int merchantAccountID, int merchantAPIKEY)
        {
            List<Transaction> WalletTransactions = new List<Transaction>();

            if (isVerified(merchantAccountID, merchantAPIKEY))
            {

                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_GetTransactions";
                objCommand.Parameters.AddWithValue("@VirtualWallet_ID", virtualWalletID);
            
                myds = db.GetDataSetUsingCmdObj(objCommand);

                for (int i = 0; i < myds.Tables[0].Rows.Count; i++)
                {
                    Transaction transaction = new Transaction();
                    transaction.Transaction_ID = Convert.ToInt32(myds.Tables[0].Rows[i][0]);
                    transaction.VirtualWalletOne_ID = Convert.ToInt32(myds.Tables[0].Rows[i][1]);

                    if(myds.Tables[0].Rows[i][2] != System.DBNull.Value)
                    {
                        transaction.VirtualWalletTwo_ID = Convert.ToInt32(myds.Tables[0].Rows[i][2]);
                    }
                    
                    transaction.Merchant_Account_ID = Convert.ToInt32(myds.Tables[0].Rows[i][3]);
                    transaction.Transaction_Type = myds.Tables[0].Rows[i][4].ToString();
                    transaction.Transaction_Amount = Convert.ToDouble(myds.Tables[0].Rows[i][5]);
                    transaction.Transaction_DateTime = myds.Tables[0].Rows[i][6].ToString();
                    WalletTransactions.Add(transaction);
                }

            }

            return WalletTransactions;
        }

       /* // GET: api/service/PaymentGateway/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }*/

        
        // POST: api/service/PaymentGateway/createVirtualWallet
        
            /*[HttpPost]
        public string Post([FromBody]string value)
        {
            return "The web api post received" + value + "";
        }*/

        [HttpPost("createVirtualWallet/{merchantAccountID}/{merchantAPIKEY}")]
        public string CreateVirtualWallet([FromBody]AccountHolderInformation accountInfo, 
            int merchantAccountID, int merchantAPIKEY)
        {
            if (isVerified(merchantAccountID, merchantAPIKEY))
            {

                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_NewVirtualWallet";
                objCommand.Parameters.AddWithValue("@Merchant_Account_ID", merchantAccountID);
                objCommand.Parameters.AddWithValue("@Merchant_API_KEY", merchantAPIKEY);
                objCommand.Parameters.AddWithValue("@VirtualWallet_Name", accountInfo.Name.ToString());
                objCommand.Parameters.AddWithValue("@VirtualWallet_PaymentMethod", accountInfo.PaymentMethod.ToString());
                objCommand.Parameters.AddWithValue("@VirtualWallet_PaymentMethodNumber", accountInfo.PaymentMethodNumber.ToString());
                objCommand.Parameters.AddWithValue("@VirtualWallet_Account_Type", accountInfo.AccountType.ToString());
                objCommand.Parameters.Add("@VirtualWallet_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
                db.DoUpdateUsingCmdObj(objCommand);



                int newWalletID = Convert.ToInt32(objCommand.Parameters["@VirtualWallet_ID"].Value);

                return "New PayBuddy Wallet was created successfully! Your Virtual Wallet ID# is " + newWalletID + ".";
            }

            return "An error occured!";
        }

        // POST: api/service/PaymentGateway/processPayment

        [HttpPost("processPayment/{merchantAccountID}/{merchantAPIKEY}/{virtualWalletID_1}/{virtualWalletID_2}/{type}/{amount}")]
        public string processPayment(int virtualWalletID_1, int virtualWalletID_2, float amount, string type,
            int merchantAccountID, int merchantAPIKEY)
        {
            if(isVerified(merchantAccountID, merchantAPIKEY))
            {
                if (type == "payment" || type == "Payment")
                {
                    //Get  the current balance for this specific wallet
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_GetVirtualWallet";
                    objCommand.Parameters.AddWithValue("@VirtualWallet_ID", virtualWalletID_1);
                    myds = db.GetDataSetUsingCmdObj(objCommand);
                    double currentAmount = Convert.ToDouble(myds.Tables[0].Rows[0][4]);

                    //if the amount we want to pay is less than or equal to the current amount
                    //do the transaction
                    if (amount < currentAmount || amount == currentAmount)
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Clear();
                        objCommand.CommandText = "TP_NewTransactionTwoWallets";
                        objCommand.Parameters.AddWithValue("@VirtualWalletOne_ID", virtualWalletID_1);
                        objCommand.Parameters.AddWithValue("@VirtualWalletTwo_ID", virtualWalletID_2);
                        objCommand.Parameters.AddWithValue("@Merchant_Account_ID", merchantAccountID);
                        objCommand.Parameters.AddWithValue("@Transaction_Type", type);
                        objCommand.Parameters.AddWithValue("@Transaction_Amount", amount);
                        objCommand.Parameters.Add("@Transaction_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
                        db.DoUpdateUsingCmdObj(objCommand);

                        int newTransactionID = Convert.ToInt32(objCommand.Parameters["@Transaction_ID"].Value);

                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Clear();
                        objCommand.CommandText = "TP_ProcessPayment";
                        objCommand.Parameters.AddWithValue("@VirtualWallet_ID_1", virtualWalletID_1);
                        objCommand.Parameters.AddWithValue("@VirtualWallet_ID_2", virtualWalletID_2);
                        objCommand.Parameters.AddWithValue("@Amount", amount);
                        db.DoUpdateUsingCmdObj(objCommand);

                        return " Payment successful! " +
                               " Virtual wallet One: " + virtualWalletID_1 +
                               " Virtual wallet Two: " + virtualWalletID_2 +
                               " Type: " + type +
                               " Amount: $" + amount +
                               " Transaction #: " + newTransactionID;
                    }
                    else
                    {
                        return " Insufficient Funds! Please Add Funds to Continue!";
                    }
                }
                else if (type == "refund" || type == "Refund")
                {
                    //Get  the current balance for this specific wallet
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_GetVirtualWallet";
                    objCommand.Parameters.AddWithValue("@VirtualWallet_ID", virtualWalletID_2);
                    myds = db.GetDataSetUsingCmdObj(objCommand);
                    double currentAmount = Convert.ToDouble(myds.Tables[0].Rows[0][4]);

                    //if the amount we want to pay is less than or equal to the current amount
                    //do the transaction
                    if (amount < currentAmount || amount == currentAmount)
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Clear();
                        objCommand.CommandText = "TP_NewTransactionTwoWallets";
                        objCommand.Parameters.AddWithValue("@VirtualWalletOne_ID", virtualWalletID_1);
                        objCommand.Parameters.AddWithValue("@VirtualWalletTwo_ID", virtualWalletID_2);
                        objCommand.Parameters.AddWithValue("@Merchant_Account_ID", merchantAccountID);
                        objCommand.Parameters.AddWithValue("@Transaction_Type", type);
                        objCommand.Parameters.AddWithValue("@Transaction_Amount", amount);
                        objCommand.Parameters.Add("@Transaction_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
                        db.DoUpdateUsingCmdObj(objCommand);

                        int newTransactionID = Convert.ToInt32(objCommand.Parameters["@Transaction_ID"].Value);

                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Clear();
                        objCommand.CommandText = "TP_ProcessRefund";
                        objCommand.Parameters.AddWithValue("@VirtualWallet_ID_1", virtualWalletID_1);
                        objCommand.Parameters.AddWithValue("@VirtualWallet_ID_2", virtualWalletID_2);
                        objCommand.Parameters.AddWithValue("@Amount", amount);
                        db.DoUpdateUsingCmdObj(objCommand);

                        return " Refund successful! " +
                               " Virtual wallet One: " + virtualWalletID_1 +
                               " Virtual wallet Two: " + virtualWalletID_2 +
                               " Type: " + type +
                               " Amount: $" + amount +
                               " Transaction #: " + newTransactionID;
                    }
                    else
                    {
                        return " Insufficient Funds! Please Add Funds to Continue!";
                    }
                }
            }

            return "There was a problem with the API Key and Merchant ID you provided. Please try again!";
        }

        // PUT: api/service/PaymentGateway/updatePaymentInfo
        /*[HttpPut("{id}")]
        public string Put(int id, [FromBody]string value)
        {
            return "The web api put received " + id +" and " + value + ".";
        }*/

        [HttpPut("updatePaymentInfo/{merchantAccountID}/{merchantAPIKEY}/{virtualWalletID}")]
        public string updatePaymentInfo(int virtualWalletID, [FromBody]AccountHolderInformation accountInfo,
            int merchantAccountID, int merchantAPIKEY)
        {
            if (isVerified(merchantAccountID, merchantAPIKEY))
            {
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_UpdatePaymentInfo";
                objCommand.Parameters.AddWithValue("@VirtualWallet_ID", virtualWalletID);
                objCommand.Parameters.AddWithValue("@Name", accountInfo.Name.ToString());
                objCommand.Parameters.AddWithValue("@PaymentMethod", accountInfo.PaymentMethod.ToString());
                objCommand.Parameters.AddWithValue("@PaymentMethodNumber", accountInfo.PaymentMethodNumber.ToString());
                objCommand.Parameters.AddWithValue("@AccountType", accountInfo.AccountType.ToString());
                db.DoUpdateUsingCmdObj(objCommand);

                return "Account # " + virtualWalletID + " successfully updated! ";
            }
                return "Your Merchant ID# and Web API combination do not match! Please try again.";
        }

        // PUT: api/service/PaymentGateway/fundAccount
        [HttpPut("fundAccount/{merchantAccountID}/{merchantAPIKEY}/{virtualWalletID}/{amount}")]
        public string fundAccount(int virtualWalletID, float amount,
            int merchantAccountID, int merchantAPIKEY)
        {
            if (isVerified(merchantAccountID, merchantAPIKEY))
            {
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_GetVirtualWallet";
                objCommand.Parameters.AddWithValue("@VirtualWallet_ID", virtualWalletID);
                myds = db.GetDataSetUsingCmdObj(objCommand);
                double currentAmount = Convert.ToDouble(myds.Tables[0].Rows[0][4]);

                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_AddFunds";
                objCommand.Parameters.AddWithValue("@VirtualWallet_ID", virtualWalletID);
                objCommand.Parameters.AddWithValue("@Amount", amount);
                db.DoUpdateUsingCmdObj(objCommand);

                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_GetVirtualWallet";
                objCommand.Parameters.AddWithValue("@VirtualWallet_ID", virtualWalletID);
                myds = db.GetDataSetUsingCmdObj(objCommand);
                double newAmount = Convert.ToDouble(myds.Tables[0].Rows[0][4]);

                //if there was positive funds added
                if (newAmount > currentAmount)
                {
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_NewTransactionOneWallet";
                    objCommand.Parameters.AddWithValue("@VirtualWalletOne_ID", virtualWalletID);
                    objCommand.Parameters.AddWithValue("@Merchant_Account_ID", merchantAccountID);
                    objCommand.Parameters.AddWithValue("@Transaction_Type", "Added Funds");
                    objCommand.Parameters.AddWithValue("@Transaction_Amount", amount);
                    objCommand.Parameters.Add("@Transaction_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
                    db.DoUpdateUsingCmdObj(objCommand);



                    int newTransactionID = Convert.ToInt32(objCommand.Parameters["@Transaction_ID"].Value);
                    return "$" + amount + " funded to Account. Your Transaction ID# is " + newTransactionID +".";
                }
                else
                {
                    return "The balance stayed the same";
                }
            }

            return "An Error Occured Funds were not added to your Account.";
        }

        //DELETE: api/service/PaymentGateway/5
        // (DELETE: api/ApiWithActions/5)
        [HttpDelete("{id}")]
        public string Delete(int id)
        {
            return "The web api delete received" + id;
        }

        public bool isVerified(int merchantID, int merchantAPIKEY)
        {
            //selects the merchant with the id and api key combo
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_GetMerchantByIDandWebAPIKEY";
            objCommand.Parameters.AddWithValue("@Merchant_Account_ID", merchantID);
            objCommand.Parameters.AddWithValue("@Merchant_API_KEY", merchantAPIKEY);
            myds = db.GetDataSetUsingCmdObj(objCommand);

            //if there is a record with this match return true
            if(myds.Tables[0].Rows.Count != 0)
            {
                return true;
            }

            return false;
        }
    }
}
