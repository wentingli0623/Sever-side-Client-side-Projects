﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayBuddy
{
    public class Transaction
    {
        public int transaction_ID;
        public int virtualWalletOne_ID;
        public int virtualWalletTwo_ID;
        public int merchant_Account_ID;
        public String transaction_Type;
        public double transaction_amount;
        public String transaction_DateTime;



        //data model class
        //do this for every attribute
        [JsonProperty(PropertyName = "Transaction ID#")]
        public int Transaction_ID
        {
            get { return transaction_ID; }
            set { transaction_ID = value; }
        }

        [JsonProperty(PropertyName = "Virtual Wallet One ID#")]
        public int VirtualWalletOne_ID
        {
            get { return virtualWalletOne_ID; }
            set { virtualWalletOne_ID = value; }
        }

        [JsonProperty(PropertyName = "Virtual Wallet Two ID#")]
        public int VirtualWalletTwo_ID
        {
            get { return virtualWalletTwo_ID; }
            set { virtualWalletTwo_ID = value; }
        }

        [JsonProperty(PropertyName = "Merchant Account ID#")]
        public int Merchant_Account_ID
        {
            get { return merchant_Account_ID; }
            set { merchant_Account_ID = value; }
        }

        [JsonProperty(PropertyName = "Transaction Type")]
        public String Transaction_Type
        {
            get { return transaction_Type; }
            set { transaction_Type = value; }
        }

        [JsonProperty(PropertyName = "Transaction Amount")]
        public double Transaction_Amount
        {
            get { return transaction_amount; }
            set { transaction_amount = value; }
        }

        [JsonProperty(PropertyName = "Transaction Date & Time")]
        public String Transaction_DateTime
        {
            get { return transaction_DateTime; }
            set { transaction_DateTime = value; }
        }
    }
}
