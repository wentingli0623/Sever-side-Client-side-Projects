﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayBuddy
{
    public class AccountHolderInformation
    {
        //private
        //encapsulation
        public String name;
        public String paymentMethod;
        public String paymentMethodNumber;
        public String accountType;



        //data model class
        //do this for every attribute
        [JsonProperty(PropertyName = "Account Name")]
        public String Name
        {
            get { return name; }
            set { name = value; }
        }

        [JsonProperty(PropertyName = "Preferred Payment Method")]
        public String PaymentMethod
        {
            get { return paymentMethod; }
            set { paymentMethod = value; }
        }

        [JsonProperty(PropertyName = "Payment Method Number")]
        public String PaymentMethodNumber
        {
            get { return paymentMethodNumber; }
            set { paymentMethodNumber = value; }
        }

        [JsonProperty(PropertyName = "Account Type")]
        public String AccountType
        {
            get { return accountType; }
            set { accountType = value; }
        }

        public AccountHolderInformation() {
        }
        
        public AccountHolderInformation(string name, string paymentMethod, 
            string paymentMethodNumber, string accountType)
        {
            this.Name = name;
            this.PaymentMethod = paymentMethod;
            this.PaymentMethodNumber = paymentMethodNumber;
            this.AccountType = accountType;

        }

    }
}
