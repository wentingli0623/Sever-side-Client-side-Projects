﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;


namespace Food_Delivery_Project
{
    public partial class ViewCart : System.Web.UI.Page
    {

        static ArrayList Order = new ArrayList();
        DBConnect db = new DBConnect();
        SqlCommand objCommand = new SqlCommand();
        private const int FIRST_COLUMN = 3;
        private const int TOTALPRICE_COLUMN = 4;
        private const int QUANTITY_COLUMN = 5;
        DBConnect dBConnect = new DBConnect();
        static int totalQuantity = 0;
        static double total = 0.0;
        static  int latestOrderID;
        DataSet dsGetOrderLineItems;
        DataSet dsGetItemId;
        static DataSet dsCustomerWalletID;
        static DataSet dsRestaurantWalletID;
        static string customerWalletID;
        static string restaurantWalletID;
        static int merchantAccountID;
        static int merchantAPIKey;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["Order"] != null)
                {
                    Order = (ArrayList)Session["Order"];


                    if (Session["OrderQuantity"] != null)
                    {
                        totalQuantity = (int)Session["OrderQuantity"];
                    }

                    if (Session["OrderTotal"] != null)
                    {
                        total = (double)Session["OrderTotal"];
                    }

                    gvOrder.Columns[FIRST_COLUMN].FooterText = "Total: ";
                    gvOrder.Columns[QUANTITY_COLUMN].FooterText = totalQuantity.ToString();
                    gvOrder.Columns[TOTALPRICE_COLUMN].FooterText = total.ToString("C2");
                    gvOrder.Columns[FIRST_COLUMN].FooterStyle.ForeColor = Color.Red;
                    gvOrder.Columns[QUANTITY_COLUMN].FooterStyle.ForeColor = Color.Red;
                    gvOrder.Columns[TOTALPRICE_COLUMN].FooterStyle.ForeColor = Color.Red;

                    gvOrder.DataSource = Order;
                    gvOrder.DataBind();

                    gvOrder.Columns[0].Visible = false;
                    gvOrder.Columns[6].Visible = false;
                    btnFinishEditing.Visible = false;
                    lblError.Visible = false;
                    btnRemoveFromOrder.Visible = false;
                    btnClickHereToOrder.Visible = false;
                    btnViewOrders.Visible = false;

                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_GetCustomer";
                    objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                    dsCustomerWalletID = db.GetDataSetUsingCmdObj(objCommand);

                    customerWalletID = dsCustomerWalletID.Tables[0].Rows[0][13].ToString();
                    merchantAccountID = Int32.Parse(dsCustomerWalletID.Tables[0].Rows[0][11].ToString());
                    merchantAPIKey = Int32.Parse(dsCustomerWalletID.Tables[0].Rows[0][12].ToString());

                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_GetRestaurant";
                    objCommand.Parameters.AddWithValue("@Email_Address", Session["Restaurant_Email"].ToString());
                    dsRestaurantWalletID = db.GetDataSetUsingCmdObj(objCommand);

                    restaurantWalletID = dsRestaurantWalletID.Tables[0].Rows[0][0].ToString();
                }
                else 
                {
                    lblError.Visible = true;
                    lblError.ForeColor = Color.Black;
                    lblError.Text = "There aren't any items in your cart.";
                    lblOrder.Visible = false;
                    btnRemoveFromOrder.Visible = false;
                    btnFinishEditing.Visible = false;
                    btnEditOrder.Visible = false;
                    btnPlaceOrder.Visible = false;
                    btnViewOrders.Visible = false;
                    btnClickHereToOrder.Visible = true;
                }
            }
        }

        public bool processPayment(string walletOne, string walletTwo, string type, float amount,
            int merchantAccountID, int merchantAPIKEY)
        {

            string apiUrl = "http://cis-iis2.temple.edu/Fall2019/CIS3342_tug36432/TermProjectWS/api/service/PaymentGateway/processPayment/";
            apiUrl += merchantAccountID + "/" + merchantAPIKEY + "/" + walletOne + "/" + walletTwo + "/" + type + "/" + amount;


            try
            {
                // Send the Customer object to the Web API that will be used to store a new customer record in the database.
                // Setup an HTTP POST Web Request and get the HTTP Web Response from the server.
                WebRequest request = WebRequest.Create(apiUrl);
                request.Method = "POST";
                request.ContentLength = 0;
                request.ContentType = "application/json";


                // Read the data from the Web Response, which requires working with streams.
                WebResponse response = request.GetResponse();
                Stream theDataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(theDataStream);
                String data = reader.ReadToEnd();

                reader.Close();
                response.Close();


                if (data == "\"New PayBuddy Wallet was created successfully! Your Virtual Wallet ID# is .\"")
                {
                    lblError.Visible = true;
                    lblError.ForeColor = Color.Green;
                    lblError.Text = "Your Account was Successfully Created! New PayBuddy Wallet Virtual Wallet ID# is ";
                    return true;
                }
                else
                {
                    lblError.Visible = true;
                    lblError.ForeColor = Color.Red;
                    lblError.Text = "An Error Occured.";
                    return false;
                }
            }

            catch (Exception ex)
            {
                lblError.Visible = true;
                lblError.ForeColor = Color.Red;
                lblError.Text = "Error: " + ex.Message;
                return false;
            }

        }

        protected void btnOrder_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomerView.aspx");
        }

        protected void btnEditOrder_Click(object sender, EventArgs e)
        {
            gvOrder.Columns[0].Visible = true;
            gvOrder.Columns[6].Visible = true;
            gvOrder.Columns[5].Visible = false;
            btnPlaceOrder.Visible = false;
            btnEditOrder.Visible = false;
            btnFinishEditing.Visible = true;
            btnRemoveFromOrder.Visible = true;
            lblOrder.Text = "Edit Order";
            gvOrder.ShowFooter = false;
            gvOrder.FooterRow.Visible = false;

        }

        protected void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            //BEGIN STORED PROCEDURE TO CREATE A NEW ORDER
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_CreateOrder";
            objCommand.Parameters.AddWithValue("@Customer_Email", Session["UserEmail"].ToString());
            objCommand.Parameters.AddWithValue("@Restaurant_Email", Session["Restaurant_Email"].ToString());
            objCommand.Parameters.AddWithValue("@TotalQuantity", totalQuantity);
            objCommand.Parameters.AddWithValue("@Total", total);
            objCommand.Parameters.AddWithValue("@DateTime", System.DateTime.Now);
            objCommand.Parameters.AddWithValue("@Order_Status", "submitted");

            //setup Output Parameter
            objCommand.Parameters.Add("@Order_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
            db.DoUpdateUsingCmdObj(objCommand);

            //Takes the value of the output parameter from the stored procedure
            //and saves it in a variable that will be used to display the most recent order
            latestOrderID = Convert.ToInt32(objCommand.Parameters["@Order_ID"].Value);

            //-------------------------------------------------------------------------------------------
            //BEGIN STORED PROCEDURE TO CREATE ORDER LINE ITEMS

            //iterates through the Order ArrayList and inserts each item into the 
            //TP_OrderLineItems table
            foreach (OrderedItem item in Order)
            {
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_CreateOrderLineItems";
                objCommand.Parameters.AddWithValue("@Order_ID", latestOrderID);
                objCommand.Parameters.AddWithValue("@Item_ID", item.ItemID);
                objCommand.Parameters.AddWithValue("@Image", item.Image.ToString());
                objCommand.Parameters.AddWithValue("@Title", item.Title.ToString());
                objCommand.Parameters.AddWithValue("@Description", item.Description.ToString());
                objCommand.Parameters.AddWithValue("@Price", item.Price);
                objCommand.Parameters.AddWithValue("@Configurable_Options", item.ConfigurableOptions.ToString());
                objCommand.Parameters.AddWithValue("@Quantity", item.Quantity);
                db.DoUpdateUsingCmdObj(objCommand);
            }

            //-------------------------------------------------------------------------------------------
            //BEGIN STORED PROCEDURE TO GET ORDER AND ORDER LINE ITEMS

            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_GetOrderLineItems";
            objCommand.Parameters.AddWithValue("@Order_ID", latestOrderID);
            dsGetOrderLineItems = db.GetDataSetUsingCmdObj(objCommand);

            if (dsGetOrderLineItems.Tables[0].Rows.Count > 0)
            {
                //needs work
                /*string type = "payment";
                string total = gvOrder.Columns[FIRST_COLUMN].FooterText;
                char[] parsetotal = total.Where(c => Char.IsDigit(c)).ToArray();
                string newtotal = new string(parsetotal);
                float amount = float.Parse(total);
                //call the api to process a payment
                //if(processPayment(customerWalletID, restaurantWalletID, type, amount, 
                   // merchantAccountID, merchantAPIKey))
                {
                    lblError.Visible = true;
                    lblError.ForeColor = Color.Green;
                    lblError.Text = "Your Order has been placed! Your Order # is " + latestOrderID + ".";
                    btnPlaceOrder.Visible = false;
                    btnEditOrder.Visible = false;
                    btnViewOrders.Visible = true;
                }*/

                lblError.Visible = true;
                lblError.ForeColor = Color.Green;
                lblError.Text = "Your Order has been placed! Your Order # is " + latestOrderID + ".";
                btnPlaceOrder.Visible = false;
                btnEditOrder.Visible = false;
                btnViewOrders.Visible = true;
            }
            else
            {
                lblError.Visible = true;
                lblError.ForeColor = Color.Red;
                lblError.Text = "An Unexpected Error Occured.";
            }

        }//end btnPlaceOrder

        protected void btnFinishEditing_Click(object sender, EventArgs e)
        {   
            //reset Order and total/totalQuantity
            Order.Clear();
            total = 0;
            totalQuantity = 0;

            for (int row = 0; row < gvOrder.Rows.Count; row++)
            {
                //GetItemId from the TP_Menu table for each item in the current gvOrder gridview
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_SelectItemID";
                objCommand.Parameters.AddWithValue("@Email_Address", Session["Restaurant_Email"].ToString());
                objCommand.Parameters.AddWithValue("@Title", gvOrder.Rows[row].Cells[2].Text);
                objCommand.Parameters.AddWithValue("@Description", gvOrder.Rows[row].Cells[3].Text);
                dsGetItemId = db.GetDataSetUsingCmdObj(objCommand);
                

                    OrderedItem orderedItem = new OrderedItem();
                    orderedItem.ItemID = int.Parse(dsGetItemId.Tables[0].Rows[0][0].ToString());
                    System.Web.UI.WebControls.Image img = gvOrder.Rows[row].Cells[1].Controls[0] as System.Web.UI.WebControls.Image;
                    orderedItem.Image = img.ImageUrl.ToString();
                    orderedItem.Title = gvOrder.Rows[row].Cells[2].Text;
                    orderedItem.Description = gvOrder.Rows[row].Cells[3].Text;
                    orderedItem.Price = double.Parse(gvOrder.Rows[row].Cells[4].Text, System.Globalization.NumberStyles.Currency);
                    TextBox TBox;
                    TBox = (TextBox)gvOrder.Rows[row].FindControl("txtQuantity");

                    //if there is a quantity entered
                    if (TBox.Text != "")
                    {
                        orderedItem.Quantity = int.Parse(TBox.Text);
                    }
                    else
                    {
                    lblError.Visible = true;
                    lblError.ForeColor = Color.Red;
                    lblError.Text = "You must enter a new Quantity!";
                    }
                    
                    //orderedItem.ConfigurableOptions = gvMenu.Rows[row].Cells[6].Text;
                    orderedItem.ConfigurableOptions = "";

                    //modify price based on configurable options (size, 4-count, 6-count, add-ons, etc.)
                    orderedItem.Price = OrderedItem.priceOfOrderedItem(orderedItem);
                    orderedItem.FinalPrice = OrderedItem.totalCostOfItem(orderedItem);

                    total += orderedItem.FinalPrice;
                    totalQuantity += orderedItem.Quantity;

                    Order.Add(orderedItem);
            }


            gvOrder.Columns[FIRST_COLUMN].FooterText = "Total: ";
            gvOrder.Columns[QUANTITY_COLUMN].FooterText = totalQuantity.ToString();
            gvOrder.Columns[TOTALPRICE_COLUMN].FooterText = total.ToString("C2");
            gvOrder.Columns[FIRST_COLUMN].FooterStyle.ForeColor = Color.Red;
            gvOrder.Columns[QUANTITY_COLUMN].FooterStyle.ForeColor = Color.Red;
            gvOrder.Columns[TOTALPRICE_COLUMN].FooterStyle.ForeColor = Color.Red;

            gvOrder.Columns[5].Visible = true;

            gvOrder.DataSource = Order;
            gvOrder.DataBind();

            gvOrder.Columns[0].Visible = false;
            
            gvOrder.Columns[6].Visible = false;
            btnFinishEditing.Visible = false;
            lblError.Visible = false;
            btnRemoveFromOrder.Visible = false;
            lblOrder.Text = "Order";
            gvOrder.ShowFooter = true;
            gvOrder.FooterRow.Visible = true;
            btnPlaceOrder.Visible = true;
            btnEditOrder.Visible = true;
        }//end btnFinishEditing

        protected void btnRemoveFromOrder_Click(object sender, EventArgs e)
        {
            int count = 0;
            int index = -1;

            for (int row = 0; row < gvOrder.Rows.Count; row++)
            {
                index++;
                CheckBox CBox;
                CBox = (CheckBox)gvOrder.Rows[row].FindControl("cbxSelectOrderItems");

                if (CBox.Checked)
                {
                    count++;
                    Order.RemoveAt(index);

                    gvOrder.DataSource = Order;
                    gvOrder.DataBind();
                }
            }

            //if there are still items to be deleted from the Order ArrayList
            if (Order.Count != 0)
            {
                lblError.Visible = true;
                lblError.ForeColor = Color.Green;
                lblError.Text = "" + count + " items were removed from your order";
            }
            //if all items are deleted from the Order ArrayList
            else if (Order.Count == 0)
            {
                lblError.Visible = true;
                lblError.ForeColor = Color.Black;
                lblError.Text = "There aren't any items in your cart.";
                lblOrder.Visible = false;
                btnRemoveFromOrder.Visible = false;
                btnFinishEditing.Visible = false;
                btnClickHereToOrder.Visible = true;
                Session["Order"] = null;
            }

        }//end btnRemoveFromOrder

        protected void btnCart_Click(object sender, EventArgs e)
        {
            //does nothing
        }

        protected void btnViewOrders_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomerAccount.aspx");
        }

        protected void btnClickHereToOrder_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomerView.aspx");
        }

        protected void btnAccount_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomerAccount.aspx");
        }
    }
}