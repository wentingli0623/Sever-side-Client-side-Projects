﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;
using System.Drawing;
using System.Web.Script.Serialization;
using System.Net;
using System.IO;

namespace Food_Delivery_Project
{
    public partial class CreateNewAccount : System.Web.UI.Page
    {
        DBConnect db = new DBConnect();
        SqlCommand objCommand = new SqlCommand();
        DataSet ds;
        bool isRestaurant;
        int virtualWalletID;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblErrorMessage.Visible = false;
                txtPassword.Visible = false;
                txtPhoneNumber.Visible = false;
                txtCustomerAddress.Visible = false;
                txtCustomerCity.Visible = false;
                ddlCustomerState.Visible = false;
                btnCreateNewAccount.Visible = false;
                lblSecurityQuestion.Visible = false;
                txtSecurityQuestionAnswer.Visible = false;
                ddlSecurityQuestion.Visible = false;
            }
        }

        protected void btnReturnToLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");

        }

        protected void btnCheckEmailAvailability_Click(object sender, EventArgs e)
        {
            if (ddlSelect.Text == "Restaurant")
            {
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_CheckRestaurantEmail";
                objCommand.Parameters.AddWithValue("@Email_Address", txtEmailAddress.Text);
                DataSet myds = db.GetDataSetUsingCmdObj(objCommand);

                if (myds.Tables[0].Rows.Count != 0)
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Red;
                    lblErrorMessage.Text = "That Email is already taken! Please enter a different Email Address.";
                }
                else
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Green;
                    lblErrorMessage.Text = "That Email is Available!";
                    txtPassword.Visible = true;
                    txtPhoneNumber.Visible = true;
                    btnCreateNewAccount.Visible = true;
                    lblSecurityQuestion.Visible = true;
                    txtSecurityQuestionAnswer.Visible = true;
                    ddlSecurityQuestion.Visible = true;

                }
            }
            else //its a customer so do this
            {
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_CheckCustomerEmail";
                objCommand.Parameters.AddWithValue("@Email_Address", txtEmailAddress.Text);
                DataSet myds = db.GetDataSetUsingCmdObj(objCommand);

                if (myds.Tables[0].Rows.Count != 0)
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Red;
                    lblErrorMessage.Text = "That Email is already taken! Please enter a different Email Address.";
                }
                else
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Green;
                    lblErrorMessage.Text = "That Email is Available!";
                    txtPassword.Visible = true;
                    txtPhoneNumber.Visible = true;
                    txtCustomerAddress.Visible = true;
                    txtCustomerCity.Visible = true;
                    ddlCustomerState.Visible = true;
                    btnCreateNewAccount.Visible = true;
                    lblSecurityQuestion.Visible = true;
                    txtSecurityQuestionAnswer.Visible = true;
                    ddlSecurityQuestion.Visible = true;
                }
            }
        }

        protected void btnCreateNewAccount_Click(object sender, EventArgs e)
        {
            if (ddlSelect.Text == "Customer")
            {
                //add the new record
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_AddCustomer";
                objCommand.Parameters.AddWithValue("@Email_Address", txtEmailAddress.Text);
                objCommand.Parameters.AddWithValue("@Customer_Name", txtName.Text);
                objCommand.Parameters.AddWithValue("@Customer_Phone_Number", txtPhoneNumber.Text);
                objCommand.Parameters.AddWithValue("@Password", txtPassword.Text);
                objCommand.Parameters.AddWithValue("@Customer_Address", txtCustomerAddress.Text);
                objCommand.Parameters.AddWithValue("@Customer_City", txtCustomerCity.Text);
                objCommand.Parameters.AddWithValue("@Customer_State", ddlCustomerState.Text);
                objCommand.Parameters.AddWithValue("@Security_Question", ddlSecurityQuestion.SelectedItem.Text);
                objCommand.Parameters.AddWithValue("@Security_Question_Answer", txtSecurityQuestionAnswer.Text);
                db.DoUpdateUsingCmdObj(objCommand);

                //check that the record was added
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_CheckCustomerEmail";
                objCommand.Parameters.AddWithValue("@Email_Address", txtEmailAddress.Text);
                DataSet myds = db.GetDataSetUsingCmdObj(objCommand);

                if (myds.Tables[0].Rows.Count != 0)
                {
                    int merchantAccountID = 1004;
                    int merchantAPIKEY = 45889662;

                    if (createWallet(ddlSelect.Text, merchantAccountID, merchantAPIKEY))
                    {
                        lblChoice.Visible = false;
                        ddlSelect.Visible = false;
                        txtName.Visible = false;
                        txtEmailAddress.Visible = false;
                        btnCheckEmailAvailability.Visible = false;
                        txtPassword.Visible = false;
                        txtPhoneNumber.Visible = false;
                        txtCustomerAddress.Visible = false;
                        txtCustomerCity.Visible = false;
                        ddlCustomerState.Visible = false;
                        btnCreateNewAccount.Visible = false;
                        lblSecurityQuestion.Visible = false;
                        txtSecurityQuestionAnswer.Visible = false;
                        ddlSecurityQuestion.Visible = false;
                    }

                    if (ckBCookie.Checked)
                    {


                        HttpCookie myCookie = new HttpCookie("customerloginCookie");
                        myCookie.Values["userEmail"] = txtEmailAddress.Text;
                        myCookie.Values["userPassword"] = txtPassword.Text;
                        myCookie.Expires = new DateTime(2025, 1, 1);

                        Response.Cookies.Add(myCookie);


                    }
                }
            }
            else
            {
                //add the new record
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_AddRestaurant";
                objCommand.Parameters.AddWithValue("@Email_Address", txtEmailAddress.Text);
                objCommand.Parameters.AddWithValue("@Restaurant_Name", txtName.Text);
                objCommand.Parameters.AddWithValue("@Restaurant_Phone_Number", txtPhoneNumber.Text);
                objCommand.Parameters.AddWithValue("@Password", txtPassword.Text);
                objCommand.Parameters.AddWithValue("@Security_Question", ddlSecurityQuestion.SelectedItem.Text);
                objCommand.Parameters.AddWithValue("@Security_Question_Answer", txtSecurityQuestionAnswer.Text);
                db.DoUpdateUsingCmdObj(objCommand);

                //check that the record was added
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_CheckRestaurantEmail";
                objCommand.Parameters.AddWithValue("@Email_Address", txtEmailAddress.Text);
                DataSet myds = db.GetDataSetUsingCmdObj(objCommand);



                if (myds.Tables[0].Rows.Count != 0)
                {

                    int merchantAccountID = 1004;
                    int merchantAPIKEY = 45889662;

                    if (createWallet(ddlSelect.Text, merchantAccountID, merchantAPIKEY))
                    {
                        lblChoice.Visible = false;
                        ddlSelect.Visible = false;
                        txtName.Visible = false;
                        txtEmailAddress.Visible = false;
                        btnCheckEmailAvailability.Visible = false;
                        txtPassword.Visible = false;
                        txtPhoneNumber.Visible = false;
                        txtCustomerAddress.Visible = false;
                        txtCustomerCity.Visible = false;
                        ddlCustomerState.Visible = false;
                        btnCreateNewAccount.Visible = false;
                        lblSecurityQuestion.Visible = false;
                        txtSecurityQuestionAnswer.Visible = false;
                        ddlSecurityQuestion.Visible = false;
                    }

                    if (ckBCookie.Checked)
                    {


                        HttpCookie myCookie = new HttpCookie("resturantloginCookie");
                        myCookie.Values["userEmail"] = txtEmailAddress.Text;
                        myCookie.Values["userPassword"] = txtPassword.Text;
                        myCookie.Expires = new DateTime(2025, 1, 1);

                        Response.Cookies.Add(myCookie);


                    }
                }
            }

        }//end CreateNewAccount

        protected void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        public bool createWallet(string type, int merchantAccountID, int merchantAPIKEY)
        {

            string apiUrl = "http://cis-iis2.temple.edu/Fall2019/CIS3342_tug36432/TermProjectWS/api/service/PaymentGateway/createVirtualWallet/";
            apiUrl += merchantAccountID + "/" + merchantAPIKEY;

            Random rand = new Random();
            AccountHolderInformation accountUpdate = new AccountHolderInformation();
            accountUpdate.Name = txtName.Text;
            accountUpdate.PaymentMethod = "debit card";
            accountUpdate.PaymentMethodNumber = rand.Next(11111111, 99999999).ToString();
            accountUpdate.AccountType = type;

            // Serialize a Customer object into a JSON string.
            JavaScriptSerializer js = new JavaScriptSerializer();
            String jsonAccountUpate = js.Serialize(accountUpdate);

            try
            {
                // Send the Customer object to the Web API that will be used to store a new customer record in the database.
                // Setup an HTTP POST Web Request and get the HTTP Web Response from the server.
                WebRequest request = WebRequest.Create(apiUrl);
                request.Method = "POST";
                request.ContentLength = jsonAccountUpate.Length;
                request.ContentType = "application/json";


                // Write the JSON data to the Web Request
                StreamWriter writer = new StreamWriter(request.GetRequestStream());
                writer.Write(jsonAccountUpate);
                writer.Flush();
                writer.Close();

                // Read the data from the Web Response, which requires working with streams.
                WebResponse response = request.GetResponse();
                Stream theDataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(theDataStream);
                String data = reader.ReadToEnd();

                reader.Close();
                response.Close();

                char[] dataWalletID = data.Where(c => Char.IsDigit(c)).ToArray();
                string newdata = new string(dataWalletID);
                int virtualWalletID = int.Parse(newdata);

                if (ddlSelect.Text == "Restaurant")
                {
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_ChangeRestaurantWalletID";
                    objCommand.Parameters.AddWithValue("@Email_Address", txtEmailAddress.Text);
                    objCommand.Parameters.AddWithValue("@VirtualWallet_ID", virtualWalletID);
                    db.DoUpdateUsingCmdObj(objCommand);
                }
                else
                {
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_ChangeCustomerWalletID";
                    objCommand.Parameters.AddWithValue("@Email_Address", txtEmailAddress.Text);
                    objCommand.Parameters.AddWithValue("@VirtualWallet_ID", virtualWalletID);
                    db.DoUpdateUsingCmdObj(objCommand);
                }

                if (data == "\"New PayBuddy Wallet was created successfully! Your Virtual Wallet ID# is " + virtualWalletID + ".\"")
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Green;
                    lblErrorMessage.Text = "Your Account was Successfully Created! New PayBuddy Wallet Virtual Wallet ID# is " + virtualWalletID;
                    return true;
                }
                else
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Red;
                    lblErrorMessage.Text = "An Error Occured.";
                    return false;
                }
            }

            catch (Exception ex)
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = Color.Red;
                lblErrorMessage.Text = "Error: " + ex.Message;
                return false;
            }

        }
    }
}