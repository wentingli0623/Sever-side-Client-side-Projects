﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;

namespace Food_Delivery_Project
{
    public partial class RestaurantView : System.Web.UI.Page
    {

        DBConnect db = new DBConnect();
        static DataSet dsMyOrders;
        static DataSet myds;
        SqlCommand objCommand = new SqlCommand();
        static String Order_ID;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                btnSubmit.Visible = false;
                btnCancel.Visible = false;
                gvOrder.Visible = false;
                lblErrorMessage.Visible = false;

                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_SelectAllOrdersByRestaurantEmail";
                objCommand.Parameters.AddWithValue("@Restaurant_Email", Session["UserEmail"].ToString());
                dsMyOrders = db.GetDataSetUsingCmdObj(objCommand);

                // Set the datasource of the Repeater and bind the data
                rptOrders.DataSource = dsMyOrders;
                rptOrders.DataBind();

            }
        }

        protected void btnOrders_Click(object sender, EventArgs e)
        {
           
        }

        protected void btnAccount_Click(object sender, EventArgs e)
        {
            Response.Redirect("RestaurantAccount.aspx");
        }

        protected void btnMenu_Click(object sender, EventArgs e)
        {
            //Response.Redirect("RestaurantMenu.aspx");
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            panelOrders.Visible = true;
            gvOrder.Visible = false;
            panelChangeOrderStatus.Visible = false;
            txtSearch.Visible = true;
            txtSearch.Text = "";
            btnSearch.Visible = true;
            lblErrorMessage.Visible = false;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            //get the new delivery status from the gridview
            RadioButtonList rdb1;
            rdb1 = (RadioButtonList)gvOrder.Rows[0].FindControl("rdbDeliveryStatus");

            //update the database with the new status
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_ChangeOrderStatus";
            objCommand.Parameters.AddWithValue("@Order_Status", rdb1.Text.ToString());
            objCommand.Parameters.AddWithValue("@Order_ID", Order_ID);
            db.DoUpdateUsingCmdObj(objCommand);

            //get the new record and confirm the status change
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_GetOrder";
            objCommand.Parameters.AddWithValue("@Order_ID", Order_ID);
            myds = db.GetDataSetUsingCmdObj(objCommand);

            if(myds.Tables[0].Rows.Count > 0 && rdb1.Text.ToString() == myds.Tables[0].Rows[0][6].ToString())
            {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Green;
                    lblErrorMessage.Text = "Order Status Updated Successfully!"; 
            }

            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_SelectAllOrdersByRestaurantEmail";
            objCommand.Parameters.AddWithValue("@Restaurant_Email", Session["UserEmail"].ToString());
            dsMyOrders = db.GetDataSetUsingCmdObj(objCommand);

            // Set the datasource of the Repeater and bind the data
            rptOrders.DataSource = dsMyOrders;
            rptOrders.DataBind();

            btnSubmit.Visible = false;
            btnCancel.Visible = false;
            gvOrder.Visible = false;
            panelOrders.Visible = true;
            btnSearch.Visible = true;
            txtSearch.Visible = true;
        }

        protected void rptOrders_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            //get specific order id
            int rowIndex = e.Item.ItemIndex;
            Label myLabel = (Label)rptOrders.Items[rowIndex].FindControl("lblOrderID");
            Order_ID = myLabel.Text;

            //get the order by using the order id above
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_GetOrderById";
            objCommand.Parameters.AddWithValue("@Restaurant_Email", Session["UserEmail"].ToString());
            objCommand.Parameters.AddWithValue("@Order_ID", Order_ID);
            myds = db.GetDataSetUsingCmdObj(objCommand);

            btnCancel.Visible = true;
            btnSubmit.Visible = true;
            panelOrders.Visible = false;
            txtSearch.Visible = false;
            btnSearch.Visible = false;
            lblErrorMessage.Visible = false;

            gvOrder.Visible = true;
            gvOrder.DataSource = myds;
            gvOrder.DataBind();

        }
    }
}