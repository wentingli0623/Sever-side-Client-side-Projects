﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;

namespace Food_Delivery_Project
{
    public partial class CustomerView : System.Web.UI.Page
    {
        DBConnect db = new DBConnect();
        SqlCommand objCommand = new SqlCommand();
        static DataSet mydsRestaurants;
        static DataSet mydsMenuItems;
        static string selectedRestaurantEmail;

        ArrayList Order = new ArrayList();
        private int totalQuantity = 0;
        private double total = 0.0;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //Visibility Controls
                lblRestaurantMenu.Visible = false;
                lblgvRestaurantError.Visible = false;
                gvMenu.Visible = false;
                btnAddtoCart.Visible = false;
                btnGotoCart.Visible = false;

                //when page loads show all restaurants
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_SelectAllRestaurants";
                mydsRestaurants = db.GetDataSetUsingCmdObj(objCommand);

                gvRestaurants.DataSource = mydsRestaurants;
                gvRestaurants.DataBind();


            }

        }

        protected void btnShowMenu_Click(object sender, EventArgs e)
        {

            int count = 0;
            int rowChecked = 0;
            for (int row = 0; row < gvRestaurants.Rows.Count; row++)
            {
                CheckBox CBox;

                CBox = (CheckBox)gvRestaurants.Rows[row].FindControl("cbxSelectRestaurant");

                // Only one thing can be selected 

                if (CBox.Checked)
                {

                    count++;
                    rowChecked = row;

                    //Clear session["Restaurant_Email"] Object
                    //then set it equal to the Email of the restaurant that is checked
                    Session["Restaurant_Email"] = null;
                    Session["Restaurant_Email"] = gvRestaurants.Rows[row].Cells[4].Text;


                }
            }
            if (count > 1)
            {
                lblgvRestaurantError.Visible = true;
                lblgvRestaurantError.ForeColor = Color.Red;
                lblgvRestaurantError.Text = "You can only select one Menu at a time!";
                gvMenu.Visible = false;
            }
            else if (count < 1)
            {
                lblgvRestaurantError.Visible = true;
                lblgvRestaurantError.ForeColor = Color.Red;
                lblgvRestaurantError.Text = "You must select at least one restaurant!";
            }
            else
            {

                lblgvRestaurantError.Visible = false;
                lblRestaurantMenu.Visible = true;
                btnAddtoCart.Visible = true;
                btnGotoCart.Visible = true;
                gvMenu.Visible = true;
                selectedRestaurantEmail = gvRestaurants.Rows[rowChecked].Cells[4].Text;


                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_SelectMenuItemsByRestaurant";
                objCommand.Parameters.AddWithValue("@Email_Address", selectedRestaurantEmail);
                mydsMenuItems = db.GetDataSetUsingCmdObj(objCommand);
                gvMenu.DataSource = mydsMenuItems;
                gvMenu.DataBind();
            }
        }//end btnShowMenu_Click

        protected void btnAddtoCart_Click(object sender, EventArgs e)
        {
            int count = 0;
            Order.Clear();

            for (int row = 0; row < gvMenu.Rows.Count; row++)
            {
                CheckBox CBox;

                CBox = (CheckBox)gvMenu.Rows[row].FindControl("cbxSelectMenuItems");



                // Only one thing can be selected 
                if (CBox.Checked)
                {
                    OrderedItem orderedItem = new OrderedItem();

                    //retrieves the ItemID from the menu item dataset 
                    orderedItem.ItemID = int.Parse(mydsMenuItems.Tables[0].Rows[row][0].ToString());
                    System.Web.UI.WebControls.Image img = gvMenu.Rows[row].Cells[1].Controls[0] as System.Web.UI.WebControls.Image;
                    orderedItem.Image = img.ImageUrl.ToString();
                    orderedItem.Title = gvMenu.Rows[row].Cells[2].Text;
                    orderedItem.Description = gvMenu.Rows[row].Cells[3].Text;
                    orderedItem.Price = double.Parse(gvMenu.Rows[row].Cells[4].Text, System.Globalization.NumberStyles.Currency);
                    TextBox TBox;
                    TBox = (TextBox)gvMenu.Rows[row].FindControl("txtMenuQuantity");
                    orderedItem.Quantity = int.Parse(TBox.Text);
                    orderedItem.ConfigurableOptions = "";

                    //modify price based on configurable options (size, 4-count, 6-count, add-ons, etc.)
                    orderedItem.Price = OrderedItem.priceOfOrderedItem(orderedItem);
                    orderedItem.FinalPrice = OrderedItem.totalCostOfItem(orderedItem);

                    total += orderedItem.FinalPrice;
                    totalQuantity += orderedItem.Quantity;

                    Order.Add(orderedItem);
                    count += orderedItem.Quantity;
                }
            }

            //Items added to session object to be accessed by cart page
            Session["Order"] = Order;
            Session["OrderTotal"] = total;
            Session["OrderQuantity"] = totalQuantity;

            lblgvRestaurantError.Visible = true;
            lblgvRestaurantError.ForeColor = Color.Green;
            lblgvRestaurantError.Text = "" + count + " items were added to your cart!";
        } //end btnAddtoCart_Click 


        protected void btnGotoCart_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewCart.aspx");
        }

        protected void btnOrder_Click(object sender, EventArgs e)
        {

        }

        protected void btnAccount_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomerAccount.aspx");
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string searchWords = txtSearch.Text;


            if (ddlRestaurantFilter.SelectedItem.Text == "Restaurant Type")
            {

                objCommand.CommandType = CommandType.StoredProcedure;
                //  objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_SelectAllRestaurantsByType";
                objCommand.Parameters.AddWithValue("@resturantType", searchWords);
                mydsRestaurants = db.GetDataSetUsingCmdObj(objCommand);

                gvRestaurants.DataSource = mydsRestaurants;
                gvRestaurants.DataBind();

            }

            if (ddlRestaurantFilter.SelectedValue.ToString() == "Restaurant Name")
            {
                objCommand.CommandType = CommandType.StoredProcedure;
                //  objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_SelectAllRestaurantsByName";
                objCommand.Parameters.AddWithValue("@resturantName", searchWords);
                mydsRestaurants = db.GetDataSetUsingCmdObj(objCommand);

                gvRestaurants.DataSource = mydsRestaurants;
                gvRestaurants.DataBind();

            }
        }

        protected void ddlRestaurantFilter_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        /* protected void btnShowMenu_Click1(object sender, EventArgs e)
         {

         }*/

        /*protected void btnPlaceOrder_Click(object sender, EventArgs e)
        {

            for (int row = 0; row < gvShowSelectedResturantMune.Rows.Count; row++)
            {

                CheckBox CBox;
                TextBox txtQuantity;
                Image imgImage;

                CBox = (CheckBox)gvShowSelectedResturantMune.Rows[row].FindControl("ckbSelectMenuItems");
                txtQuantity = (TextBox)gvShowSelectedResturantMune.Rows[row].FindControl("txtbMenuQuantity");
                imgImage = (Image)gvShowSelectedResturantMune.Rows[row].FindControl("image");
                // only one resturant allowed to select
                if (CBox.Checked)
                {


                    order selectedSingleItem = new order();

                    Image img = gvShowSelectedResturantMune.Rows[row].Cells[1].Controls[0] as Image;
                    selectedSingleItem.Image = img.ImageUrl.ToString();
                    selectedSingleItem.Title = gvShowSelectedResturantMune.Rows[row].Cells[2].Text;
                    selectedSingleItem.Description = gvShowSelectedResturantMune.Rows[row].Cells[3].Text;
                    selectedSingleItem.Price = float.Parse(gvShowSelectedResturantMune.Rows[row].Cells[4].Text.Substring(1));


                    if (txtQuantity.Text == "")
                    {

                        Response.Write("<script>alert('Please put quantity of this order')</script>");
                    }
                    else
                    {
                        selectedSingleItem.Quantity = int.Parse(txtQuantity.Text);
                        selectedSingleItem.Total = selectedSingleItem.Price * selectedSingleItem.Quantity;
                        orderTotal += selectedSingleItem.Total;
                        orderList.Add(selectedSingleItem);
                    }
                }
                if (orderList.Count == 0)
                {


                    Response.Write("<script>alert('Please select at least one item ')</script>");

                }
            }/end btnPlaceOrder */

    }
}
