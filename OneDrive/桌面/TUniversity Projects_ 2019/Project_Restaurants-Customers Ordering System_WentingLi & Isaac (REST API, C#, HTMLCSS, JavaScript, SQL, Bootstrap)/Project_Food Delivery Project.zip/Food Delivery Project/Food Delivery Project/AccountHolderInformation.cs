﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Food_Delivery_Project
{
    public class AccountHolderInformation
    {
        //private
        //encapsulation
        public String name;
        public String paymentMethod;
        public String paymentMethodNumber;
        public String accountType;



        //data model class
        //do this for every attribute

        public String Name
        {
            get { return name; }
            set { name = value; }
        }


        public String PaymentMethod
        {
            get { return paymentMethod; }
            set { paymentMethod = value; }
        }


        public String PaymentMethodNumber
        {
            get { return paymentMethodNumber; }
            set { paymentMethodNumber = value; }
        }


        public String AccountType
        {
            get { return accountType; }
            set { accountType = value; }
        }

        public AccountHolderInformation()
        {
        }

        public AccountHolderInformation(string name, string paymentMethod,
            string paymentMethodNumber, string accountType)
        {
            this.Name = name;
            this.PaymentMethod = paymentMethod;
            this.PaymentMethodNumber = paymentMethodNumber;
            this.AccountType = accountType;

        }
    }
}