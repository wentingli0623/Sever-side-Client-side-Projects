﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;
using System.Drawing;

namespace Food_Delivery_Project
{
    public partial class ForgotPassword : System.Web.UI.Page
    {
        DBConnect db = new DBConnect();
        SqlCommand objCommand = new SqlCommand();
        static bool isRestaurant;
        DataSet myds;
        DataSet myds2;
        DataSet myds3;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblErrorMessage.Visible = false;
                isRestaurant = false;
                txtNewPassword.Visible = false;
                txtConfirmNewPassword.Visible = false;
                btnSubmit.Visible = false;
                txtSecurityQuestionAnswer.Visible = false;
                lblSecurityQuestion.Visible = false;
                btnCheckMyAnswer.Visible = false;
                

            }

        }


        protected bool isValidUser(string user)
        {
            //starts by Validating the username and pass against the Restaurant table
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_GetRestaurantPassword";
            objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
            myds = db.GetDataSetUsingCmdObj(objCommand);

            //if the user and password match the database
            if (myds.Tables[0].Rows.Count > 0 && user == myds.Tables[0].Rows[0][0].ToString())
            {
                isRestaurant = true;
                return true;
            }


            if (isRestaurant == false)
            {
                //if it's indeed not a restaurant validate against the customer table
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_GetCustomerPassword";
                objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
                myds2 = db.GetDataSetUsingCmdObj(objCommand);

                if (myds2.Tables[0].Rows.Count > 0 && user == myds2.Tables[0].Rows[0][0].ToString())
                {
                    isRestaurant = false;
                    return true;
                }


            }
            return false;
        }//end isValidUser

        protected void btnReturnToLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void btnChangeMyPassword_Click(object sender, EventArgs e)
        {
            if (isValidUser(txtUserName.Text) && !isRestaurant)
            {
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_GetCustomerPassword";
                objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
                myds3 = db.GetDataSetUsingCmdObj(objCommand);


                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = Color.Green;
                lblErrorMessage.Text = "Please Answer Your Security Question.";
                lblSecurityQuestion.Visible = true;
                lblSecurityQuestion.Text = "" + myds3.Tables[0].Rows[0][2].ToString() + "";
                txtSecurityQuestionAnswer.Visible = true;
                btnCheckMyAnswer.Visible = true;
                isRestaurant = false;
                btnChangeMyPassword.Visible = false;
                txtUserName.Visible = false;
            }
            else if (isValidUser(txtUserName.Text) && isRestaurant)
            {
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_GetRestaurantPassword";
                objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
                myds3 = db.GetDataSetUsingCmdObj(objCommand);

                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = Color.Green;
                lblErrorMessage.Text = "Please Answer Your Security Question.";
                lblSecurityQuestion.Visible = true;
                lblSecurityQuestion.Text = "" + myds3.Tables[0].Rows[0][2].ToString() + "";
                txtSecurityQuestionAnswer.Visible = true;
                btnCheckMyAnswer.Visible = true;
                isRestaurant = true;
                btnChangeMyPassword.Visible = false;
                txtUserName.Visible = false;
                /* txtNewPassword.Visible = true;
                 txtConfirmNewPassword.Visible = true;
                 btnSubmit.Visible = true;*/
            }
            else
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = Color.Red;
                lblErrorMessage.Text = "The information you provided does not match what we have in our records! Please Try Again.";
            }
        }//end ChangeMyPassword_Click

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtConfirmNewPassword.Text != "" && txtNewPassword.Text != "")
            {

                if (isRestaurant == false && confirmPassword(txtNewPassword.Text, txtConfirmNewPassword.Text))
                {
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_ChangeCustomerPassword";
                    objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
                    objCommand.Parameters.AddWithValue("@New_Password", txtNewPassword.Text);
                    db.DoUpdateUsingCmdObj(objCommand);

                    
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_GetCustomerPassword";
                    objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
                    myds2 = db.GetDataSetUsingCmdObj(objCommand);

                    if (myds2.Tables[0].Rows.Count > 0 && txtConfirmNewPassword.Text == myds2.Tables[0].Rows[0][1].ToString())
                    {
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = Color.Green;
                        lblErrorMessage.Text = "Your Password was Successfully Changed!";
                        txtConfirmNewPassword.Visible = false;
                        txtNewPassword.Visible = false;
                        txtUserName.Visible = false;
                        btnSubmit.Visible = false;
                        btnChangeMyPassword.Visible = false;
                    }


                }
                else if (isRestaurant == true && confirmPassword(txtNewPassword.Text, txtConfirmNewPassword.Text))
                {
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_ChangeRestaurantPassword";
                    objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
                    objCommand.Parameters.AddWithValue("@New_Password", txtNewPassword.Text);
                    db.DoUpdateUsingCmdObj(objCommand);

                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_GetRestaurantPassword";
                    objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
                    myds2 = db.GetDataSetUsingCmdObj(objCommand);

                    if (myds2.Tables[0].Rows.Count > 0 && txtConfirmNewPassword.Text == myds2.Tables[0].Rows[0][1].ToString())
                    {
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = Color.Green;
                        lblErrorMessage.Text = "Your Password was Successfully Changed!";
                        txtConfirmNewPassword.Visible = false;
                        txtNewPassword.Visible = false;
                        txtUserName.Visible = false;
                        btnSubmit.Visible = false;
                        btnChangeMyPassword.Visible = false;

                    }
                }
                else
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Red;
                    lblErrorMessage.Text = "Passwords do not match! Try Again.";
                }
            }
        }//end btnSubmit_Click

        //does not work for restaurant for some reason needs to be debugged
        protected void btnCheckMyAnswer_Click(object sender, EventArgs e)
        {
            if(isRestaurant) 
            {
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_GetRestaurantPassword";
                objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
                myds2 = db.GetDataSetUsingCmdObj(objCommand);

                if (myds2.Tables[0].Rows.Count > 0 && txtSecurityQuestionAnswer.Text == myds2.Tables[0].Rows[0][3].ToString())
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Green;
                    lblErrorMessage.Text = "Your Credentials Were Verified! Please Enter A New Password";
                    txtConfirmNewPassword.Visible = true;
                    txtNewPassword.Visible = true;
                    btnSubmit.Visible = true;
                    lblSecurityQuestion.Visible = false;
                    txtSecurityQuestionAnswer.Visible = false;
                    btnCheckMyAnswer.Visible = false;
                }
            }
            else if (!isRestaurant)
            {
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_GetCustomerPassword";
                objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
                myds2 = db.GetDataSetUsingCmdObj(objCommand);

                if (myds2.Tables[0].Rows.Count > 0 && txtSecurityQuestionAnswer.Text == myds2.Tables[0].Rows[0][3].ToString())
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Green;
                    lblErrorMessage.Text = "Your Credentials Were Verified! Please Enter A New Password";
                    txtConfirmNewPassword.Visible = true;
                    txtNewPassword.Visible = true;
                    btnSubmit.Visible = true;
                    lblSecurityQuestion.Visible = false;
                    txtSecurityQuestionAnswer.Visible = false;
                    btnCheckMyAnswer.Visible = false;

                }
            }
        }//end btn CheckMyAnswer

        protected bool confirmPassword (string password, string confirmpassword)
        {
            if (password == confirmpassword)
            {
                return true;
            }
            return false;
        }


    }
}