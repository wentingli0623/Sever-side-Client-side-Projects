﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;

namespace Food_Delivery_Project
{
    public partial class Login : System.Web.UI.Page
    {
        DBConnect db = new DBConnect();
        SqlCommand objCommand = new SqlCommand();
        bool isRestaurant;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblErrorMessage.Visible = false;
                isRestaurant = false;

            }
            if (Request.Cookies["customerloginCookie"] != null)
            {
                Session["UserEmail"] = (string)Request.Cookies["customerloginCookie"].Values["userEmail"].ToString();
                Response.Redirect("CustomerView.aspx");
            }
            if (Request.Cookies["resturantloginCookie"] != null)
            {
                Session["UserEmail"] = (string)Request.Cookies["resturantloginCookie"].Values["userEmail"].ToString();
                Response.Redirect("RestaurantView.aspx");
            }
        }

        protected void btnCreateNewAccount_Click(object sender, EventArgs e)
        {
            Response.Redirect("CreateNewAccount.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {

            if (isValidUser(txtUserName.Text, txtPassword.Text) && isRestaurant == false)
            {
                Session["UserEmail"] = txtUserName.Text;
                Response.Redirect("CustomerView.aspx");
            }
            else if(isValidUser(txtUserName.Text, txtPassword.Text) && isRestaurant == true)
            {
                Session["UserEmail"] = txtUserName.Text;
                Response.Redirect("RestaurantView.aspx");
            }
            else
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = Color.Red;
                lblErrorMessage.Text = "Not a Valid Username or Password!";
            }

        }

        protected bool isValidUser(string user, string pass)
        {
                //starts by Validating the username and pass against the Restaurant table
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_SelectRestaurantUsernameAndPassword";
                objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
                DataSet myds = db.GetDataSetUsingCmdObj(objCommand);

                    if (myds.Tables[0].Rows.Count > 0 && user == myds.Tables[0].Rows[0][0].ToString() && pass == myds.Tables[0].Rows[0][1].ToString())
                    {
                        isRestaurant = true;
                        return true;
                    }

                
            if (isRestaurant == false)
            {
                //if it's indeed not a restaurant validate against the customer table
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_SelectCustomerUsernameAndPassword";
                objCommand.Parameters.AddWithValue("@Email_Address", txtUserName.Text);
                DataSet myds2 = db.GetDataSetUsingCmdObj(objCommand);

                    if (myds2.Tables[0].Rows.Count > 0  && user == myds2.Tables[0].Rows[0][0].ToString() && pass == myds2.Tables[0].Rows[0][1].ToString())
                    {
                        isRestaurant = false;
                        return true;
                    }
                

            }
            return false;
        }//end isValidUser

        protected void btnForgotPassword_Click(object sender, EventArgs e)
        {
            Response.Redirect("ForgotPassword.aspx");
        }
    }
}