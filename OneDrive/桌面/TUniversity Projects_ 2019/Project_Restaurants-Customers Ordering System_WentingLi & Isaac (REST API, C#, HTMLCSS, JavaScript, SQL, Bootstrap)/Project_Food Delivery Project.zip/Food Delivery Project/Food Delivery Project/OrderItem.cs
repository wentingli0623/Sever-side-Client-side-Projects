﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Food_Delivery_Project
{
    public class OrderedItem
    {
        //add a class for Drinks with attributes from each order 

        //private
        //encapsulation
            public int itemID;
            public String image;
            public String title;
            public String description;
            public double price;
            public int quantity;
            public String configurableOptions;

            public double totalSales;
            public int totalQuantitySold;
            public double finalprice;




        //data model class
        //do this for every attribute
            public int ItemID
            {
                get { return itemID; }
                set { itemID = value; }
            }

            public String Image
            {
                get { return image; }
                set { image = value; }
            }

            public String Title
            {
                get { return title; }
                set { title = value; }
            }

            public String Description
            {
                get { return description; }
                set { description = value; }
            }

            public double Price
            {
                get { return price; }
                set { price = value; }
            }

            public int Quantity
            {
                get { return quantity; }
                set { quantity = value; }
            }

            public String ConfigurableOptions
            {
                get { return configurableOptions; }
                set { configurableOptions = value; }

            }


            public double FinalPrice
            {
                get { return finalprice; }
                set { finalprice = value; }
            }

            public int TotalQuantitySold
            {
                get { return totalQuantitySold; }
                set { totalQuantitySold = value; }
            }

            public double TotalSales
            {
                get { return totalSales; }
                set { totalSales = value; }
            }

        public static double totalCostOfItem(OrderedItem orderedItem)
        {

            return (orderedItem.quantity * orderedItem.price);

        }//end totalCostOfItem


        public static double priceOfOrderedItem(OrderedItem orderedItem)
        {
            if (orderedItem.configurableOptions != null)
            {
                //do something
            }
            /*if (orderedItem.size == "Trenta")
            {
                return orderedItem.price += (.5 * orderedItem.price);
            }
            else if (orderedItem.size == "Venti")
            {
                return orderedItem.price += (.3 * orderedItem.price);
            }
            else if (orderedItem.size == "Grande")
            {
                return orderedItem.price += (.2 * orderedItem.price);
            }
            else if (orderedItem.size == "Tall")
            {
                return orderedItem.price += (.15 * orderedItem.price);
            }*/

            return orderedItem.price;
        }//end priceOfDrink method 

    }
}