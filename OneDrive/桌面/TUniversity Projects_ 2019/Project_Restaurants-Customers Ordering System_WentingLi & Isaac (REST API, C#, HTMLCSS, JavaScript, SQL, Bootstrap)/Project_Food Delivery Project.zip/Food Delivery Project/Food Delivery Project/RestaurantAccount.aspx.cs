﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;

namespace Food_Delivery_Project
{
    public partial class RestaurantAccount : System.Web.UI.Page
    {
        DBConnect db = new DBConnect();
        static DataSet dsMyRestaurant;
        static DataSet myds;
        SqlCommand objCommand = new SqlCommand();
        static string RestaurantEmail;
        double Balance = 0.0;
        List<Transaction> TransactionList = new List<Transaction>();
        Label lblBalance;
        Label lblPaymentMethod;
        Label lblName;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                panelAccountInfo.Visible = true;
                panelAccountActivity.Visible = true;
                panelChangeInfo.Visible = false;
                lblErrorMessage.Visible = false;


                RestaurantEmail = (string)Session["UserEmail"];


                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_GetRestaurant";
                objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                dsMyRestaurant = db.GetDataSetUsingCmdObj(objCommand);

                int virtualWalletID = (int)Int32.Parse(dsMyRestaurant.Tables[0].Rows[0][12].ToString());
                int merchantAccountID = (int)Int32.Parse(dsMyRestaurant.Tables[0].Rows[0][10].ToString());
                int merchantAPIKEY = (int)Int32.Parse(dsMyRestaurant.Tables[0].Rows[0][11].ToString());


                // Set the datasource of the ListView and bind the data
                lstAccountInfo.DataSource = dsMyRestaurant;
                lstAccountInfo.DataBind();

                lblBalance = (Label)lstAccountInfo.Items[0].FindControl("lblBalance");

                if (GetTransactions(virtualWalletID, merchantAccountID, merchantAPIKEY))
                {
                    //foreach Transaction t in Transactions
                    rptTransactions.DataSource = TransactionList;
                    rptTransactions.DataBind();

                    getBalance(TransactionList);
                    lblBalance.Text = "$" + Balance + "";
                }

            }
        }

        public void getBalance(List<Transaction> Transactions)
        {
            foreach (Transaction t in Transactions)
            {
                if (t.Transaction_Type == "payment" || t.Transaction_Type == "Added Funds")
                {
                    Balance += t.Transaction_Amount;

                }
                else if (t.Transaction_Type == "refund")
                {
                    Balance -= t.Transaction_Amount;
                }
            }
        }

        public bool GetTransactions(int virtualWalletID, int merchantAccountID, int merchantAPIKEY)
        {

            string apiUrl = "http://cis-iis2.temple.edu/Fall2019/CIS3342_tug36432/TermProjectWS/api/service/PaymentGateway/getTransactions/";
            apiUrl += merchantAccountID + "/" + merchantAPIKEY + "/" + virtualWalletID;

            try
            {
                // Send the Customer object to the Web API that will be used to store a new customer record in the database.
                // Setup an HTTP POST Web Request and get the HTTP Web Response from the server.
                WebRequest request = WebRequest.Create(apiUrl);
                WebResponse response = request.GetResponse();

                Stream theDataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(theDataStream);
                String data = reader.ReadToEnd();
                reader.Close();
                response.Close();

                JavaScriptSerializer js = new JavaScriptSerializer();
                TransactionList = js.Deserialize<List<Transaction>>(data);

                return true;

            }

            catch (Exception ex)
            {
                return false;
            }
        }

        public bool UpdateAccount(string name, int virtualWalletID, int merchantAccountID, int merchantAPIKEY)
        {
            lblPaymentMethod = (Label)lstAccountInfo.Items[0].FindControl("lblPreferredPaymentMethod");

            string apiUrl = "http://cis-iis2.temple.edu/Fall2019/CIS3342_tug36432/TermProjectWS/api/service/PaymentGateway/updatePaymentInfo/";
            apiUrl += merchantAccountID + "/" + merchantAPIKEY + "/" + virtualWalletID;

            Random rand = new Random();
            AccountHolderInformation accountUpdate = new AccountHolderInformation();
            accountUpdate.Name = name;
            accountUpdate.PaymentMethod = lblPaymentMethod.Text;
            accountUpdate.PaymentMethodNumber = rand.Next(11111111, 99999999).ToString();
            accountUpdate.AccountType = "restaurant";

            // Serialize a Customer object into a JSON string.
            JavaScriptSerializer js = new JavaScriptSerializer();
            String jsonAccountUpate = js.Serialize(accountUpdate);

            try
            {
                // Send the Customer object to the Web API that will be used to store a new customer record in the database.
                // Setup an HTTP POST Web Request and get the HTTP Web Response from the server.
                WebRequest request = WebRequest.Create(apiUrl);
                request.Method = "PUT";
                request.ContentLength = jsonAccountUpate.Length;
                request.ContentType = "application/json";


                // Write the JSON data to the Web Request
                StreamWriter writer = new StreamWriter(request.GetRequestStream());
                writer.Write(jsonAccountUpate);
                writer.Flush();
                writer.Close();

                // Read the data from the Web Response, which requires working with streams.
                WebResponse response = request.GetResponse();
                Stream theDataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(theDataStream);
                String data = reader.ReadToEnd();

                reader.Close();
                response.Close();

                if (data == "\"Account # " + virtualWalletID + " successfully updated! \"")
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Green;
                    lblErrorMessage.Text = "Name Successfully Updated!";
                    return true;
                }
                else
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Red;
                    lblErrorMessage.Text = "An Error Occured.";
                    return false;
                }
            }

            catch (Exception ex)
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = Color.Red;
                lblErrorMessage.Text = "Error: " + ex.Message;
                return false;
            }

        }

        public bool UpdateAccount(string PaymentMethod, string PaymentMethodNumber, int virtualWalletID, int merchantAccountID, int merchantAPIKEY)
        {
            lblName = (Label)lstAccountInfo.Items[0].FindControl("lblCustomerName");

            string apiUrl = "http://cis-iis2.temple.edu/Fall2019/CIS3342_tug36432/TermProjectWS/api/service/PaymentGateway/updatePaymentInfo/";
            apiUrl += merchantAccountID + "/" + merchantAPIKEY + "/" + virtualWalletID;

            AccountHolderInformation accountUpdate = new AccountHolderInformation();
            accountUpdate.Name = lblName.Text;
            accountUpdate.PaymentMethod = PaymentMethod;
            accountUpdate.PaymentMethodNumber = PaymentMethodNumber;
            accountUpdate.AccountType = "restaurant";

            // Serialize a Customer object into a JSON string.
            JavaScriptSerializer js = new JavaScriptSerializer();
            String jsonAccountUpate = js.Serialize(accountUpdate);

            try
            {
                // Send the Customer object to the Web API that will be used to store a new customer record in the database.
                // Setup an HTTP POST Web Request and get the HTTP Web Response from the server.
                WebRequest request = WebRequest.Create(apiUrl);
                request.Method = "PUT";
                request.ContentLength = jsonAccountUpate.Length;
                request.ContentType = "application/json";


                // Write the JSON data to the Web Request
                StreamWriter writer = new StreamWriter(request.GetRequestStream());
                writer.Write(jsonAccountUpate);
                writer.Flush();
                writer.Close();

                // Read the data from the Web Response, which requires working with streams.
                WebResponse response = request.GetResponse();
                Stream theDataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(theDataStream);
                String data = reader.ReadToEnd();

                reader.Close();
                response.Close();

                if (data == "\"Account # " + virtualWalletID + " successfully updated! \"")
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Green;
                    lblErrorMessage.Text = "Update was successful";
                    return true;
                }
                else
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Red;
                    lblErrorMessage.Text = "A problem occurred while Updating your account";
                    return false;
                }
            }

            catch (Exception ex)
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = Color.Red;
                lblErrorMessage.Text = "Error: " + ex.Message;
                return false;
            }

        }

        protected void btnAccountInformation_Click(object sender, EventArgs e)
        {
            //toggle Account Info Visibility
            if (panelAccountInfo.Visible)
            {
                lblErrorMessage.Visible = false;
                panelAccountInfo.Visible = false;
            }
            else
            {
                lblErrorMessage.Visible = false;
                panelAccountInfo.Visible = true;
            }
        }

        protected void btnOrders_Click(object sender, EventArgs e)
        {
            Response.Redirect("RestaurantView.aspx");
        }

        protected void btnAccountActivity_Click(object sender, EventArgs e)
        {
            //toggle Account Info Visibility
            if (panelAccountActivity.Visible)
            {
                lblErrorMessage.Visible = false;
                panelAccountActivity.Visible = false;
            }
            else
            {
                lblErrorMessage.Visible = false;
                panelAccountActivity.Visible = true;
            }
        }

        protected void btnChangePaymentMethod_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Visible = false;
            panelChangeInfo.Visible = true;
            lblPreferredPaymentMethod.Visible = true;
            rdbPreferredPaymentMetod.Visible = true;
            txtPreferredPaymentMethodNumber.Visible = true;
            lblChange.Visible = false;
            txtChange.Visible = false;
            lblConfirmChange.Visible = false;
            txtConfirmChange.Visible = false;

        }

        protected void btnChangePassword_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Visible = false;
            panelChangeInfo.Visible = true;
            lblPreferredPaymentMethod.Visible = false;
            rdbPreferredPaymentMetod.Visible = false;
            txtPreferredPaymentMethodNumber.Visible = false;
            lblChange.Visible = true;
            txtChange.Visible = true;
            lblConfirmChange.Visible = true;
            txtConfirmChange.Visible = true;
            txtChange.TextMode = TextBoxMode.Password;
            txtConfirmChange.TextMode = TextBoxMode.Password;
            lblChange.Text = "Enter New Password";
            lblConfirmChange.Text = "Confirm New Password";
        }

        protected void btnChangePhone_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Visible = false;
            panelChangeInfo.Visible = true;
            lblPreferredPaymentMethod.Visible = false;
            rdbPreferredPaymentMetod.Visible = false;
            txtPreferredPaymentMethodNumber.Visible = false;
            lblChange.Visible = true;
            txtChange.Visible = true;
            lblConfirmChange.Visible = true;
            txtConfirmChange.Visible = true;
            lblChange.Text = "Enter New Phone Number";
            lblConfirmChange.Text = "Confirm New Phone Number";
            txtChange.TextMode = TextBoxMode.SingleLine;
            txtConfirmChange.TextMode = TextBoxMode.SingleLine;
            txtChange.Text = "";
            txtConfirmChange.Text = "";

        }

        protected void btnChangeEmail_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Visible = false;
            panelChangeInfo.Visible = true;
            lblPreferredPaymentMethod.Visible = false;
            rdbPreferredPaymentMetod.Visible = false;
            txtPreferredPaymentMethodNumber.Visible = false;
            lblChange.Visible = true;
            txtChange.Visible = true;
            lblConfirmChange.Visible = true;
            txtConfirmChange.Visible = true;
            lblChange.Text = "Enter New Email";
            lblConfirmChange.Text = "Confirm New Email";
            txtChange.TextMode = TextBoxMode.SingleLine;
            txtConfirmChange.TextMode = TextBoxMode.SingleLine;
            txtChange.Text = "";
            txtConfirmChange.Text = "";
        }

        protected void btnChangeName_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Visible = false;
            panelChangeInfo.Visible = true;
            lblPreferredPaymentMethod.Visible = false;
            rdbPreferredPaymentMetod.Visible = false;
            txtPreferredPaymentMethodNumber.Visible = false;
            lblChange.Visible = true;
            txtChange.Visible = true;
            lblConfirmChange.Visible = true;
            txtConfirmChange.Visible = true;
            lblChange.Text = "Enter New Name";
            lblConfirmChange.Text = "Confirm New Name";
            txtChange.TextMode = TextBoxMode.SingleLine;
            txtConfirmChange.TextMode = TextBoxMode.SingleLine;
            txtChange.Text = "";
            txtConfirmChange.Text = "";
        }

        protected void btnFundAccount_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Visible = false;
            panelChangeInfo.Visible = true;
            lblPreferredPaymentMethod.Visible = false;
            rdbPreferredPaymentMetod.Visible = false;
            txtPreferredPaymentMethodNumber.Visible = false;
            lblChange.Visible = true;
            txtChange.Visible = true;
            lblChange.Text = "Enter Amount";
            lblConfirmChange.Visible = false;
            txtConfirmChange.Visible = false;
            txtChange.TextMode = TextBoxMode.SingleLine;
            txtConfirmChange.TextMode = TextBoxMode.SingleLine;
            txtChange.Text = "";

        }

        protected void btnSubmitChanges_Click(object sender, EventArgs e)
        {
            //if the radio button list is not visible
            if (!rdbPreferredPaymentMetod.Visible)
            {
                ValidateCredentials(txtPassword.Text, lblChange.Text, lblConfirmChange.Text);
            }
            else
            {
                ValidateCredentials(txtPassword.Text, rdbPreferredPaymentMetod.SelectedValue);
            }

        }//end btnSubmit Changes

        //Validates Credentials based off which information
        //the user wishes to changes
        protected void ValidateCredentials(string pass, string change, string confirmChange)
        {
            //Get the current password 
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_GetRestaurant";
            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
            myds = db.GetDataSetUsingCmdObj(objCommand);

            //check password from the customer table
            if (myds.Tables[0].Rows.Count > 0 && pass == myds.Tables[0].Rows[0][5].ToString())
            {
                if (change == "Enter New Password")
                {
                    //if the new password equals the old one show an error
                    if (txtChange.Text == myds.Tables[0].Rows[0][5].ToString())
                    {
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = Color.Red;
                        lblErrorMessage.Text = "Password must be different from the old one!";
                    }
                    else
                    {
                        //if the new password matches the confirmed password change it
                        //get the new password then confirmed it's been changed
                        if (txtChange.Text == txtConfirmChange.Text)
                        {
                            objCommand.CommandType = CommandType.StoredProcedure;
                            objCommand.Parameters.Clear();
                            objCommand.CommandText = "TP_ChangeRestaurantPassword";
                            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                            objCommand.Parameters.AddWithValue("@New_Password", txtConfirmChange.Text);
                            db.DoUpdateUsingCmdObj(objCommand);


                            objCommand.CommandType = CommandType.StoredProcedure;
                            objCommand.Parameters.Clear();
                            objCommand.CommandText = "TP_GetRestaurant";
                            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                            myds = db.GetDataSetUsingCmdObj(objCommand);

                            if (myds.Tables[0].Rows.Count > 0 && txtConfirmChange.Text == myds.Tables[0].Rows[0][5].ToString())
                            {
                                lblErrorMessage.Visible = true;
                                lblErrorMessage.ForeColor = Color.Green;
                                lblErrorMessage.Text = "Your Password was Successfully Changed!";
                                panelChangeInfo.Visible = false;

                            }
                        }
                        else
                        {
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = Color.Red;
                            lblErrorMessage.Text = "New passwords must match!";
                        }
                    }
                }//end new password change
                else if (change == "Enter New Email")
                {
                    //if the new email equals the old one show an error
                    if (txtChange.Text == myds.Tables[0].Rows[0][2].ToString())
                    {
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = Color.Red;
                        lblErrorMessage.Text = "Email must be different from the old one!";
                    }
                    else
                    {
                        //if the new email matches the confirmed email change it
                        //get the new email, and the orders associated with it
                        //then confirmed it's been changed
                        if (txtChange.Text == txtConfirmChange.Text)
                        {

                            //change the customer table
                            objCommand.CommandType = CommandType.StoredProcedure;
                            objCommand.Parameters.Clear();
                            objCommand.CommandText = "TP_ChangeRestaurantEmail";
                            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                            objCommand.Parameters.AddWithValue("@New_Email", txtConfirmChange.Text);
                            db.DoUpdateUsingCmdObj(objCommand);

                            //change the orders table
                            objCommand.CommandType = CommandType.StoredProcedure;
                            objCommand.Parameters.Clear();
                            objCommand.CommandText = "TP_ChangeRestaurantEmailOrders";
                            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                            objCommand.Parameters.AddWithValue("@New_Email", txtConfirmChange.Text);
                            db.DoUpdateUsingCmdObj(objCommand);

                            //Change the session "UserEmail" object
                            //to reflect the new change in emails
                            Session["UserEmail"] = txtConfirmChange.Text;

                            //Check the order table to see if the email has been changed
                            //by confirming there are records that exist with the new email address
                            objCommand.CommandType = CommandType.StoredProcedure;
                            objCommand.Parameters.Clear();
                            objCommand.CommandText = "TP_SelectAllOrdersByRestaurantEmail";
                            objCommand.Parameters.AddWithValue("@Restaurant_Email", Session["UserEmail"].ToString());
                            myds = db.GetDataSetUsingCmdObj(objCommand);

                            if (myds.Tables[0].Rows.Count > 0)
                            {
                                lblErrorMessage.Visible = true;
                                lblErrorMessage.ForeColor = Color.Green;
                                lblErrorMessage.Text = "Your Email was Successfully Changed!";
                                panelChangeInfo.Visible = false;
                            }
                        }
                        else
                        {
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = Color.Red;
                            lblErrorMessage.Text = "New Emails must match!";
                        }
                    }
                }//end new email change
                else if (change == "Enter New Phone Number")
                {
                    //if the new phone number equals the old one show an error
                    if (txtChange.Text == myds.Tables[0].Rows[0][3].ToString())
                    {
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = Color.Red;
                        lblErrorMessage.Text = "Phone # must be different from the old one!";
                    }
                    else
                    {
                        //if the new phone number matches the confirmed phone number change it
                        //get the new phone number then confirmed it's been changed
                        if (txtChange.Text == txtConfirmChange.Text)
                        {

                            //change the customer table
                            objCommand.CommandType = CommandType.StoredProcedure;
                            objCommand.Parameters.Clear();
                            objCommand.CommandText = "TP_ChangeRestaurantPhoneNumber";
                            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                            objCommand.Parameters.AddWithValue("@New_Phone_Number", txtConfirmChange.Text);
                            db.DoUpdateUsingCmdObj(objCommand);

                            //check the new phone number
                            objCommand.CommandType = CommandType.StoredProcedure;
                            objCommand.Parameters.Clear();
                            objCommand.CommandText = "TP_GetRestaurant";
                            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                            myds = db.GetDataSetUsingCmdObj(objCommand);

                            if (myds.Tables[0].Rows.Count > 0 && txtConfirmChange.Text == myds.Tables[0].Rows[0][3].ToString())
                            {
                                lblErrorMessage.Visible = true;
                                lblErrorMessage.ForeColor = Color.Green;
                                lblErrorMessage.Text = "Your Phone Number was Successfully Changed!";
                                panelChangeInfo.Visible = false;
                            }
                        }
                        else
                        {
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = Color.Red;
                            lblErrorMessage.Text = "New Phone Numbers must match!";
                        }
                    }

                }//end new phone number change
                else if (change == "Enter New Name")
                {
                    //if the new name equals the old one show an error
                    if (txtChange.Text == myds.Tables[0].Rows[0][1].ToString())
                    {
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = Color.Red;
                        lblErrorMessage.Text = "Name must be different from the old one!";
                    }
                    else
                    {
                        //if the new name matches the confirmed phone number change it
                        //get the new name number then confirmed it's been changed
                        if (txtChange.Text == txtConfirmChange.Text)
                        {

                            //change the customer table
                            objCommand.CommandType = CommandType.StoredProcedure;
                            objCommand.Parameters.Clear();
                            objCommand.CommandText = "TP_ChangeRestaurantName";
                            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                            objCommand.Parameters.AddWithValue("@New_Name", txtConfirmChange.Text);
                            db.DoUpdateUsingCmdObj(objCommand);

                            //check the new name
                            objCommand.CommandType = CommandType.StoredProcedure;
                            objCommand.Parameters.Clear();
                            objCommand.CommandText = "TP_GetRestaurant";
                            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                            myds = db.GetDataSetUsingCmdObj(objCommand);

                            if (myds.Tables[0].Rows.Count > 0 && txtConfirmChange.Text == myds.Tables[0].Rows[0][1].ToString())
                            {
                                int virtualWalletID = (int)Int32.Parse(myds.Tables[0].Rows[0][13].ToString());
                                int merchantAccountID = (int)Int32.Parse(myds.Tables[0].Rows[0][11].ToString());
                                int merchantAPIKEY = (int)Int32.Parse(myds.Tables[0].Rows[0][12].ToString());

                                //call the api to update the payment profile
                                if (UpdateAccount(txtChange.Text, virtualWalletID, merchantAccountID, merchantAPIKEY))
                                {
                                    lblErrorMessage.Visible = true;
                                    lblErrorMessage.ForeColor = Color.Green;
                                    lblErrorMessage.Text = "Your Name was Successfully Changed!";
                                    panelChangeInfo.Visible = false;
                                }

                            }
                        }
                        else
                        {
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = Color.Red;
                            lblErrorMessage.Text = "New Names must match!";
                        }
                    }
                }//end new name change
                else if (change == "Enter Image Url")
                {
                    //if the new name equals the old one show an error
                    if (txtChange.Text == myds.Tables[0].Rows[0][2].ToString())
                    {
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = Color.Red;
                        lblErrorMessage.Text = "Image must be different from the old one!";
                    }
                    else
                    {
                        //change the customer table
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Clear();
                        objCommand.CommandText = "TP_ChangeRestaurantImage";
                        objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                        objCommand.Parameters.AddWithValue("@New_Image", txtConfirmChange.Text);
                        db.DoUpdateUsingCmdObj(objCommand);

                        //check the new image
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Clear();
                        objCommand.CommandText = "TP_GetRestaurant";
                        objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                        myds = db.GetDataSetUsingCmdObj(objCommand);

                        if (myds.Tables[0].Rows.Count > 0 && txtConfirmChange.Text == myds.Tables[0].Rows[0][2].ToString())
                        {
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = Color.Green;
                            lblErrorMessage.Text = "Your Image was Successfully Changed!";
                            panelChangeInfo.Visible = false;
                        }

                    }
                }//end new image change
                else if (change == "Enter Restaurant Type")
                {
                    //if the new name equals the old one show an error
                    if (txtChange.Text == myds.Tables[0].Rows[0][8].ToString())
                    {
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = Color.Red;
                        lblErrorMessage.Text = "Restaurant type must be different from the old one!";
                    }
                    else
                    {
                        //change the customer table
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Clear();
                        objCommand.CommandText = "TP_ChangeRestaurantType";
                        objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                        objCommand.Parameters.AddWithValue("@New_Type", txtConfirmChange.Text);
                        db.DoUpdateUsingCmdObj(objCommand);

                        //check the new type
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Clear();
                        objCommand.CommandText = "TP_GetRestaurant";
                        objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                        myds = db.GetDataSetUsingCmdObj(objCommand);

                        if (myds.Tables[0].Rows.Count > 0 && txtConfirmChange.Text == myds.Tables[0].Rows[0][8].ToString())
                        {
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = Color.Green;
                            lblErrorMessage.Text = "Your Restaurant Type was Successfully Changed!";
                            panelChangeInfo.Visible = false;
                        }

                    }
                }//end new type change
                else if (change == "Enter Amount")
                {
                    double amount = 0;
                    //if no amount is entered throw an error
                    if (txtChange.Text == "")
                    {
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = Color.Red;
                        lblErrorMessage.Text = "You must enter an amount greater than 0!";
                    }
                    //if the user did not enter a valid integer
                    //needs work not working properly
                    else if (!Double.TryParse(txtChange.Text, out amount))
                    {
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = Color.Red;
                        lblErrorMessage.Text = "You must enter a valid number!";
                    }
                    //if the amount the user enter is a valid double
                    //then call the api and add funds to the account
                    else if (Double.TryParse(txtChange.Text, out amount))
                    {
                        int virtualWalletID = (int)Int32.Parse(myds.Tables[0].Rows[0][12].ToString());
                        int merchantAccountID = (int)Int32.Parse(myds.Tables[0].Rows[0][10].ToString());
                        int merchantAPIKEY = (int)Int32.Parse(myds.Tables[0].Rows[0][11].ToString());
                        string apiUrl = "http://cis-iis2.temple.edu/Fall2019/CIS3342_tug36432/TermProjectWS/api/service/PaymentGateway/fundAccount/";
                        apiUrl += merchantAccountID + "/" + merchantAPIKEY + "/" + virtualWalletID + "/" + amount;

                        try
                        {
                            // Send the Customer object to the Web API that will be used to store a new customer record in the database.
                            // Setup an HTTP POST Web Request and get the HTTP Web Response from the server.
                            WebRequest request = WebRequest.Create(apiUrl);
                            request.Method = "PUT";
                            request.ContentLength = 0;

                            WebResponse response = request.GetResponse();
                            Stream theDataStream = response.GetResponseStream();
                            StreamReader reader = new StreamReader(theDataStream);
                            String data = reader.ReadToEnd();
                            reader.Close();
                            response.Close();

                            JavaScriptSerializer js = new JavaScriptSerializer();
                            string result = js.Deserialize<string>(data);

                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = Color.Green;
                            lblErrorMessage.Text = result;

                            lblBalance = (Label)lstAccountInfo.Items[0].FindControl("lblBalance");

                            //-----------------------------------------------------------------------------------
                            //rebinds the transactions list and should reset the balance but running into
                            //an issue
                            if (GetTransactions(virtualWalletID, merchantAccountID, merchantAPIKEY))
                            {
                                //foreach Transaction t in Transactions
                                rptTransactions.DataSource = TransactionList;
                                rptTransactions.DataBind();

                                getBalance(TransactionList);
                                lblBalance.Text = "$" + Balance + "";

                            }
                        }

                        catch (Exception ex)
                        {
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = Color.Red;
                            lblErrorMessage.Text = "Error: " + ex.Message;
                        }

                    }

                }//end funds added

                //get the new customer info
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Clear();
                objCommand.CommandText = "TP_GetRestaurant";
                objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                dsMyRestaurant = db.GetDataSetUsingCmdObj(objCommand);

                // Set the datasource of the ListView and bind the data
                lstAccountInfo.DataSource = dsMyRestaurant;
                lstAccountInfo.DataBind();
            }
        }//end ValidateCredentials

        //over load for radio button list
        protected void ValidateCredentials(string pass, string change)
        {
            //Get the current password 
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_GetRestaurant";
            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
            myds = db.GetDataSetUsingCmdObj(objCommand);

            //check password from the restaurant table
            if (myds.Tables[0].Rows.Count > 0 && pass == myds.Tables[0].Rows[0][5].ToString())
            {
                //if the new payment method equals the old one show an error
                if (rdbPreferredPaymentMetod.SelectedValue == myds.Tables[0].Rows[0][9].ToString())
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = Color.Red;
                    lblErrorMessage.Text = "Payment method must be different from the old one!";
                }
                else
                {
                    //change the restaurant table
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_ChangeRestaurantPreferredPaymentMethod";
                    objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                    objCommand.Parameters.AddWithValue("@New_Payment_Method", rdbPreferredPaymentMetod.Text);
                    db.DoUpdateUsingCmdObj(objCommand);

                    //check the new payment method
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.Parameters.Clear();
                    objCommand.CommandText = "TP_GetRestaurant";
                    objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
                    myds = db.GetDataSetUsingCmdObj(objCommand);

                    if (myds.Tables[0].Rows.Count > 0 && rdbPreferredPaymentMetod.SelectedValue == myds.Tables[0].Rows[0][9].ToString())
                    {
                        int virtualWalletID = (int)Int32.Parse(myds.Tables[0].Rows[0][12].ToString());
                        int merchantAccountID = (int)Int32.Parse(myds.Tables[0].Rows[0][10].ToString());
                        int merchantAPIKEY = (int)Int32.Parse(myds.Tables[0].Rows[0][11].ToString());

                        //call the api to update the payment profile
                        if (UpdateAccount(rdbPreferredPaymentMetod.SelectedItem.Text, txtPreferredPaymentMethodNumber.Text,
                            virtualWalletID, merchantAccountID, merchantAPIKEY))
                        {
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = Color.Green;
                            lblErrorMessage.Text = "Your Payment Method was Successfully Changed!";
                            panelChangeInfo.Visible = false;
                        }
                    }
                    else
                    {
                        //should never reach this, but if you do its there
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = Color.Red;
                        lblErrorMessage.Text = "An Error Occured!";
                    }
                }
            }

            //get the new customer info
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_GetRestaurant";
            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
            dsMyRestaurant = db.GetDataSetUsingCmdObj(objCommand);

            // Set the datasource of the ListView and bind the data
            lstAccountInfo.DataSource = dsMyRestaurant;
            lstAccountInfo.DataBind();
        }//end ValidateCredentials Overload

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            panelChangeInfo.Visible = false;
        }

        protected void btnAccount_Click(object sender, EventArgs e)
        {
            //do nothing
        }

        protected void btnMenu_Click(object sender, EventArgs e)
        {
            //Response.Redirect("RestaurantMenu.aspx");
        }

        protected void btnChangeImage_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Visible = false;
            panelChangeInfo.Visible = true;
            lblPreferredPaymentMethod.Visible = false;
            rdbPreferredPaymentMetod.Visible = false;
            txtPreferredPaymentMethodNumber.Visible = false;
            lblChange.Visible = true;
            txtChange.Visible = true;
            lblConfirmChange.Visible = false;
            txtConfirmChange.Visible = false;
            lblChange.Text = "Enter Image Url";
            txtChange.Text = "";
        }

        protected void btnChangeType_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Visible = false;
            panelChangeInfo.Visible = true;
            lblPreferredPaymentMethod.Visible = false;
            rdbPreferredPaymentMetod.Visible = false;
            txtPreferredPaymentMethodNumber.Visible = false;
            lblChange.Visible = true;
            txtChange.Visible = true;
            lblConfirmChange.Visible = false;
            txtConfirmChange.Visible = false;
            lblChange.Text = "Enter Restaurant Type";
            txtChange.Text = "";
        }
    }
}