﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;

namespace Food_Delivery_Project
{
    public partial class UserControlOne : System.Web.UI.UserControl
    {
        DBConnect objDB = new DBConnect();
        static DataSet myds;
        SqlCommand objCommand = new SqlCommand();
        string password;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [Category("Misc")]
        public String Password
        {
            get { return password; }
            set { password = value; }
        }

        public override void DataBind()
        {
            //Get the current password 
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Clear();
            objCommand.CommandText = "TP_GetCustomer";
            objCommand.Parameters.AddWithValue("@Email_Address", Session["UserEmail"].ToString());
            myds = objDB.GetDataSetUsingCmdObj(objCommand);

            string password = (String)objDB.GetField("Password", 0);

            foreach (char c in password)
            {
                lblPassword.Text += "*";
            }

        }
    }
}